import unittest

from game.config import GATE_RANK_ORDER
from game.dungeons.generator import DungeonLayoutGenerator
from game.dungeons.rewards import gate_clear_rewards
from game.dungeons.types import DEFAULT_RANK, RANK_SETTINGS, normalize_rank, rank_index


class DungeonSupportTests(unittest.TestCase):
    def test_layout_generator_builds_start_normal_and_boss_rooms(self):
        generator = DungeonLayoutGenerator()

        rooms = generator.build_room_plan("A", 3, "Crimson Vault")

        self.assertEqual([room.room_type for room in rooms], ["start", "normal", "normal", "normal", "boss"])
        self.assertEqual([room.room_id for room in rooms], [0, 1, 2, 3, 4])
        self.assertEqual(rooms[0].theme, "Crimson Vault")
        self.assertGreater(rooms[-1].encounter_budget, rooms[-2].encounter_budget)

    def test_layout_generator_normalizes_rank_and_room_count(self):
        generator = DungeonLayoutGenerator()

        rooms = generator.build_room_plan("???", 0, "")

        self.assertEqual(len(rooms), 3)
        self.assertEqual(rooms[0].theme, "unknown")
        self.assertEqual(rooms[1].encounter_budget, 1 + max(0, GATE_RANK_ORDER.index(DEFAULT_RANK) - 2))

    def test_gate_clear_rewards_clamps_negative_inputs(self):
        rewards = gate_clear_rewards("c", rooms_cleared=-5, kills=-10, mastery_level=-1)

        self.assertEqual(rewards, {"gold": 60, "potions": 1, "mana": 1, "stamina": 0, "mastery_xp": 15})

    def test_gate_clear_rewards_applies_bonuses(self):
        rewards = gate_clear_rewards("A", rooms_cleared=4, kills=7, flawless=True, mastery_level=6)

        self.assertEqual(rewards["gold"], 125 + 32 + 21 + 35 + 12 + 12)
        self.assertEqual(rewards["mastery_xp"], 22 + 8 + 2 + 12)
        self.assertEqual(rewards["potions"], 3)
        self.assertEqual(rewards["mana"], 1)
        self.assertEqual(rewards["stamina"], 1)

    def test_gate_clear_rewards_falls_back_to_default_rank_rewards(self):
        rewards = gate_clear_rewards("legend", rooms_cleared=0, kills=0, flawless=False, mastery_level=1)

        self.assertEqual(rewards, {"gold": 60, "potions": 1, "mana": 1, "stamina": 0, "mastery_xp": 15})

    def test_normalize_rank_uses_shared_default_for_unknown_values(self):
        self.assertEqual(normalize_rank("a"), "A")
        self.assertEqual(normalize_rank("legend"), DEFAULT_RANK)

    def test_rank_index_matches_gate_rank_order(self):
        self.assertEqual(rank_index("ss"), GATE_RANK_ORDER.index("SS"))
        self.assertEqual(rank_index("unknown"), GATE_RANK_ORDER.index(DEFAULT_RANK))

    def test_rank_settings_cover_all_gate_ranks(self):
        self.assertEqual(set(RANK_SETTINGS), set(GATE_RANK_ORDER))
        self.assertEqual(RANK_SETTINGS["MONARCH"]["boss_type"], "ss_boss")
        self.assertEqual(RANK_SETTINGS["E"]["room_range"], (2, 3))


if __name__ == "__main__":
    unittest.main()
