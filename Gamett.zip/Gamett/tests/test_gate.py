import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from game.dungeons.gate import Gate, GateRoom
from game.dungeons.types import rank_index


class DummyEnemy:
    def __init__(self, x: float, y: float, name: str = "Enemy", variant: str = "mob", archetype: str = "raider"):
        self.x = x
        self.y = y
        self.name = name
        self.variant = variant
        self.archetype = archetype
        self.alive = True
        self.radius = 16
        self.stats = SimpleNamespace(max_hp=10.0, hp=10.0, attack_power=1.0, speed=1.0)
        self.damage = 1.0
        self.base_speed = 1.0

    def set_target(self, target) -> None:
        self.target = target

    def set_coordination(self, role: str, **kwargs) -> None:
        self.role = role
        self.coord = kwargs

    def distance_to(self, target) -> float:
        return abs(self.x - target.x) + abs(self.y - target.y)


class DummyBoss(DummyEnemy):
    def __init__(self, x: float, y: float, name: str = "Boss", **kwargs):
        super().__init__(x, y, name=name, variant="boss", archetype="boss")
        self.pending = []

    def consume_summon_requests(self):
        requests = list(self.pending)
        self.pending.clear()
        return requests


def make_enemy(x: float, y: float, rank: str = "C", name: str = "Enemy", roll: float = 0.0):
    return DummyEnemy(x, y, name=name)


def make_miniboss(x: float, y: float, rank: str = "C", name: str = "MiniBoss"):
    return DummyEnemy(x, y, name=name, variant="charger", archetype="stalker")


def make_variant_enemy(variant: str, x: float, y: float, rank: str = "C", name: str = "Enemy", elite: bool = False):
    unit = DummyEnemy(x, y, name=name, variant=variant)
    unit.elite = elite
    return unit


class GateTests(unittest.TestCase):
    def setUp(self):
        enemy_patcher = patch("game.dungeons.gate.create_enemy", side_effect=make_enemy)
        miniboss_patcher = patch("game.dungeons.gate.create_miniboss", side_effect=make_miniboss)
        variant_patcher = patch("game.dungeons.gate.create_variant_enemy", side_effect=make_variant_enemy)
        boss_patcher = patch("game.dungeons.gate.Boss", side_effect=lambda x, y, name, style: DummyBoss(x, y, name=name))
        ss_boss_patcher = patch(
            "game.dungeons.gate.SSBoss",
            side_effect=lambda x, y, name, boss_id, style: DummyBoss(x, y, name=name),
        )

        self.patchers = [enemy_patcher, miniboss_patcher, variant_patcher, boss_patcher, ss_boss_patcher]
        for patcher in self.patchers:
            patcher.start()
            self.addCleanup(patcher.stop)

    def test_generate_creates_walkable_enemy_spawns(self):
        gate = Gate(rank="A", seed=7)

        self.assertGreaterEqual(len(gate.rooms), 3)
        self.assertEqual(gate.rooms[0].room_type, "start")
        self.assertEqual(gate.rooms[-1].room_type, "boss")

        for room in gate.rooms[1:]:
            self.assertTrue(room.enemy_spawn_points, f"Room {room.room_id} should have spawn points")
            for x, y in room.enemy_spawn_points:
                self.assertTrue(gate.is_walkable_point(x, y, 28, room=room), f"Spawn point {(x, y)} should be walkable")

    def test_sample_enemy_spawn_relaxes_spacing_before_returning_invalid_point(self):
        gate = Gate(rank="A", seed=11)
        room = GateRoom(room_id=99)
        room.room_bounds = gate.current_room_bounds()
        room.wall_rects = []
        room.player_spawn = (220.0, 360.0)
        room.enemy_spawn_points = [(900.0, 360.0), (980.0, 360.0)]

        spawn = gate._sample_enemy_spawn(room, used_positions=[(900.0, 360.0), (980.0, 360.0)])

        self.assertEqual(spawn, (900.0, 360.0))
        self.assertTrue(gate.is_walkable_point(*spawn, 28, room=room))

    def test_boss_summons_only_scale_after_player_power_is_known(self):
        gate = Gate(rank="A", seed=13)
        gate.balance = Mock()
        gate.balance.scale_enemy = Mock()
        room = GateRoom(room_id=1, room_type="boss")
        room.room_bounds = gate.current_room_bounds()
        room.wall_rects = []
        room.player_spawn = (220.0, 360.0)
        room.enemy_spawn_points = [(900.0, 360.0)]
        room.boss = DummyBoss(900.0, 360.0)

        gate.player_power = None
        gate._spawn_boss_summons(room, {"variant": "charger", "count": 1})
        gate.balance.scale_enemy.assert_not_called()

        gate.player_power = 42.0
        gate._spawn_boss_summons(room, {"variant": "wisp", "count": 1})
        gate.balance.scale_enemy.assert_called_once()
        _, scaled_power = gate.balance.scale_enemy.call_args.args
        self.assertEqual(scaled_power, 42.0)

    def test_advance_room_requires_current_room_to_be_cleared(self):
        gate = Gate(rank="A", seed=17)

        gate.current_room_index = 1
        room = gate.current_room()
        room.mobs = [DummyEnemy(400.0, 300.0)]
        room.mobs[0].alive = True

        advanced = gate.advance_room()

        self.assertFalse(advanced)
        self.assertEqual(gate.current_room_index, 1)
        self.assertFalse(gate.finished)

    def test_advancing_from_last_room_marks_gate_finished(self):
        gate = Gate(rank="A", seed=19)

        gate.current_room_index = len(gate.rooms) - 1
        room = gate.current_room()
        room.boss = None
        room.mobs = []

        advanced = gate.advance_room()

        self.assertFalse(advanced)
        self.assertTrue(gate.finished)

    def test_update_marks_boss_room_finished_when_boss_and_summons_are_dead(self):
        gate = Gate(rank="A", seed=23)
        gate.current_room_index = len(gate.rooms) - 1
        room = gate.current_room()
        room.boss = DummyBoss(900.0, 360.0)
        room.boss.alive = False
        room.mobs = [DummyEnemy(840.0, 360.0)]
        room.mobs[0].alive = False
        player = SimpleNamespace(x=220.0, y=360.0, alive=True)

        gate.update(player)

        self.assertTrue(room.cleared)
        self.assertTrue(gate.finished)

    def test_apply_balance_scales_all_room_enemies_and_bosses(self):
        gate = Gate(rank="A", seed=29)
        gate.balance = Mock()
        gate.balance.evaluate_player.return_value = 77.0
        gate.balance.calculate_multiplier = Mock()
        gate.balance.scale_enemy = Mock()
        gate.balance.scale_boss = Mock()

        normal_room = gate.rooms[1]
        normal_room.mobs = [DummyEnemy(300.0, 300.0), DummyEnemy(340.0, 300.0)]
        boss_room = gate.rooms[-1]
        boss_room.boss = DummyBoss(900.0, 360.0)
        boss_room.mobs = [DummyEnemy(840.0, 360.0)]
        expected_enemy_count = sum(len(room.mobs) for room in gate.rooms)
        expected_boss_count = sum(1 for room in gate.rooms if room.boss is not None)
        player = SimpleNamespace(
            x=220.0,
            y=360.0,
            alive=True,
            stats=SimpleNamespace(max_hp=100.0, max_mana=50.0, max_stamina=50.0, attack_power=5.0, defense=4.0, speed=10.0),
        )

        gate.apply_balance(player)

        self.assertEqual(gate.player_power, 77.0)
        gate.balance.calculate_multiplier.assert_called_once_with("A")
        self.assertEqual(gate.balance.scale_enemy.call_count, expected_enemy_count)
        self.assertEqual(gate.balance.scale_boss.call_count, expected_boss_count)
        gate.balance.scale_boss.assert_called_with(boss_room.boss, 77.0)

    def test_get_active_enemies_returns_living_units_only(self):
        gate = Gate(rank="A", seed=31)

        gate.current_room_index = 1
        normal_room = gate.current_room()
        alive_enemy = DummyEnemy(300.0, 300.0)
        dead_enemy = DummyEnemy(340.0, 300.0)
        dead_enemy.alive = False
        normal_room.mobs = [alive_enemy, dead_enemy]
        self.assertEqual(gate.get_active_enemies(), [alive_enemy])

        gate.current_room_index = len(gate.rooms) - 1
        boss_room = gate.current_room()
        living_boss = DummyBoss(900.0, 360.0)
        living_add = DummyEnemy(840.0, 360.0)
        dead_add = DummyEnemy(820.0, 360.0)
        dead_add.alive = False
        boss_room.boss = living_boss
        boss_room.mobs = [living_add, dead_add]
        self.assertEqual(gate.get_active_enemies(), [living_boss, living_add])

    def test_get_debug_state_reports_current_gate_progress(self):
        gate = Gate(rank="S", seed=37)
        gate.current_room_index = 1
        gate.current_room().cleared = True

        debug = gate.get_debug_state()

        self.assertEqual(debug["seed"], 37)
        self.assertEqual(debug["rank"], "S")
        self.assertEqual(debug["rank_index"], rank_index("S"))
        self.assertEqual(debug["display_name"], gate.display_name)
        self.assertEqual(debug["theme_name"], gate.theme_name)
        self.assertEqual(debug["current_room_index"], 1)
        self.assertEqual(debug["room_type"], gate.current_room().room_type)
        self.assertTrue(debug["room_cleared"])
        self.assertEqual(debug["total_rooms"], len(gate.rooms))


if __name__ == "__main__":
    unittest.main()
