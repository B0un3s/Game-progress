import unittest

from game.ai.behavior_tree import BehaviorTree


class DummyActor:
    def __init__(self, hp: float, attack_range: float = 45.0, speed: float = 140.0):
        self.hp = hp
        self.max_hp = 100.0
        self.attack_range = attack_range
        self.base_speed = speed


class DummyTarget:
    def __init__(self, x: float = 100.0, y: float = 100.0):
        self.x = x
        self.y = y


class BehaviorTreeTests(unittest.TestCase):
    def test_tick_prefers_pressure_when_enemy_is_close_and_healthy(self):
        tree = BehaviorTree("test")
        enemy = DummyActor(hp=80.0)
        player = DummyTarget()

        result = tree.tick(enemy=enemy, player=player, distance=18.0)

        self.assertEqual(result["action"], "pressure")
        self.assertIn("close", result["reason"])

    def test_tick_prefers_retreat_when_health_is_low(self):
        tree = BehaviorTree("test")
        enemy = DummyActor(hp=18.0)
        player = DummyTarget()

        result = tree.tick(enemy=enemy, player=player, distance=120.0)

        self.assertEqual(result["action"], "retreat")
        self.assertIn("low health", result["reason"])

    def test_tick_returns_a_human_like_action_when_context_is_missing(self):
        tree = BehaviorTree("test")

        result = tree.tick()

        self.assertIn(result["action"], {"idle", "observe", "pressure"})
        self.assertTrue(result["reason"])


if __name__ == "__main__":
    unittest.main()
