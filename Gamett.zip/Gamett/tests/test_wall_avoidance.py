import unittest

import pygame

from game.core.entity import Entity
from game.core.stats import Stats


class WallAvoidanceTests(unittest.TestCase):
    def test_entity_uses_navigation_walls_to_push_away_from_obstacle(self):
        entity = Entity(
            x=100.0,
            y=100.0,
            radius=10.0,
            color=(255, 255, 255),
            stats=Stats(max_hp=100.0, max_mana=0.0, max_stamina=0.0, hp_regen=0.0, mana_regen=0.0, stamina_regen=0.0, attack_power=1.0, defense=0.0, speed=120.0),
            name="wall_test",
        )
        entity.set_velocity(120.0, 0.0)
        entity.navigation_walls = [pygame.Rect(90, 80, 30, 40)]

        start_x = entity.x
        entity.update(0.1, world_rect=pygame.Rect(0, 0, 400, 400))

        self.assertEqual(entity.x, start_x)
        self.assertEqual(entity.vx, 0.0)


if __name__ == "__main__":
    unittest.main()
