import unittest

import pygame

from game.main import STATE_LOADING, STATE_TITLE, handle_loading_screen_input


class LoadingScreenInputTests(unittest.TestCase):
    def test_loading_screen_does_not_skip_on_space(self):
        event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_SPACE})

        self.assertEqual(handle_loading_screen_input(event, STATE_LOADING), STATE_LOADING)

    def test_loading_screen_returns_to_title_on_escape(self):
        event = pygame.event.Event(pygame.KEYDOWN, {"key": pygame.K_ESCAPE})

        self.assertEqual(handle_loading_screen_input(event, STATE_LOADING), STATE_TITLE)


if __name__ == "__main__":
    unittest.main()
