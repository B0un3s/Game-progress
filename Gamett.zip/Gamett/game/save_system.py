# game/save_system.py

from __future__ import annotations

import json
import os
from copy import deepcopy

from game.config import STARTING_HEALING_POTIONS
from game.player.builds import DEFAULT_CORE_STATS, STARTING_BUILD_POINTS, make_default_loadout, make_default_skill_modifiers, make_default_unlocked_skills


DEFAULT_KEYBINDS = {
    "move_up": "w",
    "move_down": "s",
    "move_left": "a",
    "move_right": "d",
    "skill_1": "q",
    "ult": "y",
    "dash": "e",
    "class_skill": "f",
    "advance_room": "space",
    "heal_potion": "h",
    "mana_potion": "j",
    "stamina_tonic": "g",
    "pause": "escape",
    "debug": "f3",
    "inventory": "b",
    "skill_tree": "k",
}


DEFAULT_SAVE = {
    "player": {
        "name": "Hunter",
        "class_id": "striker",
        "core_stats": dict(DEFAULT_CORE_STATS),
        "build_points": STARTING_BUILD_POINTS,
        "equipped_skills": make_default_loadout("striker"),
        "skill_modifiers": make_default_skill_modifiers(),
        "unlocked_skills": make_default_unlocked_skills(),
        "level": 1,
        "xp": 0,
        "gold": 0,
        "stat_points": 0,
        "skill_points": 0,
        "skill_ranks": {},
        "equipped_passives": [],
        "branch_rewards_claimed": [],
        "selected_specialization": "",
        "keybinds": dict(DEFAULT_KEYBINDS),
    },
    "progress": {
        "highest_gate_rank_cleared": "E",
        "gates_cleared": 0,
        "bosses_killed": 0,
    },
    "inventory": {
        "max_slots": 24,
        "items": [
            {
                "item_id": "healing_potion",
                "name": "Healing Potion",
                "quantity": STARTING_HEALING_POTIONS,
                "item_type": "consumable",
            },
            {
                "item_id": "mana_potion",
                "name": "Mana Potion",
                "quantity": 1,
                "item_type": "consumable",
            },
            {
                "item_id": "stamina_tonic",
                "name": "Stamina Tonic",
                "quantity": 1,
                "item_type": "consumable",
            },
        ],
    },
}


class SaveSystem:
    def __init__(self, save_path: str = "game/data/save.json"):
        self.save_path = save_path

    def exists(self) -> bool:
        return os.path.exists(self.save_path)

    def load(self) -> dict:
        if not self.exists():
            return deepcopy(DEFAULT_SAVE)

        try:
            with open(self.save_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return deepcopy(DEFAULT_SAVE)

        return self._merge_with_default(data)

    def save(self, data: dict) -> None:
        os.makedirs(os.path.dirname(self.save_path), exist_ok=True)
        with open(self.save_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def reset(self) -> None:
        self.save(deepcopy(DEFAULT_SAVE))

    def _merge_with_default(self, data: dict) -> dict:
        merged = deepcopy(DEFAULT_SAVE)
        self._deep_update(merged, data)
        return merged

    def _deep_update(self, base: dict, updates: dict) -> None:
        for key, value in updates.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_update(base[key], value)
            else:
                base[key] = value
