from __future__ import annotations

import random

from game.enemies.mob import Mob
from game.enemies.elite import Elite
from game.enemies.miniboss import MiniBoss
from game.enemies.variants import GunnerMob, ChargerMob, WispMob


RANK_ELITE_CHANCE = {
    "E": 0.00,
    "D": 0.04,
    "C": 0.08,
    "B": 0.14,
    "A": 0.20,
    "S": 0.28,
    "SS": 0.36,
    "SSS": 0.46,
    "EX": 0.58,
    "MONARCH": 0.72,
}

RANK_ARCHETYPES = {
    "E": ["raider", "raider", "skirmisher"],
    "D": ["raider", "skirmisher", "brute"],
    "C": ["raider", "skirmisher", "brute", "stalker"],
    "B": ["brute", "skirmisher", "stalker"],
    "A": ["brute", "stalker", "skirmisher"],
    "S": ["brute", "stalker", "skirmisher", "stalker"],
    "SS": ["brute", "stalker", "stalker", "skirmisher"],
    "SSS": ["brute", "stalker", "stalker"],
    "EX": ["brute", "stalker", "stalker"],
    "MONARCH": ["brute", "stalker", "stalker"],
}

RANK_AFFIX_COUNTS = {
    "E": (0, 0),
    "D": (0, 1),
    "C": (0, 1),
    "B": (0, 1),
    "A": (1, 1),
    "S": (1, 1),
    "SS": (1, 2),
    "SSS": (1, 2),
    "EX": (1, 2),
    "MONARCH": (2, 2),
}

AFFIX_POOL = ("frenzied", "warded", "volatile", "draining")

RANK_VARIANTS = {
    "E": [("mob", 8), ("gunner", 1)],
    "D": [("mob", 7), ("gunner", 2), ("charger", 1)],
    "C": [("mob", 5), ("gunner", 2), ("charger", 2), ("wisp", 1)],
    "B": [("mob", 4), ("gunner", 2), ("charger", 2), ("wisp", 2)],
    "A": [("mob", 3), ("gunner", 3), ("charger", 2), ("wisp", 2)],
    "S": [("mob", 2), ("gunner", 3), ("charger", 3), ("wisp", 2)],
    "SS": [("gunner", 3), ("charger", 3), ("wisp", 3), ("mob", 1)],
    "SSS": [("gunner", 3), ("charger", 3), ("wisp", 4)],
    "EX": [("gunner", 3), ("charger", 4), ("wisp", 4)],
    "MONARCH": [("gunner", 3), ("charger", 4), ("wisp", 5)],
}


def roll_affixes(rank: str, elite: bool) -> tuple[str, ...]:
    rank = str(rank).upper()
    min_count, max_count = RANK_AFFIX_COUNTS.get(rank, (0, 1))
    if elite:
        max_count = min(len(AFFIX_POOL), max_count + 1)
        min_count = min(max_count, min_count + (1 if rank not in {"E", "D"} else 0))
    count = random.randint(min_count, max_count)
    if count <= 0:
        return ()
    return tuple(random.sample(AFFIX_POOL, count))


def create_enemy(x: float, y: float, rank: str = "C", name: str = "Mob", roll: float = 0.0):
    rank = str(rank).upper()
    chance = RANK_ELITE_CHANCE.get(rank, 0.08)
    archetypes = RANK_ARCHETYPES.get(rank, ["raider"])
    archetype = random.choice(archetypes)
    variant_choices = RANK_VARIANTS.get(rank, [("mob", 1)])
    variant = random.choices([v for v, _ in variant_choices], weights=[w for _, w in variant_choices], k=1)[0]
    prefix = archetype.title()
    elite = roll < chance
    affixes = roll_affixes(rank, elite)
    affix_prefix = "".join(f"{affix.title()}_" for affix in affixes)
    full_name = f"{affix_prefix}{prefix}_{name}"
    if elite:
        return Elite(x, y, name=f"Elite_{affix_prefix}{prefix}_{name}", archetype=archetype, affixes=affixes)
    if variant == "gunner":
        return GunnerMob(x, y, name=f"Gunner_{full_name}", archetype=archetype, affixes=affixes)
    if variant == "charger":
        return ChargerMob(x, y, name=f"Charger_{full_name}", archetype=archetype, affixes=affixes)
    if variant == "wisp":
        return WispMob(x, y, name=f"Wisp_{full_name}", archetype=archetype, affixes=affixes)
    return Mob(x, y, name=full_name, archetype=archetype, affixes=affixes)


def create_miniboss(x: float, y: float, rank: str = "C", name: str = "MiniBoss"):
    rank = str(rank).upper()
    archetypes = RANK_ARCHETYPES.get(rank, ["brute"])
    archetype = random.choice(archetypes)
    affixes = roll_affixes(rank, elite=True)
    affix_prefix = "".join(f"{affix.title()}_" for affix in affixes)
    return MiniBoss(x, y, name=f"Mini_{affix_prefix}{archetype.title()}_{name}", archetype=archetype, affixes=affixes)


def create_variant_enemy(
    variant: str,
    x: float,
    y: float,
    rank: str = "C",
    name: str = "Mob",
    elite: bool = False,
):
    rank = str(rank).upper()
    archetypes = RANK_ARCHETYPES.get(rank, ["raider"])
    archetype = random.choice(archetypes)
    affixes = roll_affixes(rank, elite)
    affix_prefix = "".join(f"{affix.title()}_" for affix in affixes)
    full_name = f"{affix_prefix}{archetype.title()}_{name}"
    if elite:
        return Elite(x, y, name=f"Elite_{full_name}", archetype=archetype, affixes=affixes)
    if variant == "gunner":
        return GunnerMob(x, y, name=f"Gunner_{full_name}", archetype=archetype, affixes=affixes)
    if variant == "charger":
        return ChargerMob(x, y, name=f"Charger_{full_name}", archetype=archetype, affixes=affixes)
    if variant == "wisp":
        return WispMob(x, y, name=f"Wisp_{full_name}", archetype=archetype, affixes=affixes)
    return Mob(x, y, name=full_name, archetype=archetype, affixes=affixes)
