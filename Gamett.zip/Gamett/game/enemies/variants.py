from __future__ import annotations

import random

import pygame

from game.config import ENEMY_ATTACK_COOLDOWN
from game.enemies.mob import Mob
from game.enemies.projectiles import EnemyProjectile


class GunnerMob(Mob):
    def __init__(self, x: float, y: float, name: str = "Gunner", archetype: str = "skirmisher", affixes: tuple[str, ...] = ()):
        super().__init__(x, y, name=name, archetype=archetype, affixes=affixes)
        self.variant = "gunner"
        self.refresh_learning_identity()
        self.damage *= 0.88
        self.base_speed *= 0.96
        self.attack_range = max(self.attack_range * 3.1, 170.0)
        self.preferred_range = self.attack_range * 0.78
        self.color = (255, 198, 110)
        self.stats.speed = self.base_speed
        self.projectiles: list[EnemyProjectile] = []

    def update(self, dt: float, world_rect: pygame.Rect | None = None) -> None:
        self.cooldowns.update(dt)
        self._update_projectiles(dt, world_rect)

        if not self.alive:
            self.persist_learning()
            super().update(dt, world_rect)
            return

        if self.target is not None and self.target.alive:
            dist = self.distance_to(self.target)
            self.memory.observe_tick(dist, dt)
            self.ai.observe_player(self.target)
            self._adapt_behavior()
            preferred_range = self.preferred_range
            if self.behavior_mode == "rushdown":
                preferred_range *= 0.82
            elif self.behavior_mode == "bait":
                preferred_range *= 1.18
            if dist < preferred_range * 0.65:
                self.move_away_from(self.target.x, self.target.y, self._current_speed() * 0.95)
            elif self.behavior_mode in {"trap", "cutoff"}:
                self.ai.apply_behavior(self, self.target, "cutoff" if self.behavior_mode == "cutoff" else "trap")
            elif dist > preferred_range:
                if self.behavior_mode == "rushdown":
                    self.ai.apply_behavior(self, self.target, "rush")
                else:
                    self.move_toward(self.target.x, self.target.y, self._current_speed() * 0.82)
            else:
                self.stop()
                self.try_attack_target()
        else:
            self.stop()

        super(Mob, self).update(dt, world_rect)

    def try_attack_target(self) -> bool:
        if self.target is None or not self.target.alive:
            return False
        if self.distance_to(self.target) > self.attack_range:
            return False
        if not self.cooldowns.ready("attack"):
            return False

        self.cooldowns.set("attack", self._current_attack_cooldown() * 1.15)
        dir_x, dir_y = self.normalize(self.target.x - self.x, self.target.y - self.y)
        spawn_x = self.x + dir_x * (self.radius + 6)
        spawn_y = self.y + dir_y * (self.radius + 6)
        self.projectiles.append(
            EnemyProjectile(
                spawn_x,
                spawn_y,
                dir_x,
                dir_y,
                speed=420.0,
                damage=self._current_attack_damage() * self.stats.attack_power * 0.92,
                radius=6.0,
                max_distance=self.attack_range + 55.0,
                color=(255, 196, 118),
            )
        )
        dealt = 0.0
        if dealt > 0 and "draining" in self.affixes:
            self.heal(dealt * 0.12)
        return True

    def _update_projectiles(self, dt: float, world_rect: pygame.Rect | None) -> None:
        if self.target is None:
            return
        remaining: list[EnemyProjectile] = []
        wall_rects = getattr(self, "navigation_walls", [])
        for projectile in self.projectiles:
            projectile.update(dt, world_rect, wall_rects)
            if not projectile.alive:
                continue
            if projectile.collides_with(self.target):
                dealt = self.target.take_damage(projectile.damage)
                if dealt > 0 and "draining" in self.affixes:
                    self.heal(dealt * 0.12)
                projectile.alive = False
            if projectile.alive:
                remaining.append(projectile)
        self.projectiles = remaining

    def draw(self, surface: pygame.Surface, cam_x: float = 0.0, cam_y: float = 0.0, draw_hp_bar: bool = True) -> None:
        super().draw(surface, cam_x, cam_y, draw_hp_bar)
        for projectile in self.projectiles:
            projectile.draw(surface, cam_x, cam_y)


class ChargerMob(Mob):
    def __init__(self, x: float, y: float, name: str = "Charger", archetype: str = "brute", affixes: tuple[str, ...] = ()):
        super().__init__(x, y, name=name, archetype=archetype, affixes=affixes)
        self.variant = "charger"
        self.refresh_learning_identity()
        self.charge_speed = self.base_speed * 2.2
        self.charge_timer = 0.0
        self.charge_cooldown = 2.8
        self.damage *= 1.1
        self.color = (255, 132, 86)

    def update(self, dt: float, world_rect: pygame.Rect | None = None) -> None:
        self.cooldowns.update(dt)
        self.charge_timer = max(0.0, self.charge_timer - dt)

        if not self.alive:
            self.persist_learning()
            super().update(dt, world_rect)
            return

        if self.target is not None and self.target.alive:
            dist = self.distance_to(self.target)
            self.memory.observe_tick(dist, dt)
            self.ai.observe_player(self.target)
            self._adapt_behavior()
            if dist > self.attack_range * 1.4 and self.charge_timer <= 0:
                self.move_toward(self.target.x, self.target.y, self.charge_speed * (1.08 if self.behavior_mode in {"rushdown", "cutoff"} else 1.0))
                if dist < self.attack_range * 2.4:
                    self.charge_timer = self.charge_cooldown
            elif self.behavior_mode == "cutoff":
                self.ai.apply_behavior(self, self.target, "cutoff")
            elif dist > self.attack_range:
                if self.behavior_mode == "rushdown":
                    self.ai.apply_behavior(self, self.target, "rush")
                else:
                    self.move_toward(self.target.x, self.target.y, self._current_speed())
            else:
                self.stop()
                self.try_attack_target()
        else:
            self.stop()

        super(Mob, self).update(dt, world_rect)

    def try_attack_target(self) -> bool:
        if self.target is None or not self.target.alive:
            return False
        if self.distance_to(self.target) > self.attack_range * 1.08:
            return False
        if not self.cooldowns.ready("attack"):
            return False

        damage_mult = 1.4 if self.charge_timer > self.charge_cooldown - 0.25 else 1.0
        self.cooldowns.set("attack", self._current_attack_cooldown() * 1.25)
        dealt = self.target.take_damage(self._current_attack_damage() * self.stats.attack_power * damage_mult)
        if dealt > 0 and "draining" in self.affixes:
            self.heal(dealt * 0.16)
        return True


class WispMob(Mob):
    def __init__(self, x: float, y: float, name: str = "Wisp", archetype: str = "stalker", affixes: tuple[str, ...] = ()):
        super().__init__(x, y, name=name, archetype=archetype, affixes=affixes)
        self.variant = "wisp"
        self.refresh_learning_identity()
        self.phase_timer = random.uniform(0.6, 1.6)
        self.damage *= 0.82
        self.base_speed *= 1.14
        self.attack_range = max(self.attack_range * 1.45, 78.0)
        self.color = (152, 210, 255)
        self.stats.max_hp *= 0.76
        self.stats.hp = self.stats.max_hp
        self.stats.speed = self.base_speed
        self.projectiles: list[EnemyProjectile] = []

    def update(self, dt: float, world_rect: pygame.Rect | None = None) -> None:
        self.cooldowns.update(dt)
        self.phase_timer -= dt
        self._update_projectiles(dt, world_rect)

        if not self.alive:
            self.persist_learning()
            super().update(dt, world_rect)
            return

        if self.target is not None and self.target.alive:
            dist = self.distance_to(self.target)
            self.memory.observe_tick(dist, dt)
            self.ai.observe_player(self.target)
            self._adapt_behavior()
            if self.phase_timer <= 0:
                preferred = self.memory.preferred_dodge_direction()
                if self.behavior_mode == "cutoff" and preferred == "left":
                    offset_x = -70
                elif self.behavior_mode == "cutoff" and preferred == "right":
                    offset_x = 70
                else:
                    offset_x = random.choice((-70, -40, 40, 70))
                offset_y = random.choice((-55, -20, 20, 55))
                self.set_position(self.target.x + offset_x, self.target.y + offset_y)
                self.phase_timer = random.uniform(1.2, 2.0)
            elif self.behavior_mode == "bait" and dist < self.attack_range * 0.72:
                self.move_away_from(self.target.x, self.target.y, self._current_speed())
            elif dist > self.attack_range:
                if self.behavior_mode == "rushdown":
                    self.ai.apply_behavior(self, self.target, "rush")
                else:
                    self.move_toward(self.target.x, self.target.y, self._current_speed() * 1.08)
            else:
                self.stop()
                self.try_attack_target()
        else:
            self.stop()

        super(Mob, self).update(dt, world_rect)

    def try_attack_target(self) -> bool:
        if self.target is None or not self.target.alive:
            return False
        if self.distance_to(self.target) > self.attack_range:
            return False
        if not self.cooldowns.ready("attack"):
            return False

        self.cooldowns.set("attack", self._current_attack_cooldown() * 0.92)
        dir_x, dir_y = self.normalize(self.target.x - self.x, self.target.y - self.y)
        self.projectiles.append(
            EnemyProjectile(
                self.x + dir_x * (self.radius + 4),
                self.y + dir_y * (self.radius + 4),
                dir_x,
                dir_y,
                speed=330.0,
                damage=self._current_attack_damage() * self.stats.attack_power,
                radius=5.0,
                max_distance=self.attack_range + 30.0,
                color=(168, 226, 255),
            )
        )
        dealt = 0.0
        if dealt > 0 and "draining" in self.affixes:
            self.heal(dealt * 0.1)
        return True

    def _update_projectiles(self, dt: float, world_rect: pygame.Rect | None) -> None:
        if self.target is None:
            return
        remaining: list[EnemyProjectile] = []
        wall_rects = getattr(self, "navigation_walls", [])
        for projectile in self.projectiles:
            projectile.update(dt, world_rect, wall_rects)
            if not projectile.alive:
                continue
            if projectile.collides_with(self.target):
                dealt = self.target.take_damage(projectile.damage)
                if dealt > 0 and "draining" in self.affixes:
                    self.heal(dealt * 0.10)
                projectile.alive = False
            if projectile.alive:
                remaining.append(projectile)
        self.projectiles = remaining

    def draw(self, surface: pygame.Surface, cam_x: float = 0.0, cam_y: float = 0.0, draw_hp_bar: bool = True) -> None:
        super().draw(surface, cam_x, cam_y, draw_hp_bar)
        for projectile in self.projectiles:
            projectile.draw(surface, cam_x, cam_y)
