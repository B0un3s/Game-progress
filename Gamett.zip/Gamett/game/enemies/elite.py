from __future__ import annotations

from game.enemies.mob import Mob


class Elite(Mob):
    def __init__(self, x: float, y: float, name: str = "Elite", archetype: str = "raider", affixes: tuple[str, ...] = ()):
        super().__init__(x, y, name=name, archetype=archetype, affixes=affixes)
        self.radius += 4
        self.damage *= 1.45
        self.attack_range *= 1.12
        self.stats.max_hp *= 1.8
        self.stats.hp = self.stats.max_hp
        self.stats.attack_power *= 1.18
        self.base_speed *= 1.05
        self.stats.speed = self.base_speed
        self.color = (255, 120, 90)
