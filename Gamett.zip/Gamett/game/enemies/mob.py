# game/enemies/mob.py

from __future__ import annotations

import math
import random
from collections import deque

import pygame

from game.config import (
    ENEMY_RADIUS,
    ENEMY_BASE_SPEED,
    ENEMY_MAX_HP,
    ENEMY_DAMAGE,
    ENEMY_ATTACK_RANGE,
    ENEMY_ATTACK_COOLDOWN,
    RED,
)
from game.ai.adaptation import CombatMemory
from game.ai.combat_ai import CombatAI
from game.ai.global_learning import GlobalLearningDB
from game.core.entity import Entity
from game.core.stats import Stats
from game.core.cooldowns import Cooldowns


AFFIX_TAG_FONT = None
MOB_LEARNING_RATE = 0.008


class Mob(Entity):
    def __init__(
        self,
        x: float,
        y: float,
        name: str = "Mob",
        archetype: str = "raider",
        affixes: tuple[str, ...] = (),
    ):
        stats = Stats(
            max_hp=ENEMY_MAX_HP,
            max_mana=0.0,
            max_stamina=0.0,
            hp_regen=0.0,
            mana_regen=0.0,
            stamina_regen=0.0,
            attack_power=1.0,
            defense=0.0,
            speed=ENEMY_BASE_SPEED,
        )

        super().__init__(
            x=x,
            y=y,
            radius=ENEMY_RADIUS,
            color=RED,
            stats=stats,
            name=name,
        )

        self.base_speed = ENEMY_BASE_SPEED
        self.damage = ENEMY_DAMAGE
        self.attack_range = ENEMY_ATTACK_RANGE

        self.archetype = archetype
        self.affixes = tuple(affixes)

        self.cooldowns = Cooldowns()
        self.target: Entity | None = None

        self.pack_role = "pressure"
        self.pack_anchor_x = self.x
        self.pack_anchor_y = self.y
        self.pack_pressure_scale = 1.0

        self.memory = CombatMemory(learning_rate=MOB_LEARNING_RATE)
        self.ai = CombatAI()
        self.behavior_mode = "pressure"

        self.global_db = GlobalLearningDB()
        self.memory_id = self._make_memory_id()
        self.global_db.register_encounter(self.memory_id)
        self.memory.load_from_dict(self.global_db.get_entity_memory(self.memory_id))
        self._learning_persisted = False

        # smarter mob brain
        self.combat_time = 0.0
        self.focus = 0.0
        self.rage = 0.0
        self.courage = random.uniform(42.0, 68.0)
        self.last_hp = self.stats.hp

        self.position_history: deque[tuple[float, float, float]] = deque(maxlen=8)

        self.stuck_timer = 0.0
        self.last_position = (self.x, self.y)
        self.unstuck_angle = random.uniform(0.0, math.tau)

        self.attack_windup = 0.0
        self.attack_telegraph_timer = 0.0
        self.attack_telegraph_color = (255, 255, 255)

        self._volatile_triggered = False

        self._apply_archetype()
        self._apply_affixes()

    def _make_memory_id(self) -> str:
        affix_tag = "_".join(sorted(self.affixes)) if self.affixes else "plain"
        variant = getattr(self, "variant", "base")
        return f"mob_{variant}_{self.archetype}_{affix_tag}"

    def refresh_learning_identity(self) -> None:
        self.memory_id = self._make_memory_id()
        self.global_db.register_encounter(self.memory_id)
        self.memory.load_from_dict(self.global_db.get_entity_memory(self.memory_id))
        self._learning_persisted = False

    def _apply_archetype(self) -> None:
        if self.archetype == "brute":
            self.radius += 4
            self.stats.max_hp *= 1.45
            self.stats.hp = self.stats.max_hp
            self.damage *= 1.35
            self.base_speed *= 0.82
            self.attack_range *= 1.10
            self.color = (188, 88, 88)

        elif self.archetype == "skirmisher":
            self.stats.max_hp *= 0.86
            self.stats.hp = self.stats.max_hp
            self.damage *= 0.92
            self.base_speed *= 1.24
            self.attack_range *= 0.95
            self.color = (255, 138, 138)

        elif self.archetype == "stalker":
            self.stats.max_hp *= 0.98
            self.stats.hp = self.stats.max_hp
            self.damage *= 1.08
            self.base_speed *= 1.08
            self.attack_range *= 1.18
            self.color = (164, 70, 110)

        elif self.archetype == "charger":
            self.stats.max_hp *= 1.15
            self.stats.hp = self.stats.max_hp
            self.damage *= 1.15
            self.base_speed *= 1.06
            self.attack_range *= 0.98
            self.color = (224, 86, 74)

        elif self.archetype == "gunner":
            self.stats.max_hp *= 0.82
            self.stats.hp = self.stats.max_hp
            self.damage *= 0.88
            self.base_speed *= 0.92
            self.attack_range *= 1.55
            self.color = (255, 116, 90)

        elif self.archetype == "wisp":
            self.stats.max_hp *= 0.72
            self.stats.hp = self.stats.max_hp
            self.damage *= 0.76
            self.base_speed *= 1.36
            self.attack_range *= 1.28
            self.color = (255, 82, 154)

        self.stats.speed = self.base_speed

    def _apply_affixes(self) -> None:
        if "frenzied" in self.affixes:
            self.base_speed *= 1.12
            self.damage *= 1.08
            self.courage += 12.0

        if "warded" in self.affixes:
            self.stats.defense += 3.0
            self.stats.max_hp *= 1.12
            self.stats.hp = self.stats.max_hp
            self.courage += 8.0

        if "volatile" in self.affixes:
            self.radius += 2
            self.damage *= 1.04
            self.courage += 6.0

        if "draining" in self.affixes:
            self.attack_range *= 1.08

        self.stats.speed = self.base_speed

    def set_target(self, target: Entity) -> None:
        self.target = target

    def set_coordination(
        self,
        role: str = "pressure",
        *,
        anchor_x: float | None = None,
        anchor_y: float | None = None,
        pressure_scale: float = 1.0,
    ) -> None:
        self.pack_role = str(role or "pressure")
        self.pack_anchor_x = float(self.x if anchor_x is None else anchor_x)
        self.pack_anchor_y = float(self.y if anchor_y is None else anchor_y)
        self.pack_pressure_scale = max(0.75, min(1.45, float(pressure_scale)))

    def update(self, dt: float, world_rect: pygame.Rect | None = None) -> None:
        self.cooldowns.update(dt)
        self.combat_time += dt
        self.attack_windup = max(0.0, self.attack_windup - dt)
        self.attack_telegraph_timer = max(0.0, self.attack_telegraph_timer - dt)

        if not self.alive:
            self.persist_learning()
            super().update(dt, world_rect)
            return

        self._update_emotions(dt)
        self._detect_stuck(dt)

        if self.target is not None and self.target.alive:
            dist = self.distance_to(self.target)

            self.memory.observe_tick(dist, dt)
            self.ai.observe_player(self.target)
            self._track_target()
            self._adapt_behavior()

            if self.attack_windup > 0:
                self.stop()
            else:
                self._smart_movement(dist)

            self.try_attack_target()

        else:
            self.stop()

        super().update(dt, world_rect)

    def _update_emotions(self, dt: float) -> None:
        damage_taken = max(0.0, self.last_hp - self.stats.hp)
        self.last_hp = self.stats.hp

        if damage_taken > 0:
            self.rage = min(100.0, self.rage + damage_taken * 0.12)
            self.courage = max(0.0, self.courage - damage_taken * 0.05)
        else:
            self.focus = min(100.0, self.focus + dt * 1.8)

        if self.target is not None and self.target.alive:
            dist = self.distance_to(self.target)

            if dist <= self.attack_range * 1.2:
                self.courage = min(100.0, self.courage + dt * 0.8)

            if self.stats.hp_ratio < 0.28 and "frenzied" not in self.affixes:
                self.courage = max(0.0, self.courage - dt * 4.0)

    def _track_target(self) -> None:
        if self.target is None:
            return

        self.position_history.append((self.target.x, self.target.y, self.combat_time))

    def _predict_target_position(self, amount: float = 0.32) -> tuple[float, float]:
        if self.target is None:
            return self.x, self.y

        if len(self.position_history) < 2:
            return self.target.x, self.target.y

        x1, y1, t1 = self.position_history[-2]
        x2, y2, t2 = self.position_history[-1]
        delta = max(0.001, t2 - t1)

        vx = (x2 - x1) / delta
        vy = (y2 - y1) / delta

        amount *= 1.0 + self.focus / 180.0

        return self.target.x + vx * amount, self.target.y + vy * amount

    def _detect_stuck(self, dt: float) -> None:
        lx, ly = self.last_position
        moved = math.hypot(self.x - lx, self.y - ly)

        if moved < 1.2:
            self.stuck_timer += dt
        else:
            self.stuck_timer = max(0.0, self.stuck_timer - dt * 2.0)

        self.last_position = (self.x, self.y)

        if self.stuck_timer > 0.45:
            self.unstuck_angle += random.uniform(0.7, 1.6)
            self.stuck_timer = 0.18

    def _unstuck_target(self) -> tuple[float, float]:
        return (
            self.x + math.cos(self.unstuck_angle) * 120.0,
            self.y + math.sin(self.unstuck_angle) * 120.0,
        )

    def _adapt_behavior(self) -> None:
        profile = CombatMemory.blended_profile(
            (self.global_db.get_player_profile_memory(), 0.55),
            (self.memory.to_dict(), 1.10),
            learning_rate=MOB_LEARNING_RATE,
        )

        if self.stats.hp_ratio < 0.22 and self.courage < 32 and "frenzied" not in self.affixes:
            self.behavior_mode = "retreat"
        elif self.rage >= 75 or "frenzied" in self.affixes:
            self.behavior_mode = "rushdown"
        elif profile["punish"] == "high" and profile["preferred_dodge"] in {"left", "right"}:
            self.behavior_mode = "cutoff"
        elif profile["range_denial"] == "high" or profile["dominant_range"] == "long":
            self.behavior_mode = "rushdown"
        elif profile["burst_denial"] == "high" or profile["burst"] == "high":
            self.behavior_mode = "bait"
        elif profile["mobility"] == "high":
            self.behavior_mode = "trap"
        elif profile["aggression"] == "high":
            self.behavior_mode = "pressure"
        else:
            self.behavior_mode = "read"

    def _smart_movement(self, dist: float) -> None:
        if self.target is None:
            self.stop()
            return

        desired_range = self._desired_range()
        speed = self._current_speed()

        if self.stuck_timer > 0.12:
            ux, uy = self._unstuck_target()
            self.move_toward(ux, uy, speed * 1.15)
            return

        predicted_x, predicted_y = self._predict_target_position()

        if self.behavior_mode == "retreat":
            self.move_away_from(self.target.x, self.target.y, speed * 1.1)
            return

        if self.archetype == "stalker" and dist < self.attack_range * 0.75 and self.cooldowns.remaining("attack") > 0:
            self.move_away_from(self.target.x, self.target.y, speed * 0.86)
            return

        if self.pack_role == "anchor":
            if dist < desired_range * 0.9:
                self.move_away_from(self.target.x, self.target.y, speed * 0.78)
            elif dist > desired_range * 1.18:
                self.move_toward(predicted_x, predicted_y, speed * 0.82)
            else:
                self.stop()
            return

        if self.pack_role == "flank":
            self._move_as_flanker(dist, desired_range, speed)
            return

        if self.pack_role == "intercept":
            self._move_as_interceptor(dist, desired_range, speed)
            return

        if self.behavior_mode == "bait" and dist < desired_range * 0.78:
            self.move_away_from(self.target.x, self.target.y, speed * 0.9)
            return

        if self.behavior_mode in {"trap", "cutoff"} and dist <= desired_range * 1.25:
            self._circle_target(speed * 0.82)
            return

        if dist > desired_range:
            if self.behavior_mode == "rushdown":
                self.move_toward(predicted_x, predicted_y, speed * 1.05)
            else:
                self.move_toward(self.target.x, self.target.y, speed)
        else:
            self.stop()

    def _move_as_flanker(self, dist: float, desired_range: float, speed: float) -> None:
        if self.target is None:
            return

        dx = self.pack_anchor_x - self.target.x
        dy = self.pack_anchor_y - self.target.y
        length = math.hypot(dx, dy) or 1.0

        dx /= length
        dy /= length

        side = -1 if hash(self.name) % 2 == 0 else 1

        flank_x = self.target.x + (-dy * side) * desired_range * 1.15
        flank_y = self.target.y + (dx * side) * desired_range * 1.15

        if dist > desired_range * 0.82:
            self.move_toward(flank_x, flank_y, speed * 1.05)
        else:
            self._circle_target(speed * 0.72)

    def _move_as_interceptor(self, dist: float, desired_range: float, speed: float) -> None:
        predicted_x, predicted_y = self._predict_target_position(0.52)

        if dist > desired_range * 0.72:
            self.move_toward(predicted_x, predicted_y, speed * 1.08)
        else:
            self.stop()

    def _circle_target(self, speed: float) -> None:
        if self.target is None:
            return

        dx = self.x - self.target.x
        dy = self.y - self.target.y
        length = math.hypot(dx, dy)

        if length <= 0.001:
            self.stop()
            return

        dx /= length
        dy /= length

        direction = -1 if (self.combat_time + hash(self.name) % 5) % 4 < 2 else 1

        tx = -dy * direction
        ty = dx * direction

        self.move_toward(self.x + tx * 96.0, self.y + ty * 96.0, speed)

    def _preferred_engage_range(self) -> float:
        desired_range = self.attack_range

        if self.archetype in {"brute", "raider", "charger"}:
            desired_range *= 1.08
        elif self.archetype in {"skirmisher", "stalker"}:
            desired_range *= 0.9
        elif self.archetype in {"wisp", "gunner"}:
            desired_range *= 1.28

        if self.behavior_mode == "rushdown":
            desired_range *= 0.86
        elif self.behavior_mode == "bait":
            desired_range *= 1.16
        elif self.behavior_mode == "trap":
            desired_range *= 1.08
        elif self.behavior_mode == "retreat":
            desired_range *= 1.55

        return desired_range

    def _desired_range(self) -> float:
        desired_range = self._preferred_engage_range()

        if self.archetype == "stalker" and self.cooldowns.remaining("attack") > 0:
            desired_range = max(desired_range, self.attack_range * 1.18)

        if self.pack_role == "anchor":
            desired_range *= 1.18
        elif self.pack_role == "flank":
            desired_range *= 0.96
        elif self.pack_role == "intercept":
            desired_range *= 0.88

        return desired_range

    def _current_speed(self) -> float:
        speed = self.base_speed

        if self.behavior_mode == "rushdown":
            speed *= 1.18
        elif self.behavior_mode == "trap":
            speed *= 1.08
        elif self.behavior_mode == "cutoff":
            speed *= 1.13
        elif self.behavior_mode == "bait":
            speed *= 0.95
        elif self.behavior_mode == "retreat":
            speed *= 1.22

        if self.pack_role == "flank":
            speed *= 1.09
        elif self.pack_role == "intercept":
            speed *= 1.13
        elif self.pack_role == "anchor":
            speed *= 0.92

        if "frenzied" in self.affixes:
            speed *= 1.06

        speed *= self.pack_pressure_scale
        speed *= 1.0 + self.rage / 600.0

        return speed

    def _current_attack_damage(self) -> float:
        damage = self.damage

        if self.behavior_mode == "pressure":
            damage *= 1.04
        elif self.behavior_mode == "trap":
            damage *= 1.08
        elif self.behavior_mode == "cutoff":
            damage *= 1.10
        elif self.behavior_mode == "rushdown":
            damage *= 1.06
        elif self.behavior_mode == "retreat":
            damage *= 0.8

        if self.pack_role == "anchor":
            damage *= 1.08
        elif self.pack_role == "intercept":
            damage *= 1.06

        if "frenzied" in self.affixes:
            damage *= 1.08

        damage *= 1.0 + self.rage / 700.0

        return damage

    def _current_attack_cooldown(self) -> float:
        cooldown = ENEMY_ATTACK_COOLDOWN

        if self.behavior_mode == "rushdown":
            cooldown *= 0.9
        elif self.behavior_mode == "trap":
            cooldown *= 0.94
        elif self.behavior_mode == "cutoff":
            cooldown *= 0.88
        elif self.behavior_mode == "bait":
            cooldown *= 1.08
        elif self.behavior_mode == "retreat":
            cooldown *= 1.2

        if self.archetype == "brute":
            cooldown *= 1.12
        elif self.archetype in {"skirmisher", "wisp"}:
            cooldown *= 0.88

        if "frenzied" in self.affixes:
            cooldown *= 0.86

        return max(0.35, cooldown)

    def _windup_time(self) -> float:
        if self.archetype == "brute":
            return 0.18
        if self.archetype in {"skirmisher", "wisp"}:
            return 0.05
        if self.archetype == "gunner":
            return 0.12
        return 0.09

    def try_attack_target(self) -> bool:
        if self.target is None or not self.target.alive:
            return False

        if self.distance_to(self.target) > self.attack_range:
            return False

        if not self.cooldowns.ready("attack"):
            return False

        if self.attack_windup <= 0 and self.attack_telegraph_timer <= 0:
            self.attack_windup = self._windup_time()
            self.attack_telegraph_timer = self.attack_windup + 0.08
            self.attack_telegraph_color = self._affix_color()
            return False

        self.cooldowns.set("attack", self._current_attack_cooldown())

        dealt = self.target.take_damage(self._current_attack_damage() * self.stats.attack_power)

        if dealt > 0:
            self.focus = min(100.0, self.focus + 3.0)

            if "draining" in self.affixes:
                self.heal(dealt * 0.18)

        self.attack_windup = 0.0
        self.attack_telegraph_timer = 0.0

        return True

    def take_damage(self, amount: float) -> float:
        dealt = super().take_damage(amount)

        if dealt > 0:
            self.rage = min(100.0, self.rage + dealt * 0.08)
            self.focus = min(100.0, self.focus + dealt * 0.04)

        if (
            not self.alive
            and "volatile" in self.affixes
            and not self._volatile_triggered
            and self.target is not None
            and self.distance_to(self.target) <= 78
        ):
            self._volatile_triggered = True
            self.target.take_damage(self.damage * 0.7)

        if not self.alive:
            self.persist_learning()

        return dealt

    def persist_learning(self) -> None:
        if self._learning_persisted:
            return

        self.global_db.merge_entity_memory(self.memory_id, self.memory.to_dict())

        if not self.alive:
            self.global_db.register_kill(self.memory_id)

        self.global_db.save()
        self._learning_persisted = True

    def record_player_basic_attack(self) -> None:
        self.memory.record_basic_attack()
        self.focus = min(100.0, self.focus + 0.8)

    def record_player_skill_1(self) -> None:
        self.memory.record_skill_1()
        self.focus = min(100.0, self.focus + 2.2)

    def record_player_ult(self) -> None:
        self.memory.record_ult()
        self.rage = min(100.0, self.rage + 12.0)
        self.focus = min(100.0, self.focus + 10.0)

    def record_player_dash(self, direction: str = "back") -> None:
        self.memory.record_dash(direction)
        self.focus = min(100.0, self.focus + 1.5)

    def _affix_color(self) -> tuple[int, int, int]:
        if "volatile" in self.affixes:
            return (255, 146, 92)
        if "warded" in self.affixes:
            return (112, 174, 255)
        if "draining" in self.affixes:
            return (176, 104, 214)
        if "frenzied" in self.affixes:
            return (255, 108, 108)
        return (255, 255, 255)

    def get_debug_state(self) -> dict:
        profile = CombatMemory.blended_profile(
            (self.global_db.get_player_profile_memory(), 0.55),
            (self.memory.to_dict(), 1.10),
            learning_rate=MOB_LEARNING_RATE,
        )

        return {
            "hp": round(self.stats.hp, 1),
            "archetype": self.archetype,
            "affixes": list(self.affixes),
            "mode": self.behavior_mode,
            "role": self.pack_role,
            "rage": round(self.rage, 1),
            "focus": round(self.focus, 1),
            "courage": round(self.courage, 1),
            "range": profile["dominant_range"],
            "mobility": profile["mobility"],
            "attack_cd": round(self.cooldowns.remaining("attack"), 2),
            "stuck": round(self.stuck_timer, 2),
            "has_target": self.target is not None and self.target.alive,
        }

    def draw(
        self,
        surface: pygame.Surface,
        cam_x: float = 0.0,
        cam_y: float = 0.0,
        draw_hp_bar: bool = True,
    ) -> None:
        super().draw(surface, cam_x, cam_y, draw_hp_bar)

        if not self.alive:
            return

        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)

        role_colors = {
            "pressure": (255, 112, 112),
            "flank": (112, 196, 255),
            "anchor": (255, 214, 112),
            "intercept": (188, 120, 255),
        }

        role_color = role_colors.get(self.pack_role, (255, 255, 255))
        pygame.draw.circle(surface, role_color, (sx, sy), int(self.radius + 7), 1)

        if self.behavior_mode == "retreat":
            pygame.draw.circle(surface, (120, 200, 255), (sx, sy), int(self.radius + 10), 1)

        if self.rage >= 70:
            pygame.draw.circle(surface, (255, 60, 60), (sx, sy), int(self.radius + 12), 2)

        if self.attack_telegraph_timer > 0:
            pygame.draw.circle(
                surface,
                self.attack_telegraph_color,
                (sx, sy),
                int(self.radius + 15),
                2,
            )

        if self.pack_role != "pressure":
            marker_y = sy - int(self.radius) - 8

            if self.pack_role == "flank":
                pygame.draw.circle(surface, role_color, (sx, marker_y), 3)

            elif self.pack_role == "anchor":
                pygame.draw.rect(
                    surface,
                    role_color,
                    (sx - 4, marker_y - 3, 8, 6),
                    border_radius=2,
                )

            elif self.pack_role == "intercept":
                pygame.draw.polygon(
                    surface,
                    role_color,
                    [
                        (sx, marker_y - 4),
                        (sx - 4, marker_y + 3),
                        (sx + 4, marker_y + 3),
                    ],
                )

        if self.affixes:
            ring_color = self._affix_color()
            pygame.draw.circle(surface, ring_color, (sx, sy), int(self.radius + 4), 2)

            tag_y = sy - int(self.radius) - 24

            for i, affix in enumerate(self.affixes[:2]):
                label = affix[:3].upper()
                pill = pygame.Rect(sx - 28 + i * 30, tag_y, 26, 14)

                pygame.draw.rect(surface, ring_color, pill, border_radius=7)

                global AFFIX_TAG_FONT
                if AFFIX_TAG_FONT is None:
                    AFFIX_TAG_FONT = pygame.font.SysFont("trebuchetms", 11, bold=True)

                img = AFFIX_TAG_FONT.render(label, True, (12, 16, 24))
                rect = img.get_rect(center=pill.center)
                surface.blit(img, rect)