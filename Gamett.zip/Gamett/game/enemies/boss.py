# game/enemies/boss.py

from __future__ import annotations

import math
import random
from collections import defaultdict, deque

import pygame

from game.config import (
    BOSS_RADIUS,
    BOSS_BASE_SPEED,
    BOSS_MAX_HP,
    BOSS_DAMAGE,
    BOSS_ATTACK_RANGE,
    BOSS_ATTACK_COOLDOWN,
    PURPLE,
    BOSS_LEARNING_RATE,
)
from game.core.entity import Entity
from game.core.stats import Stats
from game.core.cooldowns import Cooldowns
from game.ai.adaptation import CombatMemory
from game.ai.global_learning import GlobalLearningDB


class Boss(Entity):
    def __init__(self, x: float, y: float, name: str = "Boss", style: str = "crusher"):
        stats = Stats(
            max_hp=BOSS_MAX_HP,
            max_mana=0.0,
            max_stamina=0.0,
            hp_regen=0.0,
            mana_regen=0.0,
            stamina_regen=0.0,
            attack_power=1.15,
            defense=2.0,
            speed=BOSS_BASE_SPEED,
        )

        super().__init__(
            x=x,
            y=y,
            radius=BOSS_RADIUS,
            color=PURPLE,
            stats=stats,
            name=name,
        )

        self.base_speed = BOSS_BASE_SPEED
        self.damage = BOSS_DAMAGE
        self.attack_range = BOSS_ATTACK_RANGE
        self.base_defense = stats.defense

        self.cooldowns = Cooldowns()
        self.target: Entity | None = None

        self.memory = CombatMemory(learning_rate=BOSS_LEARNING_RATE)
        self.ai_profile: dict = {}

        self.phase = 1
        self.behavior_mode = "pressure"
        self.style = style
        self.attack_pattern = "brutal_standard"
        self.summon_doctrine = "balanced"
        self.world_insight = "low"

        self.telegraph_timer = 0.0
        self.telegraph_color = (255, 255, 255)

        self.summon_cooldown = 0.0
        self.pending_summons: list[dict] = []

        self.boss_id = f"boss_{self.style}_{self.name.lower().replace(' ', '_')}"
        self.global_db = GlobalLearningDB()
        self.global_db.register_encounter(self.boss_id)
        self.memory.load_from_dict(self.global_db.get_boss_memory(self.boss_id))
        self._learning_persisted = False

        # Advanced AI
        self.rage = 0.0
        self.focus = 0.0
        self.confidence = 50.0
        self.last_hp = self.stats.hp

        self.position_history: deque[tuple[float, float, float]] = deque(maxlen=10)
        self.player_heatmap: dict[tuple[int, int], float] = defaultdict(float)
        self.heatmap_cell_size = 120

        self.feint_chance = 0.08
        self.fake_attack_timer = 0.0
        self.combat_time = 0.0

        self._apply_style()

    def _apply_style(self) -> None:
        if self.style == "hunter":
            self.base_speed *= 1.16
            self.attack_range *= 0.9
            self.damage *= 0.92
            self.color = (132, 112, 255)
            self.feint_chance += 0.08
        elif self.style == "ritualist":
            self.base_speed *= 0.92
            self.attack_range *= 1.22
            self.damage *= 1.08
            self.color = (196, 94, 255)
        else:
            self.damage *= 1.14
            self.stats.max_hp *= 1.1
            self.stats.hp = self.stats.max_hp

    def set_target(self, target: Entity) -> None:
        self.target = target

    def update(self, dt: float, world_rect: pygame.Rect | None = None) -> None:
        self.cooldowns.update(dt)
        self.summon_cooldown = max(0.0, self.summon_cooldown - dt)
        self.telegraph_timer = max(0.0, self.telegraph_timer - dt)
        self.fake_attack_timer = max(0.0, self.fake_attack_timer - dt)
        self.combat_time += dt

        if not self.alive:
            super().update(dt, world_rect)
            return

        self._update_emotional_state(dt)
        self._update_phase()

        if self.target is not None and self.target.alive:
            dist = self.distance_to(self.target)

            self.memory.observe_tick(dist, dt)
            self._track_player(dt)
            self._adapt_behavior()

            self.stats.defense = self._current_defense()
            self._try_prepare_summon()

            self._combat_movement(dist)

            if self.fake_attack_timer <= 0:
                if not self.try_signature_attack():
                    self.try_attack_target()
        else:
            self.stop()

        super().update(dt, world_rect)

    def _update_emotional_state(self, dt: float) -> None:
        damage_taken = max(0.0, self.last_hp - self.stats.hp)
        self.last_hp = self.stats.hp

        self.rage = min(100.0, self.rage + damage_taken * 0.18)
        self.focus = min(100.0, self.focus + dt * 2.2)

        if damage_taken > 0:
            self.confidence = max(0.0, self.confidence - damage_taken * 0.08)
        elif self.target is not None and self.target.alive:
            if self.distance_to(self.target) <= self.attack_range * 1.25:
                self.confidence = min(100.0, self.confidence + dt * 1.5)

    def _track_player(self, dt: float) -> None:
        if self.target is None:
            return

        self.position_history.append((self.target.x, self.target.y, self.combat_time))

        cell = (
            int(self.target.x // self.heatmap_cell_size),
            int(self.target.y // self.heatmap_cell_size),
        )

        self.player_heatmap[cell] += dt

        for key in list(self.player_heatmap.keys()):
            self.player_heatmap[key] *= 0.999
            if self.player_heatmap[key] < 0.05:
                del self.player_heatmap[key]

    def _predict_target_position(self, prediction_time: float = 0.45) -> tuple[float, float]:
        if self.target is None:
            return self.x, self.y

        if len(self.position_history) < 2:
            return self.target.x, self.target.y

        x1, y1, t1 = self.position_history[-2]
        x2, y2, t2 = self.position_history[-1]
        delta = max(0.001, t2 - t1)

        vx = (x2 - x1) / delta
        vy = (y2 - y1) / delta

        prediction_time *= 1.0 + self.focus / 160.0

        return (
            self.target.x + vx * prediction_time,
            self.target.y + vy * prediction_time,
        )

    def _update_phase(self) -> None:
        hp_ratio = self.stats.hp_ratio

        old_phase = self.phase

        if hp_ratio <= 0.32:
            self.phase = 3
        elif hp_ratio <= 0.68:
            self.phase = 2
        else:
            self.phase = 1

        if self.phase != old_phase:
            self.rage = min(100.0, self.rage + 18.0)
            self.focus = min(100.0, self.focus + 12.0)
            self.telegraph_timer = 0.65
            self.telegraph_color = (255, 80, 120)

    def _adapt_behavior(self) -> None:
        profile = self._blended_profile()
        self.ai_profile = profile

        observations = int(profile.get("observations", 0))

        if observations >= 120 or self.focus >= 80:
            self.world_insight = "high"
        elif observations >= 50 or self.focus >= 45:
            self.world_insight = "medium"
        else:
            self.world_insight = "low"

        if self.rage >= 85:
            self.behavior_mode = "berserk_pressure"
            self.attack_pattern = "rage_chain"
            self.summon_doctrine = "punishers"
            return

        if profile["punish"] == "high" and profile["preferred_dodge"] in {"left", "right"}:
            self.behavior_mode = "cutoff_pressure"
            self.attack_pattern = "intercept_combo"
            self.summon_doctrine = "punishers"
        elif profile["range_denial"] == "high" or profile["dominant_range"] == "long":
            self.behavior_mode = "anti_range"
            self.attack_pattern = "lunging_break"
            self.summon_doctrine = "hunters"
        elif profile["burst_denial"] == "high" or profile["burst"] == "high":
            self.behavior_mode = "cautious_pressure"
            self.attack_pattern = "measured_crush"
            self.summon_doctrine = "shieldwall"
        elif profile["mobility"] == "high":
            self.behavior_mode = "trap_pressure"
            self.attack_pattern = "stalk_chain"
            self.summon_doctrine = "trappers"
        else:
            self.behavior_mode = "pressure"
            self.attack_pattern = "brutal_standard"
            self.summon_doctrine = "balanced"

    def _blended_profile(self) -> dict:
        return CombatMemory.blended_profile(
            (self.global_db.get_player_profile_memory(), 0.8),
            (self.memory.to_dict(), 1.15),
            learning_rate=BOSS_LEARNING_RATE,
        )

    def _combat_movement(self, dist: float) -> None:
        if self.target is None:
            self.stop()
            return

        desired_range = self._desired_range()
        speed = self._current_speed()

        predicted_x, predicted_y = self._predict_target_position()

        if dist > desired_range * 1.1:
            self.move_toward(predicted_x, predicted_y, speed)
        elif dist < desired_range * 0.55:
            self.move_away_from(self.target.x, self.target.y, speed * 0.92)
        elif self.behavior_mode in {"trap_pressure", "cutoff_pressure"}:
            self._circle_target(speed * 0.75)
        elif self.behavior_mode == "cautious_pressure" and self.confidence < 35:
            self.move_away_from(self.target.x, self.target.y, speed * 0.55)
        else:
            self.stop()

    def _circle_target(self, speed: float) -> None:
        if self.target is None:
            return

        dx = self.x - self.target.x
        dy = self.y - self.target.y
        length = math.hypot(dx, dy)

        if length <= 0.001:
            self.stop()
            return

        dx /= length
        dy /= length

        direction = -1 if self.combat_time % 4.0 < 2.0 else 1

        tangent_x = -dy * direction
        tangent_y = dx * direction

        move_x = self.x + tangent_x * 80
        move_y = self.y + tangent_y * 80

        self.move_toward(move_x, move_y, speed)

    def _preferred_engage_range(self) -> float:
        desired_range = self.attack_range

        if self.style == "hunter":
            desired_range *= 0.86
        elif self.style == "ritualist":
            desired_range *= 1.16

        if self.behavior_mode == "anti_range":
            desired_range *= 0.9
        elif self.behavior_mode == "trap_pressure":
            desired_range *= 1.04
        elif self.behavior_mode == "cutoff_pressure":
            desired_range *= 0.84
        elif self.behavior_mode == "cautious_pressure":
            desired_range *= 1.14
        elif self.behavior_mode == "berserk_pressure":
            desired_range *= 0.78

        return desired_range

    def _desired_range(self) -> float:
        return self._preferred_engage_range()

    def _current_speed(self) -> float:
        speed = self.base_speed

        if self.phase == 2:
            speed *= 1.1
        elif self.phase == 3:
            speed *= 1.22

        if self.behavior_mode == "anti_range":
            speed *= 1.16
        elif self.behavior_mode == "trap_pressure":
            speed *= 1.1
        elif self.behavior_mode == "cutoff_pressure":
            speed *= 1.18
        elif self.behavior_mode == "berserk_pressure":
            speed *= 1.26

        speed *= 1.0 + self.rage / 420.0

        return speed

    def _current_damage(self) -> float:
        dmg = self.damage

        if self.phase == 2:
            dmg *= 1.14
        elif self.phase == 3:
            dmg *= 1.3

        if self.behavior_mode == "cautious_pressure":
            dmg *= 0.96
        elif self.behavior_mode == "trap_pressure":
            dmg *= 1.08
        elif self.behavior_mode == "cutoff_pressure":
            dmg *= 1.12
        elif self.behavior_mode == "berserk_pressure":
            dmg *= 1.22

        dmg *= 1.0 + self.rage / 500.0

        return dmg

    def _current_defense(self) -> float:
        defense = self.base_defense

        if self.behavior_mode == "cautious_pressure":
            defense += 2.7
        elif self.behavior_mode == "trap_pressure":
            defense += 1.3
        elif self.behavior_mode == "berserk_pressure":
            defense -= 0.8

        if self.world_insight == "high":
            defense += 1.1
        elif self.world_insight == "medium":
            defense += 0.45

        return max(0.0, defense)

    def _current_attack_range(self) -> float:
        attack_range = self.attack_range

        if self.attack_pattern == "lunging_break":
            attack_range *= 1.24
        elif self.attack_pattern == "intercept_combo":
            attack_range *= 1.14
        elif self.attack_pattern == "measured_crush":
            attack_range *= 1.1
        elif self.attack_pattern == "rage_chain":
            attack_range *= 1.18

        if self.phase >= 3:
            attack_range *= 1.05

        return attack_range

    def _attack_repeat_count(self) -> int:
        if self.attack_pattern == "intercept_combo":
            return 2 if self.phase >= 2 else 1
        if self.attack_pattern == "stalk_chain":
            return 2 if self.phase >= 3 else 1
        if self.attack_pattern == "rage_chain":
            return 3
        return 1

    def _current_attack_cooldown(self) -> float:
        cd = BOSS_ATTACK_COOLDOWN

        if self.phase == 2:
            cd *= 0.93
        elif self.phase == 3:
            cd *= 0.84

        if self.behavior_mode == "cautious_pressure":
            cd *= 1.06
        elif self.behavior_mode == "trap_pressure":
            cd *= 0.92
        elif self.behavior_mode == "cutoff_pressure":
            cd *= 0.86
        elif self.behavior_mode == "berserk_pressure":
            cd *= 0.72

        if self.world_insight == "high":
            cd *= 0.94

        return max(0.35, cd)

    def _signature_cooldown(self) -> float:
        cooldown = 7.8 if self.phase == 1 else 6.2 if self.phase == 2 else 5.0

        if self.world_insight == "high":
            cooldown *= 0.88
        elif self.world_insight == "medium":
            cooldown *= 0.95

        if self.behavior_mode == "berserk_pressure":
            cooldown *= 0.8

        return max(2.8, cooldown)

    def try_signature_attack(self) -> bool:
        if self.target is None or not self.target.alive:
            return False

        if not self.cooldowns.ready("signature"):
            return False

        dist = self.distance_to(self.target)
        damage = self._current_damage() * self.stats.attack_power
        attack_range = self._current_attack_range()

        if self._should_feint(dist):
            self._perform_feint()
            return True

        triggered = False

        if self.attack_pattern == "lunging_break":
            if dist <= attack_range * 1.38:
                self.target.take_damage(damage * 1.2)
                triggered = True

        elif self.attack_pattern == "intercept_combo":
            if dist <= attack_range * 1.15:
                self.target.take_damage(damage * 0.94)
                if self.target.alive and self.distance_to(self.target) <= attack_range * 1.22:
                    self.target.take_damage(damage * 0.78)
                triggered = True

        elif self.attack_pattern == "measured_crush":
            if dist <= attack_range:
                self.target.take_damage(damage * 1.36)
                self.rage = min(100.0, self.rage + 4.0)
                triggered = True

        elif self.attack_pattern == "stalk_chain":
            if dist <= attack_range * 1.2:
                for hit_mult in (0.62, 0.62, 0.52):
                    if not self.target.alive:
                        break
                    self.target.take_damage(damage * hit_mult)
                triggered = True

        elif self.attack_pattern == "rage_chain":
            if dist <= attack_range * 1.28:
                for hit_mult in (0.58, 0.58, 0.58, 0.72):
                    if not self.target.alive:
                        break
                    self.target.take_damage(damage * hit_mult)
                triggered = True

        else:
            if dist <= attack_range:
                self.target.take_damage(damage * 1.08)
                triggered = True

        if not triggered:
            return False

        self.telegraph_timer = 0.34
        self.telegraph_color = self._telegraph_color()
        self.cooldowns.set("signature", self._signature_cooldown())
        self.cooldowns.set("attack", max(self._current_attack_cooldown() * 0.68, 0.5))
        self.focus = min(100.0, self.focus + 4.0)

        return True

    def _should_feint(self, dist: float) -> bool:
        if self.phase < 2:
            return False

        if dist > self._current_attack_range() * 1.1:
            return False

        chance = self.feint_chance

        if self.world_insight == "medium":
            chance += 0.04
        elif self.world_insight == "high":
            chance += 0.09

        if self.behavior_mode in {"cutoff_pressure", "trap_pressure"}:
            chance += 0.05

        if self.rage >= 70:
            chance *= 0.55

        return random.random() < chance

    def _perform_feint(self) -> None:
        self.telegraph_timer = 0.42
        self.telegraph_color = (255, 255, 255)
        self.fake_attack_timer = 0.26

        self.cooldowns.set("signature", max(1.2, self._signature_cooldown() * 0.38))
        self.cooldowns.set("attack", 0.35)

        self.focus = min(100.0, self.focus + 7.0)

    def _telegraph_color(self) -> tuple[int, int, int]:
        return {
            "lunging_break": (255, 170, 94),
            "intercept_combo": (182, 126, 255),
            "measured_crush": (255, 214, 120),
            "stalk_chain": (122, 244, 188),
            "rage_chain": (255, 72, 72),
            "brutal_standard": (220, 220, 255),
        }.get(self.attack_pattern, (220, 220, 255))

    def try_attack_target(self) -> bool:
        if self.target is None or not self.target.alive:
            return False

        if self.distance_to(self.target) > self._current_attack_range():
            return False

        if not self.cooldowns.ready("attack"):
            return False

        self.cooldowns.set("attack", self._current_attack_cooldown())

        base_damage = self._current_damage() * self.stats.attack_power
        repeat_count = self._attack_repeat_count()

        for hit_index in range(repeat_count):
            if not self.target.alive:
                break

            hit_mult = 1.0 if hit_index == 0 else 0.44
            self.target.take_damage(base_damage * hit_mult)

        self.focus = min(100.0, self.focus + 2.5)
        return True

    def _try_prepare_summon(self) -> None:
        if self.phase < 2 or self.summon_cooldown > 0:
            return

        variant_sets = {
            "balanced": ["charger"],
            "hunters": ["gunner", "gunner", "wisp"],
            "shieldwall": ["charger", "charger", "wisp"],
            "trappers": ["wisp", "gunner"],
            "punishers": ["charger", "wisp"],
        }

        summon_variants = variant_sets.get(self.summon_doctrine, ["charger"])
        summon_count = 1 if self.phase == 2 else 2

        if self.behavior_mode in {"anti_range", "cutoff_pressure", "berserk_pressure"}:
            summon_count += 1

        elite_chance = 0.0

        if self.world_insight == "high" and self.phase >= 3:
            elite_chance = 0.24

        if self.rage >= 85:
            elite_chance += 0.12

        self.pending_summons.append({
            "variants": summon_variants,
            "count": summon_count,
            "elite_chance": min(0.45, elite_chance),
            "doctrine": self.summon_doctrine,
        })

        base_cd = 9.4 if self.phase == 2 else 7.4

        if self.summon_doctrine in {"hunters", "punishers"}:
            base_cd *= 0.9

        if self.behavior_mode == "berserk_pressure":
            base_cd *= 0.82

        self.summon_cooldown = max(4.5, base_cd)

    def consume_summon_requests(self) -> list[dict]:
        requests = list(self.pending_summons)
        self.pending_summons.clear()
        return requests

    def record_player_basic_attack(self) -> None:
        self.memory.record_basic_attack()
        self.focus = min(100.0, self.focus + 0.8)

    def record_player_skill_1(self) -> None:
        self.memory.record_skill_1()
        self.focus = min(100.0, self.focus + 2.5)

    def record_player_ult(self) -> None:
        self.memory.record_ult()
        self.rage = min(100.0, self.rage + 14.0)
        self.focus = min(100.0, self.focus + 12.0)

    def record_player_dash(self, direction: str = "back") -> None:
        self.memory.record_dash(direction)
        self.focus = min(100.0, self.focus + 1.8)

    def persist_learning(self) -> None:
        if self._learning_persisted:
            return

        self.global_db.merge_entity_memory(self.boss_id, self.memory.to_dict())

        if not self.alive:
            self.global_db.register_kill(self.boss_id)

        self.global_db.save()
        self._learning_persisted = True

    def get_debug_state(self) -> dict:
        profile = self._blended_profile()

        hottest_cell = None
        hottest_value = 0.0

        if self.player_heatmap:
            hottest_cell, hottest_value = max(self.player_heatmap.items(), key=lambda item: item[1])

        return {
            "hp": round(self.stats.hp, 1),
            "phase": self.phase,
            "mode": self.behavior_mode,
            "style": self.style,
            "pattern": self.attack_pattern,
            "summons": self.summon_doctrine,
            "insight": self.world_insight,
            "rage": round(self.rage, 1),
            "focus": round(self.focus, 1),
            "confidence": round(self.confidence, 1),
            "attack_cd": round(self.cooldowns.remaining("attack"), 2),
            "sig_cd": round(self.cooldowns.remaining("signature"), 2),
            "preferred_dodge": profile["preferred_dodge"],
            "dominant_range": profile["dominant_range"],
            "aggression": profile["aggression"],
            "burst": profile["burst"],
            "mobility": profile["mobility"],
            "punish": profile["punish"],
            "hot_cell": hottest_cell,
            "hot_value": round(hottest_value, 2),
        }

    def draw(
        self,
        surface: pygame.Surface,
        cam_x: float = 0.0,
        cam_y: float = 0.0,
        draw_hp_bar: bool = True,
    ) -> None:
        super().draw(surface, cam_x, cam_y, draw_hp_bar)

        if not self.alive:
            return

        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)

        doctrine_color = {
            "balanced": (206, 194, 230),
            "hunters": (120, 198, 255),
            "shieldwall": (255, 214, 126),
            "trappers": (126, 242, 198),
            "punishers": (198, 126, 255),
        }.get(self.summon_doctrine, (220, 220, 240))

        pygame.draw.circle(surface, doctrine_color, (sx, sy), int(self.radius + 10), 2)

        if self.rage >= 70:
            pygame.draw.circle(surface, (255, 60, 60), (sx, sy), int(self.radius + 16), 2)

        if self.world_insight == "high":
            pygame.draw.circle(surface, (120, 220, 255), (sx, sy), int(self.radius + 22), 1)

        if self.telegraph_timer > 0:
            pulse = int((1.0 - self.telegraph_timer / 0.65) * 22)
            pygame.draw.circle(
                surface,
                self.telegraph_color,
                (sx, sy),
                int(self.radius + 14 + pulse),
                3,
            )