# game/enemies/ss_boss.py

from __future__ import annotations

import pygame

from game.config import (
    SS_BOSS_RADIUS,
    SS_BOSS_BASE_SPEED,
    SS_BOSS_MAX_HP,
    SS_BOSS_DAMAGE,
    SS_BOSS_ATTACK_RANGE,
    SS_BOSS_ATTACK_COOLDOWN,
    ORANGE,
    SS_BOSS_LEARNING_RATE,
)
from game.core.entity import Entity
from game.core.stats import Stats
from game.core.cooldowns import Cooldowns
from game.ai.adaptation import CombatMemory
from game.ai.combat_ai import CombatAI
from game.ai.global_learning import GlobalLearningDB


class SSBoss(Entity):
    def __init__(self, x: float, y: float, name: str = "SS Boss", boss_id: str = "ss_boss_1", style: str = "cataclysm"):
        stats = Stats(
            max_hp=SS_BOSS_MAX_HP,
            max_mana=0.0,
            max_stamina=0.0,
            hp_regen=0.0,
            mana_regen=0.0,
            stamina_regen=0.0,
            attack_power=1.35,
            defense=4.0,
            speed=SS_BOSS_BASE_SPEED,
        )

        super().__init__(
            x=x,
            y=y,
            radius=SS_BOSS_RADIUS,
            color=ORANGE,
            stats=stats,
            name=name,
        )

        self.base_speed = SS_BOSS_BASE_SPEED
        self.base_damage = SS_BOSS_DAMAGE
        self.base_attack_range = SS_BOSS_ATTACK_RANGE
        self.base_attack_cooldown = SS_BOSS_ATTACK_COOLDOWN
        self.base_defense = stats.defense

        self.cooldowns = Cooldowns()
        self.target: Entity | None = None

        self.memory = CombatMemory(learning_rate=SS_BOSS_LEARNING_RATE)
        self.ai = CombatAI()

        self.phase = 1
        self.behavior_mode = "adaptive_pressure"
        self.attack_pattern = "monarch_standard"
        self.summon_doctrine = "balanced"
        self.world_insight = "high"
        self.telegraph_timer = 0.0
        self.telegraph_color = (255, 255, 255)
        self.enrage = False

        self.dash_punish_bonus = 1.0
        self.anti_range_bonus = 1.0
        self.anti_burst_bonus = 1.0

        self.boss_id = boss_id
        self.global_db = GlobalLearningDB()
        self.global_db.register_encounter(self.boss_id)
        self.memory.load_from_dict(self.global_db.get_boss_memory(self.boss_id))
        self._learning_persisted = False
        self.style = style
        self.summon_cooldown = 0.0
        self.pending_summons: list[dict] = []
        self._apply_style()

    def _apply_style(self) -> None:
        if self.style == "predator":
            self.base_speed *= 1.12
            self.base_attack_cooldown *= 0.92
            self.color = (255, 166, 84)
        elif self.style == "oracle":
            self.base_attack_range *= 1.18
            self.base_damage *= 0.94
            self.color = (255, 208, 110)
        else:
            self.base_damage *= 1.10
            self.stats.max_hp *= 1.10
            self.stats.hp = self.stats.max_hp

    def set_target(self, target: Entity) -> None:
        self.target = target

    def update(self, dt: float, world_rect: pygame.Rect | None = None) -> None:
        self.cooldowns.update(dt)
        self.summon_cooldown = max(0.0, self.summon_cooldown - dt)
        self.telegraph_timer = max(0.0, self.telegraph_timer - dt)

        if not self.alive:
            super().update(dt, world_rect)
            return

        self._update_phase()

        if self.target is not None and self.target.alive:
            dist = self.distance_to(self.target)

            self.memory.observe_tick(dist, dt)
            self._adapt_behavior()
            self.stats.defense = self._current_defense()
            self._try_prepare_summon()

            self.ai.observe_player(self.target)
            profile = CombatMemory.blended_profile(
                (self.global_db.get_player_profile_memory(), 1.0),
                (self.memory.to_dict(), 1.2),
                learning_rate=SS_BOSS_LEARNING_RATE,
            )
            behavior = self.ai.choose_behavior(self, self.target, profile)
            self.ai.apply_behavior(self, self.target, behavior)
            if self.distance_to(self.target) <= self._current_attack_range() * 1.32:
                self.try_signature_attack()
        else:
            self.stop()

        super().update(dt, world_rect)

    def _update_phase(self) -> None:
        hp_ratio = self.stats.hp_ratio

        if hp_ratio <= 0.20:
            self.phase = 4
            self.enrage = True
        elif hp_ratio <= 0.45:
            self.phase = 3
        elif hp_ratio <= 0.75:
            self.phase = 2
        else:
            self.phase = 1

    def _adapt_behavior(self) -> None:
        profile = self._blended_profile()
        observations = int(profile.get("observations", 0))
        if observations >= 220:
            self.world_insight = "apex"
        elif observations >= 110:
            self.world_insight = "high"
        else:
            self.world_insight = "medium"

        self.dash_punish_bonus = 1.0
        self.anti_range_bonus = 1.0
        self.anti_burst_bonus = 1.0

        if profile["mobility"] == "high":
            self.behavior_mode = "dash_punish"
            self.attack_pattern = "predator_chain"
            self.summon_doctrine = "execution_net"
            self.dash_punish_bonus = 1.28
        elif profile["punish"] == "high" and profile["preferred_dodge"] in {"left", "right"}:
            self.behavior_mode = "cutoff_execution"
            self.attack_pattern = "monarch_intercept"
            self.summon_doctrine = "cutoff_ring"
            self.dash_punish_bonus = 1.22
            self.anti_range_bonus = 1.10
        elif profile["range_denial"] == "high" or profile["dominant_range"] == "long":
            self.behavior_mode = "anti_range"
            self.attack_pattern = "gate_lance"
            self.summon_doctrine = "hunter_screen"
            self.anti_range_bonus = 1.24
        elif profile["burst_denial"] == "high" or profile["burst"] == "high":
            self.behavior_mode = "anti_burst"
            self.attack_pattern = "abyss_guard"
            self.summon_doctrine = "stability_wall"
            self.anti_burst_bonus = 1.20
        else:
            self.behavior_mode = "adaptive_pressure"
            self.attack_pattern = "monarch_standard"
            self.summon_doctrine = "balanced"

    def _blended_profile(self) -> dict:
        return CombatMemory.blended_profile(
            (self.global_db.get_player_profile_memory(), 1.0),
            (self.memory.to_dict(), 1.2),
            learning_rate=SS_BOSS_LEARNING_RATE,
        )

    def _current_damage(self) -> float:
        damage = self.base_damage

        if self.phase == 2:
            damage *= 1.10
        elif self.phase == 3:
            damage *= 1.22
        elif self.phase == 4:
            damage *= 1.35

        if self.behavior_mode == "dash_punish":
            damage *= self.dash_punish_bonus
        elif self.behavior_mode == "anti_range":
            damage *= 1.10
        elif self.behavior_mode == "anti_burst":
            damage *= self.anti_burst_bonus
        elif self.behavior_mode == "cutoff_execution":
            damage *= 1.16

        if self.enrage:
            damage *= 1.12

        return damage

    def _current_defense(self) -> float:
        defense = self.base_defense
        if self.behavior_mode == "anti_burst":
            defense += 4.0
        elif self.behavior_mode == "dash_punish":
            defense += 1.5
        elif self.behavior_mode == "cutoff_execution":
            defense += 2.0
        if self.world_insight == "apex":
            defense += 2.0
        elif self.world_insight == "high":
            defense += 1.0
        return defense

    def _current_attack_range(self) -> float:
        attack_range = self.base_attack_range
        if self.attack_pattern == "gate_lance":
            attack_range *= 1.26
        elif self.attack_pattern == "monarch_intercept":
            attack_range *= 1.18
        elif self.attack_pattern == "abyss_guard":
            attack_range *= 1.10
        if self.phase >= 3:
            attack_range *= 1.06
        return attack_range

    def _attack_repeat_count(self) -> int:
        if self.attack_pattern == "predator_chain":
            return 2 if self.phase < 4 else 3
        if self.attack_pattern == "monarch_intercept":
            return 2
        return 1

    def _current_attack_cooldown(self) -> float:
        cd = self.base_attack_cooldown

        if self.phase == 2:
            cd *= 0.94
        elif self.phase == 3:
            cd *= 0.86
        elif self.phase == 4:
            cd *= 0.78

        if self.behavior_mode == "dash_punish":
            cd *= 0.92
        elif self.behavior_mode == "anti_range":
            cd *= 0.90
        elif self.behavior_mode == "anti_burst":
            cd *= 0.96
        elif self.behavior_mode == "cutoff_execution":
            cd *= 0.84

        if self.enrage:
            cd *= 0.92

        return cd

    def _signature_cooldown(self) -> float:
        cooldown = 6.4 if self.phase == 1 else 5.2 if self.phase == 2 else 4.2 if self.phase == 3 else 3.5
        if self.world_insight == "apex":
            cooldown *= 0.84
        elif self.world_insight == "high":
            cooldown *= 0.92
        return cooldown

    def try_signature_attack(self) -> bool:
        if self.target is None or not self.target.alive:
            return False
        if not self.cooldowns.ready("signature"):
            return False

        dist = self.distance_to(self.target)
        damage = self._current_damage() * self.stats.attack_power
        triggered = False

        if self.attack_pattern == "predator_chain":
            if dist <= self._current_attack_range() * 1.12:
                for hit_mult in (0.72, 0.68, 0.64 if self.phase >= 3 else 0.0):
                    if hit_mult <= 0 or not self.target.alive:
                        continue
                    self.target.take_damage(damage * hit_mult)
                triggered = True
        elif self.attack_pattern == "monarch_intercept":
            if dist <= self._current_attack_range() * 1.24:
                self.target.take_damage(damage * 0.96)
                if self.target.alive:
                    self.target.take_damage(damage * 0.88)
                triggered = True
        elif self.attack_pattern == "gate_lance":
            if dist <= self._current_attack_range() * 1.42:
                self.target.take_damage(damage * 1.28)
                triggered = True
        elif self.attack_pattern == "abyss_guard":
            if dist <= self._current_attack_range() * 1.08:
                self.target.take_damage(damage * 1.36)
                self.stats.defense = max(self.stats.defense, self._current_defense() + 2.0)
                triggered = True
        elif self.attack_pattern == "monarch_standard":
            if self.enrage and dist <= self._current_attack_range() * 1.12:
                self.target.take_damage(damage * 1.1)
                triggered = True

        if not triggered:
            return False

        self.telegraph_timer = 0.42
        self.telegraph_color = self._telegraph_color()
        self.cooldowns.set("signature", self._signature_cooldown())
        self.cooldowns.set("attack", max(self._current_attack_cooldown() * 0.72, 0.42))
        return True

    def _telegraph_color(self) -> tuple[int, int, int]:
        return {
            "predator_chain": (255, 132, 86),
            "monarch_intercept": (210, 126, 255),
            "gate_lance": (120, 208, 255),
            "abyss_guard": (255, 226, 142),
            "monarch_standard": (255, 186, 118),
        }.get(self.attack_pattern, (255, 220, 180))

    def try_attack_target(self) -> bool:
        if self.target is None or not self.target.alive:
            return False

        if self.distance_to(self.target) > self._current_attack_range():
            return False

        if not self.cooldowns.ready("attack"):
            return False

        self.cooldowns.set("attack", self._current_attack_cooldown())
        base_damage = self._current_damage() * self.stats.attack_power
        repeat_count = self._attack_repeat_count()
        for hit_index in range(repeat_count):
            hit_mult = 1.0 if hit_index == 0 else 0.52 if hit_index == 1 else 0.34
            self.target.take_damage(base_damage * hit_mult)
        return True

    def _try_prepare_summon(self) -> None:
        if self.phase < 2 or self.summon_cooldown > 0:
            return
        variant_sets = {
            "balanced": ["charger", "gunner"],
            "execution_net": ["charger", "charger", "wisp"],
            "cutoff_ring": ["wisp", "gunner", "gunner"],
            "hunter_screen": ["gunner", "gunner", "wisp"],
            "stability_wall": ["charger", "wisp", "charger"],
        }
        summon_variants = variant_sets.get(self.summon_doctrine, ["charger", "gunner"])
        summon_count = 2 if self.phase == 2 else 3 if self.phase == 3 else 4
        if self.behavior_mode in {"anti_range", "cutoff_execution"}:
            summon_count += 1
        elite_chance = 0.12 if self.phase >= 3 else 0.0
        if self.world_insight == "apex":
            elite_chance += 0.18
        self.pending_summons.append({
            "variants": summon_variants,
            "count": summon_count,
            "elite_chance": elite_chance,
        })
        base_cd = 8.0 if self.phase == 2 else 6.4 if self.phase == 3 else 5.0
        if self.summon_doctrine in {"execution_net", "cutoff_ring"}:
            base_cd *= 0.9
        self.summon_cooldown = base_cd

    def consume_summon_requests(self) -> list[dict]:
        requests = list(self.pending_summons)
        self.pending_summons.clear()
        return requests

    def record_player_basic_attack(self) -> None:
        self.memory.record_basic_attack()

    def record_player_skill_1(self) -> None:
        self.memory.record_skill_1()

    def record_player_ult(self) -> None:
        self.memory.record_ult()

    def record_player_dash(self, direction: str = "back") -> None:
        self.memory.record_dash(direction)

    def persist_learning(self) -> None:
        if self._learning_persisted:
            return
        self.global_db.merge_entity_memory(self.boss_id, self.memory.to_dict())
        if not self.alive:
            self.global_db.register_kill(self.boss_id)
        self.global_db.save()
        self._learning_persisted = True

    def get_debug_state(self) -> dict:
        profile = self._blended_profile()
        return {
            "hp": round(self.stats.hp, 1),
            "phase": self.phase,
            "mode": self.behavior_mode,
            "style": self.style,
            "pattern": self.attack_pattern,
            "summons": self.summon_doctrine,
            "insight": self.world_insight,
            "enrage": self.enrage,
            "attack_cd": round(self.cooldowns.remaining("attack"), 2),
            "sig_cd": round(self.cooldowns.remaining("signature"), 2),
            "preferred_dodge": profile["preferred_dodge"],
            "dominant_range": profile["dominant_range"],
            "aggression": profile["aggression"],
            "burst": profile["burst"],
            "mobility": profile["mobility"],
            "punish": profile["punish"],
        }

    def draw(self, surface: pygame.Surface, cam_x: float = 0.0, cam_y: float = 0.0, draw_hp_bar: bool = True) -> None:
        super().draw(surface, cam_x, cam_y, draw_hp_bar)
        if not self.alive:
            return

        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)
        doctrine_color = {
            "balanced": (255, 198, 126),
            "execution_net": (255, 132, 86),
            "cutoff_ring": (210, 126, 255),
            "hunter_screen": (120, 208, 255),
            "stability_wall": (255, 226, 142),
        }.get(self.summon_doctrine, (255, 214, 166))
        pygame.draw.circle(surface, doctrine_color, (sx, sy), int(self.radius + 12), 2)
        if self.world_insight == "apex":
            pygame.draw.circle(surface, (255, 244, 182), (sx, sy), int(self.radius + 18), 1)

        if self.telegraph_timer > 0:
            pulse = int((1.0 - self.telegraph_timer / 0.42) * 24)
            pygame.draw.circle(surface, self.telegraph_color, (sx, sy), int(self.radius + 16 + pulse), 3)
