from __future__ import annotations

from game.enemies.elite import Elite


class MiniBoss(Elite):
    def __init__(self, x: float, y: float, name: str = "MiniBoss", archetype: str = "brute", affixes: tuple[str, ...] = ()):
        super().__init__(x, y, name=name, archetype=archetype, affixes=affixes)
        self.radius += 6
        self.damage *= 1.18
        self.attack_range *= 1.08
        self.stats.max_hp *= 1.45
        self.stats.hp = self.stats.max_hp
        self.stats.attack_power *= 1.12
        self.base_speed *= 0.98
        self.stats.speed = self.base_speed
        self.color = (255, 170, 96)
        self.variant = "miniboss"
