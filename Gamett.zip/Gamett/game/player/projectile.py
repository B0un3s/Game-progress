from __future__ import annotations

import pygame

from game.config import YELLOW


class PlayerProjectile:
    def __init__(
        self,
        x: float,
        y: float,
        dir_x: float,
        dir_y: float,
        speed: float,
        damage: float,
        radius: float,
        max_distance: float,
        color=YELLOW,
        action_name: str = "skill_1",
    ):
        self.x = float(x)
        self.y = float(y)
        self.dir_x = float(dir_x)
        self.dir_y = float(dir_y)
        self.speed = float(speed)
        self.damage = float(damage)
        self.radius = float(radius)
        self.max_distance = float(max_distance)
        self.color = color
        self.action_name = action_name
        self.distance_travelled = 0.0
        self.alive = True

    @staticmethod
    def _hits_wall(x: float, y: float, radius: float, wall: pygame.Rect) -> bool:
        closest_x = max(wall.left, min(wall.right, x))
        closest_y = max(wall.top, min(wall.bottom, y))
        dx = x - closest_x
        dy = y - closest_y
        return dx * dx + dy * dy <= radius * radius

    def update(self, dt: float, world_rect: pygame.Rect | None = None, wall_rects: list[pygame.Rect] | None = None) -> None:
        if not self.alive:
            return

        step = self.speed * dt
        self.x += self.dir_x * step
        self.y += self.dir_y * step
        self.distance_travelled += step

        if world_rect is not None and not world_rect.collidepoint(self.x, self.y):
            self.alive = False
            return

        for wall in wall_rects or []:
            if self._hits_wall(self.x, self.y, self.radius, wall):
                self.alive = False
                return

        if self.distance_travelled >= self.max_distance:
            self.alive = False

    def collides_with(self, entity) -> bool:
        if not getattr(entity, "alive", False):
            return False

        dx = self.x - entity.x
        dy = self.y - entity.y
        total_radius = self.radius + entity.radius
        return (dx * dx + dy * dy) <= (total_radius * total_radius)

    def draw(self, surface: pygame.Surface, cam_x: float = 0.0, cam_y: float = 0.0) -> None:
        if not self.alive:
            return

        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)
        pygame.draw.circle(surface, self.color, (sx, sy), int(self.radius))
        glow_radius = int(self.radius + 4)
        pygame.draw.circle(surface, (255, 255, 255), (sx, sy), glow_radius, 1)
