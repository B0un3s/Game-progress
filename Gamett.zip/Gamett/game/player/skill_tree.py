from __future__ import annotations

from dataclasses import dataclass, field
import re


TIER_UNLOCK_LEVELS = {
    "T1": 1,
    "T2": 5,
    "T3": 10,
    "T4": 18,
    "T5": 28,
    "T6": 40,
    "T7": 55,
    "T8": 75,
}

TIER_COSTS = {
    "T1": 1,
    "T2": 2,
    "T3": 2,
    "T4": 3,
    "T5": 3,
    "T6": 4,
    "T7": 4,
    "T8": 5,
}

CLASS_BRANCHES = {
    "striker": ("Brutality", "Control", "Survival"),
    "ranger": ("Precision", "Mobility", "Control"),
    "awakened": ("Arcane", "Phase", "Hybrid Combat"),
}

CLASS_PRIMARY_STAT = {
    "striker": "strength",
    "ranger": "dexterity",
    "awakened": "intelligence",
}


@dataclass(frozen=True)
class SkillNode:
    node_id: str
    display_slot: int
    name: str
    branch: str
    class_id: str | None
    node_type: str
    tier: str
    max_rank: int
    cost: int
    min_level: int
    description: str
    requirements: tuple[str, ...] = ()
    stat_requirements: dict[str, int] = field(default_factory=dict)
    mastery_required: int = 0
    same_branch_required: int = 0
    total_nodes_required: int = 0
    branch_completion_required: bool = False
    passive_category: str = ""
    effects: dict[str, float | str | int] = field(default_factory=dict)


def slugify(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def make_node_id(prefix: str, name: str) -> str:
    return f"{prefix}_{slugify(name)}"


def _skill_desc(name: str, branch: str, tier: str) -> str:
    return f"{tier} {branch.lower()} technique: {name}."


def _passive_desc(name: str, category: str, tier: str) -> str:
    return f"{tier} {category.lower()} passive: {name}."


STRIKER_SKILLS = [
    "Heavy Slash", "Cleave", "Crushing Blow", "Guard Break", "Dash Strike", "Overhead Smash",
    "Blood Strike", "Whirl Slash", "Ground Slam", "Execution Cut", "Stagger Hit", "Shoulder Bash",
    "Rage Swing", "Iron Will Strike", "Double Cleave", "Chain Breaker", "Brutal Jab", "Leap Smash",
    "Skull Crusher", "War Cry", "Blade Rush", "Parry Counter", "Shockwave Cut", "Berserk Mode",
    "Bone Breaker", "Heavy Combo", "Momentum Strike", "Guarded Slash", "Flame Edge", "Frost Edge",
    "Thunder Edge", "Life Rend", "Armor Splitter", "Impact Burst", "Reckless Charge", "Blade Storm",
    "Titan Swing", "Echo Slash", "Rage Burst", "Counter Spin", "Iron Skin Strike", "Blood Frenzy",
    "Final Cut", "Slam Combo", "Crushing Wave", "Chain Slam", "Execution Leap", "Savage Combo",
    "Breaker Strike", "Monarch Cleave",
]

RANGER_SKILLS = [
    "Quick Shot", "Power Shot", "Multi Shot", "Piercing Arrow", "Dash Roll", "Backstep Shot",
    "Poison Arrow", "Frost Arrow", "Fire Arrow", "Shock Arrow", "Sniper Shot", "Trap Drop",
    "Explosive Arrow", "Volley", "Mark Target", "Silent Step", "Rapid Fire", "Ricochet Shot",
    "Hook Shot", "Smoke Bomb", "Phantom Shot", "Double Shot", "Scatter Shot", "Tracking Arrow",
    "Energy Bolt", "Wind Step", "Blink Shot", "Snare Trap", "Bleed Arrow", "Weak Point Shot",
    "Focus Aim", "Storm Arrow", "Ice Trap", "Flame Volley", "Dash Barrage", "Shadow Shot",
    "Piercing Rain", "Predator Mark", "Burst Shot", "Arrow Storm", "Wind Slash", "Split Arrow",
    "Energy Rain", "Swift Barrage", "Phantom Dash", "Trap Field", "Razor Arrow", "Shock Trap",
    "Spirit Arrow", "Monarch Volley",
]

AWAKENED_SKILLS = [
    "Arc Slash", "Energy Strike", "Blink Slash", "Mana Burst", "Spirit Blade", "Echo Strike",
    "Phase Dash", "Magic Cleave", "Flame Pulse", "Frost Pulse", "Lightning Pulse", "Soul Drain",
    "Mana Blade", "Rift Strike", "Shadow Slash", "Chain Strike", "Arc Wave", "Mana Shield",
    "Energy Dash", "Phantom Blade", "Rift Step", "Void Slash", "Elemental Strike", "Magic Combo",
    "Mana Surge", "Energy Rain", "Phase Strike", "Soul Burst", "Spell Slash", "Void Pulse",
    "Astral Strike", "Echo Dash", "Mana Explosion", "Rift Storm", "Spirit Combo", "Energy Cleave",
    "Arc Barrage", "Phantom Rush", "Mana Overload", "Void Rain", "Chain Pulse", "Rift Combo",
    "Astral Wave", "Magic Burst", "Phase Combo", "Spirit Storm", "Void Breaker", "Energy Collapse",
    "Dimensional Cut", "Monarch Rift",
]

PASSIVE_NAMES = [
    "Increased Health", "Increased Mana", "Increased Stamina", "Faster Regen", "Lifesteal", "Crit Chance",
    "Crit Damage", "Attack Speed", "Movement Speed", "Damage Reduction", "Armor Boost", "Elemental Resistance",
    "Cooldown Reduction", "Energy Efficiency", "Combo Damage", "Execution Bonus", "Boss Damage", "Elite Damage",
    "Dodge Chance", "Stamina Regen", "Mana Regen", "Skill Damage Boost", "AoE Increase", "Range Increase",
    "Projectile Speed", "Trap Damage", "Bleed Bonus", "Burn Bonus", "Freeze Duration", "Shock Duration",
    "On-Hit Heal", "On-Kill Heal", "Rage Build", "Damage After Dash", "Combo Multiplier", "Last Hit Bonus",
    "Finisher Damage", "Backstab Damage", "Crit Chain", "Skill Reset Chance", "Shield Gain", "Damage Reflection",
    "Death Prevention", "Heal Boost", "Potion Efficiency", "Status Immunity", "Reduced Stagger",
    "Faster Recovery", "Barrier Generation", "Resist Knockback", "Dual Scaling", "Elemental Conversion",
    "Damage Over Time Boost", "Chain Damage", "Energy Overflow", "Mana Shield Boost", "Lifesteal Scaling",
    "Skill Echo", "Damage Aura", "Pull Effect", "Double Strike Chance", "Triple Hit Chance",
    "Instant Kill Chance", "Damage Amplification", "Skill Overcharge", "Ultimate Boost", "Energy Explosion",
    "Infinite Stamina", "Rage Mode", "Time Slow on Hit", "Gold Gain", "XP Gain", "Drop Chance",
    "Loot Quality", "Movement After Kill", "Vision Range", "Trap Detection", "Resource Boost",
    "Auto Pickup", "Cooldown Reset", "Shadow Form", "Fire Form", "Ice Form", "Lightning Form",
    "Void Form", "Spirit Form", "Blood Form", "Berserker Mode", "Phantom State", "Energy Field",
    "Monarch Power", "Domain Control", "Infinite Combo", "Reality Shift", "Damage Conversion",
    "Ultimate Regen", "Multi Skill Cast", "Time Warp", "Soul Harvest", "Ascended Form",
]


PASSIVE_CATEGORY_BY_INDEX = {}
for idx in range(100):
    if idx < 24:
        PASSIVE_CATEGORY_BY_INDEX[idx] = "Core"
    elif idx < 54:
        PASSIVE_CATEGORY_BY_INDEX[idx] = "Specialized"
    elif idx < 74:
        PASSIVE_CATEGORY_BY_INDEX[idx] = "Advanced"
    elif idx < 90:
        PASSIVE_CATEGORY_BY_INDEX[idx] = "Rankable"
    else:
        PASSIVE_CATEGORY_BY_INDEX[idx] = "Milestone"


PASSIVE_TIER_BY_INDEX = {}
for idx in range(100):
    if idx < 10:
        PASSIVE_TIER_BY_INDEX[idx] = "T1"
    elif idx < 24:
        PASSIVE_TIER_BY_INDEX[idx] = "T2" if idx < 17 else "T3"
    elif idx < 39:
        PASSIVE_TIER_BY_INDEX[idx] = "T4"
    elif idx < 54:
        PASSIVE_TIER_BY_INDEX[idx] = "T5" if idx < 47 else "T6"
    elif idx < 64:
        PASSIVE_TIER_BY_INDEX[idx] = "T7"
    elif idx < 74:
        PASSIVE_TIER_BY_INDEX[idx] = "T8"
    elif idx < 82:
        PASSIVE_TIER_BY_INDEX[idx] = "T5"
    elif idx < 90:
        PASSIVE_TIER_BY_INDEX[idx] = "T6"
    elif idx < 95:
        PASSIVE_TIER_BY_INDEX[idx] = "T7"
    else:
        PASSIVE_TIER_BY_INDEX[idx] = "T8"


def _make_active_nodes(class_id: str, names: list[str]) -> list[SkillNode]:
    branches = CLASS_BRANCHES[class_id]
    tier_slices = {
        "T1": names[0:6],
        "T2": names[6:12],
        "T3": names[12:18],
        "T4": names[18:24],
        "T5": names[24:30],
        "T6": names[30:36],
        "T7": names[36:43],
        "T8": names[43:50],
    }
    nodes: list[SkillNode] = []
    display_slot = 1
    previous_by_branch: dict[str, str] = {}
    nodes_by_branch: dict[str, list[str]] = {branch: [] for branch in branches}

    for tier in ("T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8"):
        for idx, name in enumerate(tier_slices[tier]):
            branch = branches[idx % len(branches)]
            requirements: list[str] = []
            stat_requirements: dict[str, int] = {}
            mastery_required = 0
            same_branch_required = 0
            total_nodes_required = 0
            branch_completion_required = False
            if tier == "T2":
                total_nodes_required = 1
                if previous_by_branch.get(branch):
                    requirements.append(previous_by_branch[branch])
            elif tier == "T3":
                total_nodes_required = 2
                stat_requirements[CLASS_PRIMARY_STAT[class_id]] = 4
                if previous_by_branch.get(branch):
                    requirements.append(previous_by_branch[branch])
            elif tier == "T4":
                mastery_required = 1
                same_branch_required = 1
                if previous_by_branch.get(branch):
                    requirements.append(previous_by_branch[branch])
            elif tier == "T5":
                total_nodes_required = 3
                stat_requirements[CLASS_PRIMARY_STAT[class_id]] = 6
                if previous_by_branch.get(branch):
                    requirements.append(previous_by_branch[branch])
            elif tier == "T6":
                mastery_required = 3
                same_branch_required = 2
                if previous_by_branch.get(branch):
                    requirements.append(previous_by_branch[branch])
            elif tier == "T7":
                mastery_required = 5
                total_nodes_required = 5
                stat_requirements[CLASS_PRIMARY_STAT[class_id]] = 8
                if previous_by_branch.get(branch):
                    requirements.append(previous_by_branch[branch])
            elif tier == "T8":
                mastery_required = 8
                branch_completion_required = True
                same_branch_required = 5
                if previous_by_branch.get(branch):
                    requirements.append(previous_by_branch[branch])

            node_id = make_node_id(class_id, name)
            nodes.append(
                SkillNode(
                    node_id=node_id,
                    display_slot=display_slot,
                    name=name,
                    branch=branch,
                    class_id=class_id,
                    node_type="active",
                    tier=tier,
                    max_rank=3,
                    cost=TIER_COSTS[tier],
                    min_level=TIER_UNLOCK_LEVELS[tier],
                    description=_skill_desc(name, branch, tier),
                    requirements=tuple(requirements),
                    stat_requirements=stat_requirements,
                    mastery_required=mastery_required,
                    same_branch_required=same_branch_required,
                    total_nodes_required=total_nodes_required,
                    branch_completion_required=branch_completion_required,
                    effects={"unlock_skill_name": name},
                )
            )
            display_slot += 1
            previous_by_branch[branch] = node_id
            nodes_by_branch[branch].append(node_id)
    return nodes


def _passive_effects(name: str, category: str, tier: str) -> tuple[int, dict[str, float]]:
    rankable = category == "Rankable"
    max_rank = 10 if rankable else 1
    effects: dict[str, float] = {}
    lowered = name.lower()
    tier_scale = {"T1": 0.04, "T2": 0.05, "T3": 0.06, "T4": 0.07, "T5": 0.08, "T6": 0.09, "T7": 0.1, "T8": 0.12}[tier]

    if "health" in lowered:
        effects["bonus_max_hp"] = 16.0 if not rankable else 8.0
    elif "mana" in lowered and "regen" not in lowered and "shield" not in lowered:
        effects["bonus_max_mana"] = 14.0 if not rankable else 7.0
    elif "stamina" in lowered and "regen" not in lowered and "infinite" not in lowered:
        effects["bonus_stamina"] = 14.0 if not rankable else 7.0
    elif "regen" in lowered and "mana" in lowered:
        effects["bonus_mana_regen"] = 0.8 if not rankable else 0.35
    elif "regen" in lowered:
        effects["bonus_stamina_regen"] = 4.0 if not rankable else 1.8
    elif "crit chance" in lowered:
        effects["crit_chance"] = tier_scale
    elif "crit damage" in lowered:
        effects["crit_damage"] = tier_scale * 1.4
    elif "attack speed" in lowered:
        effects["attack_speed"] = tier_scale
    elif "movement speed" in lowered:
        effects["bonus_speed"] = 6.0 if not rankable else 3.0
    elif "damage reduction" in lowered or "armor boost" in lowered:
        effects["damage_reduction"] = tier_scale
    elif "cooldown" in lowered:
        effects["cooldown_reduction"] = tier_scale
    elif "lifesteal" in lowered or "on-hit heal" in lowered or "on-kill heal" in lowered:
        effects["lifesteal"] = tier_scale * 0.8
    elif "skill damage" in lowered or "damage amplification" in lowered or "ultimate boost" in lowered:
        effects["all_damage_multiplier"] = tier_scale
    elif "range" in lowered:
        effects["skill_1_bonus_range"] = 35.0 if not rankable else 18.0
    elif "projectile speed" in lowered:
        effects["skill_1_bonus_speed"] = 45.0 if not rankable else 20.0
    elif "combo" in lowered or "finisher" in lowered or "boss damage" in lowered or "elite damage" in lowered:
        effects["all_damage_multiplier"] = tier_scale * 0.75
    else:
        effects["all_damage_multiplier"] = tier_scale * 0.5
    return max_rank, effects


def _make_passive_nodes() -> list[SkillNode]:
    nodes: list[SkillNode] = []
    display_slot = 1001
    previous_passive_id = ""
    for idx, name in enumerate(PASSIVE_NAMES):
        tier = PASSIVE_TIER_BY_INDEX[idx]
        category = PASSIVE_CATEGORY_BY_INDEX[idx]
        max_rank, effects = _passive_effects(name, category, tier)
        requirements: list[str] = []
        stat_requirements: dict[str, int] = {}
        mastery_required = 0
        total_nodes_required = 0
        same_branch_required = 0
        branch_completion_required = False

        if tier == "T2":
            total_nodes_required = 1
            if previous_passive_id:
                requirements.append(previous_passive_id)
        elif tier == "T3":
            total_nodes_required = 2
            stat_requirements["vitality"] = 4
        elif tier == "T4":
            total_nodes_required = 3
            stat_requirements["strength"] = 4
        elif tier == "T5":
            total_nodes_required = 5
            mastery_required = 2
        elif tier == "T6":
            total_nodes_required = 8
            mastery_required = 3
            stat_requirements["dexterity"] = 6
        elif tier == "T7":
            total_nodes_required = 12
            mastery_required = 5
            stat_requirements["intelligence"] = 8
        elif tier == "T8":
            total_nodes_required = 16
            mastery_required = 8
            branch_completion_required = True

        node = SkillNode(
            node_id=make_node_id("passive", name),
            display_slot=display_slot,
            name=name,
            branch=category,
            class_id=None,
            node_type="passive",
            tier=tier,
            max_rank=max_rank,
            cost=TIER_COSTS[tier],
            min_level=TIER_UNLOCK_LEVELS[tier],
            description=_passive_desc(name, category, tier),
            requirements=tuple(requirements),
            stat_requirements=stat_requirements,
            mastery_required=mastery_required,
            same_branch_required=same_branch_required,
            total_nodes_required=total_nodes_required,
            branch_completion_required=branch_completion_required,
            passive_category=category,
            effects=effects,
        )
        nodes.append(node)
        display_slot += 1
        if category != "Rankable":
            previous_passive_id = node.node_id
    return nodes


SKILL_TREE_NODES: tuple[SkillNode, ...] = tuple(
    _make_active_nodes("striker", STRIKER_SKILLS)
    + _make_active_nodes("ranger", RANGER_SKILLS)
    + _make_active_nodes("awakened", AWAKENED_SKILLS)
    + _make_passive_nodes()
)

SKILL_TREE_BY_ID = {node.node_id: node for node in SKILL_TREE_NODES}
