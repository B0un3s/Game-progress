from __future__ import annotations

from game.player.builds import get_specializations
from game.player.skill_tree import CLASS_BRANCHES, SKILL_TREE_BY_ID, SKILL_TREE_NODES, TIER_UNLOCK_LEVELS


PASSIVE_CATEGORY_SLOT_CAPS = {
    "Core": 3,
    "Specialized": 3,
    "Advanced": 2,
    "Rankable": 2,
    "Milestone": 1,
}


class Progression:
    def __init__(
        self,
        level: int = 1,
        xp: int = 0,
        stat_points: int = 0,
        skill_points: int = 0,
        skill_ranks: dict[str, int] | None = None,
        allocated_stats: dict[str, int] | None = None,
        equipped_passives: list[str] | None = None,
        branch_rewards_claimed: list[str] | None = None,
        selected_specialization: str = "",
    ):
        self.level = max(1, int(level))
        self.xp = max(0, int(xp))
        self.stat_points = max(0, int(stat_points))
        self.skill_points = max(0, int(skill_points))
        self.skill_ranks = {node.node_id: 0 for node in SKILL_TREE_NODES}
        self.allocated_stats = {
            "power": 0,
            "vitality": 0,
            "focus": 0,
            "agility": 0,
        }
        self.equipped_passives: list[str] = []
        self.branch_rewards_claimed = set(branch_rewards_claimed or [])
        self.selected_specialization = str(selected_specialization or "")

        for node_id, rank in (skill_ranks or {}).items():
            if node_id in self.skill_ranks:
                self.skill_ranks[node_id] = max(0, int(rank))
        for stat_id, rank in (allocated_stats or {}).items():
            if stat_id in self.allocated_stats:
                self.allocated_stats[stat_id] = max(0, int(rank))
        for node_id in (equipped_passives or []):
            node = SKILL_TREE_BY_ID.get(node_id)
            if node is not None and node.node_type == "passive":
                self.equipped_passives.append(node_id)
        self.equipped_passives = list(dict.fromkeys(self.equipped_passives))

    def xp_to_next_level(self) -> int:
        return 100 + int((self.level - 1) * 60 + max(0, self.level - 20) * 18 + max(0, self.level - 50) * 24)

    def add_xp(self, amount: int) -> list[int]:
        amount = max(0, int(amount))
        self.xp += amount
        leveled_up = []

        while self.xp >= self.xp_to_next_level():
            self.xp -= self.xp_to_next_level()
            self.level += 1
            self.stat_points += 3
            self.skill_points += 1
            leveled_up.append(self.level)

        return leveled_up

    def can_spend_points(self, amount: int = 1) -> bool:
        return self.stat_points >= amount

    def spend_points(self, amount: int = 1) -> bool:
        amount = max(1, int(amount))
        if self.stat_points < amount:
            return False
        self.stat_points -= amount
        return True

    def allocate_stat(self, stat_id: str, amount: int = 1) -> tuple[bool, str]:
        stat_id = str(stat_id).lower()
        amount = max(1, int(amount))
        if stat_id not in self.allocated_stats:
            return False, "Unknown stat"
        if self.stat_points < amount:
            return False, "Not enough stat points"
        self.stat_points -= amount
        self.allocated_stats[stat_id] += amount
        return True, f"{stat_id.title()} +{amount}"

    def stat_summary(self) -> list[dict]:
        labels = {
            "power": ("P", "Power", "+5% attack power per point."),
            "vitality": ("V", "Vitality", "+14 HP and +6 stamina per point."),
            "focus": ("F", "Focus", "+12 mana and +0.6 mana regen per point."),
            "agility": ("G", "Agility", "+4 speed and +5 stamina regen per point."),
        }
        rows = []
        for stat_id, amount in self.allocated_stats.items():
            key_name, label, desc = labels[stat_id]
            rows.append({
                "key": key_name,
                "stat_id": stat_id,
                "name": label,
                "amount": amount,
                "description": desc,
            })
        return rows

    def get_skill_rank(self, node_id: str) -> int:
        return self.skill_ranks.get(node_id, 0)

    def get_node_rank_label(self, node_id: str) -> str:
        rank = self.get_skill_rank(node_id)
        if rank <= 0:
            return "Locked"
        return f"Rank {rank}"

    def passive_slot_limit(self, class_mastery: int = 1) -> int:
        return min(11, 2 + self.level // 15 + max(0, class_mastery - 1) // 3)

    def _count_unlocked_class_nodes(self, class_id: str) -> int:
        return sum(
            1
            for node in SKILL_TREE_NODES
            if node.class_id == class_id and self.get_skill_rank(node.node_id) > 0
        )

    def _count_unlocked_same_branch(self, class_id: str | None, branch: str, node_type: str = "active") -> int:
        return sum(
            1
            for node in SKILL_TREE_NODES
            if node.class_id == class_id and node.branch == branch and node.node_type == node_type and self.get_skill_rank(node.node_id) > 0
        )

    def _branch_completed(self, class_id: str | None, branch: str, upto_tier: str = "T7", node_type: str = "active") -> bool:
        max_level = TIER_UNLOCK_LEVELS.get(upto_tier, 75)
        candidates = [
            node for node in SKILL_TREE_NODES
            if node.class_id == class_id and node.branch == branch and node.min_level <= max_level and node.node_type == node_type
        ]
        return bool(candidates) and all(self.get_skill_rank(node.node_id) >= 1 for node in candidates)

    def _completed_branches(self, class_id: str) -> list[str]:
        return [branch for branch in CLASS_BRANCHES.get(class_id, ()) if self._branch_completed(class_id, branch, node_type="active")]

    def branch_summary(self, class_id: str) -> list[dict]:
        rows = []
        for branch in CLASS_BRANCHES.get(class_id, ()):
            total = len([
                node for node in SKILL_TREE_NODES
                if node.class_id == class_id and node.branch == branch and node.node_type == "active" and node.min_level < TIER_UNLOCK_LEVELS["T8"]
            ])
            unlocked = self._count_unlocked_same_branch(class_id, branch, "active")
            reward_key = f"{class_id}:{branch}"
            completed = self._branch_completed(class_id, branch, node_type="active")
            rows.append({
                "branch": branch,
                "unlocked": unlocked,
                "total": total,
                "completed": completed,
                "reward_claimed": reward_key in self.branch_rewards_claimed,
                "reward_ready": completed and reward_key not in self.branch_rewards_claimed,
            })
        return rows

    def _passive_category_count(self) -> dict[str, int]:
        counts = {key: 0 for key in PASSIVE_CATEGORY_SLOT_CAPS}
        for node_id in self.equipped_passives:
            node = SKILL_TREE_BY_ID.get(node_id)
            if node is None:
                continue
            counts[node.passive_category] = counts.get(node.passive_category, 0) + 1
        return counts

    def can_toggle_passive(self, node_id: str, class_mastery: int = 1) -> tuple[bool, str]:
        node = SKILL_TREE_BY_ID.get(node_id)
        if node is None or node.node_type != "passive":
            return False, "Not a passive"
        if self.get_skill_rank(node_id) <= 0:
            return False, "Passive not unlocked"
        if node_id in self.equipped_passives:
            return True, "UNEQUIP"

        if len(self.equipped_passives) >= self.passive_slot_limit(class_mastery):
            return False, f"Passive slots full ({self.passive_slot_limit(class_mastery)})"

        counts = self._passive_category_count()
        category_cap = PASSIVE_CATEGORY_SLOT_CAPS.get(node.passive_category, 1)
        if counts.get(node.passive_category, 0) >= category_cap:
            return False, f"{node.passive_category} cap {category_cap}"

        return True, "EQUIP"

    def toggle_passive(self, node_id: str, class_mastery: int = 1) -> tuple[bool, str]:
        can_toggle, reason = self.can_toggle_passive(node_id, class_mastery)
        if not can_toggle:
            return False, reason
        if node_id in self.equipped_passives:
            self.equipped_passives.remove(node_id)
            return True, f"Unequipped {SKILL_TREE_BY_ID[node_id].name}"
        self.equipped_passives.append(node_id)
        return True, f"Equipped {SKILL_TREE_BY_ID[node_id].name}"

    def passive_summary(self, class_mastery: int = 1) -> dict:
        counts = self._passive_category_count()
        return {
            "equipped": len(self.equipped_passives),
            "limit": self.passive_slot_limit(class_mastery),
            "categories": {
                category: {
                    "equipped": counts.get(category, 0),
                    "limit": limit,
                }
                for category, limit in PASSIVE_CATEGORY_SLOT_CAPS.items()
            },
        }

    def can_unlock_node(
        self,
        node_id: str,
        *,
        class_id: str = "striker",
        class_mastery: int = 1,
        core_stats: dict[str, int] | None = None,
    ) -> tuple[bool, str]:
        node = SKILL_TREE_BY_ID.get(node_id)
        if node is None:
            return False, "Invalid node"
        if self.get_skill_rank(node.node_id) >= node.max_rank:
            return False, "Already maxed"
        if self.level < node.min_level:
            return False, f"Requires level {node.min_level}"
        if self.skill_points < node.cost:
            return False, "Not enough skill points"
        if node.class_id is not None and node.class_id != class_id:
            return False, f"Requires {node.class_id.title()}"
        if class_mastery < node.mastery_required:
            return False, f"Requires mastery {node.mastery_required}"

        stats = {key: int((core_stats or {}).get(key, 1)) for key in ("strength", "dexterity", "vitality", "endurance", "intelligence")}
        for stat_id, needed in node.stat_requirements.items():
            if stats.get(stat_id, 1) < needed:
                return False, f"Requires {stat_id.title()} {needed}"

        for req in node.requirements:
            if self.get_skill_rank(req) <= 0:
                return False, f"Requires {SKILL_TREE_BY_ID[req].name}"

        if node.total_nodes_required > 0:
            if node.node_type == "passive":
                unlocked_total = sum(1 for other in SKILL_TREE_NODES if other.node_type == "passive" and self.get_skill_rank(other.node_id) > 0)
                if unlocked_total < node.total_nodes_required:
                    return False, f"Requires {node.total_nodes_required} passive nodes"
            else:
                target_class = node.class_id or class_id
                if self._count_unlocked_class_nodes(target_class) < node.total_nodes_required:
                    return False, f"Requires {node.total_nodes_required} class nodes"

        if node.same_branch_required > 0:
            if node.node_type == "passive":
                unlocked_same = sum(
                    1
                    for other in SKILL_TREE_NODES
                    if other.node_type == "passive" and other.branch == node.branch and self.get_skill_rank(other.node_id) > 0
                )
                if unlocked_same < node.same_branch_required:
                    return False, f"Requires {node.same_branch_required} {node.branch} passives"
            else:
                target_class = node.class_id or class_id
                if self._count_unlocked_same_branch(target_class, node.branch, "active") < node.same_branch_required:
                    return False, f"Requires {node.same_branch_required} {node.branch} nodes"

        if node.branch_completion_required:
            if node.node_type == "passive":
                if not self._branch_completed(None, node.branch, node_type="passive"):
                    return False, f"Complete {node.branch}"
            else:
                target_class = node.class_id or class_id
                if not self._branch_completed(target_class, node.branch, node_type="active"):
                    return False, f"Complete {node.branch}"

        return True, "READY"

    def _visible_nodes(
        self,
        *,
        class_id: str,
        class_mastery: int,
        core_stats: dict[str, int] | None,
    ) -> list:
        relevant_nodes = [
            node for node in SKILL_TREE_NODES
            if node.class_id is None or node.class_id == class_id
        ]
        rows = []
        for node in relevant_nodes:
            rank = self.get_skill_rank(node.node_id)
            if rank >= node.max_rank:
                continue
            can_unlock, reason = self.can_unlock_node(
                node.node_id,
                class_id=class_id,
                class_mastery=class_mastery,
                core_stats=core_stats,
            )
            sort_group = 0 if can_unlock else 1
            rows.append((sort_group, node.min_level, node.cost, node.name, node, reason))
        rows.sort(key=lambda item: item[:4])
        return [item[4] for item in rows[:8]]

    def _claim_branch_rewards(self, class_id: str) -> dict[str, int | list[str]]:
        completed_now = []
        for row in self.branch_summary(class_id):
            if row["reward_ready"]:
                reward_key = f"{class_id}:{row['branch']}"
                self.branch_rewards_claimed.add(reward_key)
                completed_now.append(row["branch"])
        if not completed_now:
            return {}
        reward = {
            "branches": completed_now,
            "skill_points": len(completed_now) * 2,
            "mastery_xp": len(completed_now) * 35,
        }
        self.skill_points += int(reward["skill_points"])
        return reward

    def unlock_skill(
        self,
        slot: int,
        *,
        class_id: str = "striker",
        class_mastery: int = 1,
        core_stats: dict[str, int] | None = None,
    ) -> tuple[bool, str, dict]:
        visible = self._visible_nodes(class_id=class_id, class_mastery=class_mastery, core_stats=core_stats)
        index = int(slot) - 1
        if index < 0 or index >= len(visible):
            return False, "Invalid slot", {}
        node = visible[index]
        can_unlock, reason = self.can_unlock_node(node.node_id, class_id=class_id, class_mastery=class_mastery, core_stats=core_stats)
        if not can_unlock:
            return False, reason, {}

        self.skill_points -= node.cost
        self.skill_ranks[node.node_id] += 1

        payload = dict(node.effects)
        payload["node_id"] = node.node_id
        payload["node_type"] = node.node_type
        payload["new_rank"] = self.skill_ranks[node.node_id]
        payload["max_rank"] = node.max_rank

        if node.node_type == "passive" and self.skill_ranks[node.node_id] == 1:
            can_toggle, _ = self.can_toggle_passive(node.node_id, class_mastery)
            if can_toggle:
                self.equipped_passives.append(node.node_id)
                payload["auto_equipped"] = True

        if node.node_type == "active":
            branch_reward = self._claim_branch_rewards(class_id)
            if branch_reward:
                payload["branch_reward"] = branch_reward

        return True, f"Unlocked {node.name} {self.skill_ranks[node.node_id]}/{node.max_rank}", payload

    def available_specializations(self, class_id: str, class_mastery: int = 1) -> list[dict]:
        completed_count = len(self._completed_branches(class_id))
        available = []
        for spec in get_specializations(class_id):
            unlocked = (
                self.level >= int(spec.get("level_required", 1))
                and class_mastery >= int(spec.get("mastery_required", 1))
                and completed_count >= int(spec.get("required_branches", 0))
            )
            available.append({**spec, "unlocked": unlocked})
        return available

    def set_specialization(self, spec_id: str, class_id: str, class_mastery: int = 1) -> tuple[bool, str]:
        for spec in self.available_specializations(class_id, class_mastery):
            if spec["spec_id"] != spec_id:
                continue
            if not spec["unlocked"]:
                return False, "Specialization locked"
            self.selected_specialization = spec_id
            return True, f"Specialization: {spec['name']}"
        return False, "Invalid specialization"

    def cycle_specialization(self, class_id: str, class_mastery: int = 1, direction: int = 1) -> str:
        unlocked = [spec for spec in self.available_specializations(class_id, class_mastery) if spec["unlocked"]]
        if not unlocked:
            self.selected_specialization = ""
            return "Locked"
        ids = [spec["spec_id"] for spec in unlocked]
        if self.selected_specialization not in ids:
            self.selected_specialization = ids[0]
        else:
            index = ids.index(self.selected_specialization)
            self.selected_specialization = ids[(index + direction) % len(ids)]
        return next(spec["name"] for spec in unlocked if spec["spec_id"] == self.selected_specialization)

    def skill_summary(
        self,
        *,
        class_id: str = "striker",
        class_mastery: int = 1,
        core_stats: dict[str, int] | None = None,
    ) -> list[dict]:
        rows = []
        visible = self._visible_nodes(class_id=class_id, class_mastery=class_mastery, core_stats=core_stats)
        for slot, node in enumerate(visible, start=1):
            can_unlock, reason = self.can_unlock_node(node.node_id, class_id=class_id, class_mastery=class_mastery, core_stats=core_stats)
            rows.append({
                "slot": slot,
                "node_id": node.node_id,
                "name": node.name,
                "branch": f"{node.class_id.title() if node.class_id else 'Passive'} / {node.branch}",
                "rank": self.get_skill_rank(node.node_id),
                "max_rank": node.max_rank,
                "cost": node.cost,
                "min_level": node.min_level,
                "tier": node.tier,
                "description": node.description,
                "requirements": node.requirements,
                "can_unlock": can_unlock,
                "status": "MAX" if self.get_skill_rank(node.node_id) >= node.max_rank else ("READY" if can_unlock else reason),
                "node_type": node.node_type,
                "passive_category": node.passive_category,
                "equipped": node.node_id in self.equipped_passives,
            })
        return rows

    def get_combat_bonuses(self) -> dict[str, float]:
        bonuses = {
            "bonus_max_hp": 0.0,
            "bonus_max_mana": 0.0,
            "bonus_mana_regen": 0.0,
            "bonus_stamina_regen": 0.0,
            "bonus_stamina": 0.0,
            "bonus_attack_power": 0.0,
            "basic_damage_multiplier": 1.0,
            "skill_1_damage_multiplier": 1.0,
            "ult_damage_multiplier": 1.0,
            "dash_cooldown_multiplier": 1.0,
            "skill_1_cooldown_multiplier": 1.0,
            "ult_mana_cost_multiplier": 1.0,
            "skill_1_bonus_range": 0.0,
            "skill_1_bonus_speed": 0.0,
            "bonus_speed": 0.0,
            "all_damage_multiplier": 1.0,
            "lifesteal": 0.0,
            "damage_reduction": 0.0,
        }

        equipped = set(self.equipped_passives)
        for node in SKILL_TREE_NODES:
            rank = self.get_skill_rank(node.node_id)
            if rank <= 0:
                continue
            if node.node_type == "passive" and node.node_id not in equipped:
                continue
            for key, value in node.effects.items():
                if key == "unlock_skill_name":
                    continue
                if key in ("basic_damage_multiplier", "skill_1_damage_multiplier", "ult_damage_multiplier", "all_damage_multiplier"):
                    bonuses[key] += float(value) * rank
                elif key == "cooldown_reduction":
                    reduction = float(value) * rank
                    bonuses["dash_cooldown_multiplier"] = max(0.4, bonuses["dash_cooldown_multiplier"] - reduction)
                    bonuses["skill_1_cooldown_multiplier"] = max(0.4, bonuses["skill_1_cooldown_multiplier"] - reduction)
                    bonuses["ult_mana_cost_multiplier"] = max(0.45, bonuses["ult_mana_cost_multiplier"] - reduction * 0.5)
                elif key in bonuses:
                    bonuses[key] += float(value) * rank

        return bonuses

    def xp_ratio(self) -> float:
        needed = self.xp_to_next_level()
        if needed <= 0:
            return 0.0
        return self.xp / needed

    def to_dict(self) -> dict:
        return {
            "level": self.level,
            "xp": self.xp,
            "stat_points": self.stat_points,
            "skill_points": self.skill_points,
            "skill_ranks": dict(self.skill_ranks),
            "allocated_stats": dict(self.allocated_stats),
            "equipped_passives": list(self.equipped_passives),
            "branch_rewards_claimed": sorted(self.branch_rewards_claimed),
            "selected_specialization": self.selected_specialization,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Progression":
        return cls(
            level=data.get("level", 1),
            xp=data.get("xp", 0),
            stat_points=data.get("stat_points", 0),
            skill_points=data.get("skill_points", 0),
            skill_ranks=data.get("skill_ranks", {}),
            allocated_stats=data.get("allocated_stats", {}),
            equipped_passives=data.get("equipped_passives", []),
            branch_rewards_claimed=data.get("branch_rewards_claimed", []),
            selected_specialization=data.get("selected_specialization", ""),
        )
