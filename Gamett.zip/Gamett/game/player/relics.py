from __future__ import annotations

import random


RARITY_ORDER = ("common", "rare", "epic", "legendary")
RARITY_COLORS = {
    "common": (186, 194, 208),
    "rare": (96, 182, 255),
    "epic": (198, 114, 255),
    "legendary": (255, 198, 96),
}
RARITY_MULTIPLIERS = {
    "common": 1.0,
    "rare": 1.35,
    "epic": 1.75,
    "legendary": 2.2,
}

RELIC_POOL = {
    "blood_charm": {
        "name": "Blood Charm",
        "description": "+12 max HP and +4% class skill damage.",
        "bonuses": {"max_hp": 12.0, "class_skill_mult": 0.04},
    },
    "focus_prism": {
        "name": "Focus Prism",
        "description": "+14 max mana and +8 projectile speed.",
        "bonuses": {"max_mana": 14.0, "projectile_speed": 8.0},
    },
    "hunter_treads": {
        "name": "Hunter Treads",
        "description": "+7 speed and +6 stamina regen.",
        "bonuses": {"speed": 7.0, "stamina_regen": 6.0},
    },
    "rune_spike": {
        "name": "Rune Spike",
        "description": "+6% basic and projectile damage.",
        "bonuses": {"basic_mult": 0.06, "skill_1_mult": 0.06},
    },
    "rift_heart": {
        "name": "Rift Heart",
        "description": "+8% ult damage and +10 stamina.",
        "bonuses": {"ult_mult": 0.08, "stamina": 10.0},
    },
}


def roll_relic_rarity(rank: str, enemy_name: str = "") -> str:
    rank = str(rank).upper()
    lowered = str(enemy_name).lower()
    table = {
        "E": [70, 24, 6, 0],
        "D": [62, 28, 9, 1],
        "C": [54, 31, 13, 2],
        "B": [46, 34, 16, 4],
        "A": [38, 36, 20, 6],
        "S": [28, 38, 24, 10],
        "SS": [18, 36, 30, 16],
        "SSS": [12, 30, 34, 24],
        "EX": [8, 24, 36, 32],
        "MONARCH": [4, 18, 38, 40],
    }
    weights = list(table.get(rank, [60, 28, 10, 2]))
    if "boss" in lowered:
        weights[1] += 4
        weights[2] += 6
        weights[3] += 6
        weights[0] = max(1, weights[0] - 16)
    if "ss" in lowered or "monarch" in lowered:
        weights[2] += 8
        weights[3] += 12
        weights[0] = max(1, weights[0] - 12)
        weights[1] = max(1, weights[1] - 8)
    return random.choices(RARITY_ORDER, weights=weights, k=1)[0]


def roll_relic(enemy_name: str = "", rank: str = "E") -> dict | None:
    lowered = str(enemy_name).lower()
    rank = str(rank).upper()
    chance = 0.0
    if "monarch" in lowered or "ss" in lowered:
        chance = 0.95
    elif "boss" in lowered:
        chance = 0.75
    elif "elite" in lowered:
        chance = 0.25
    elif rank in {"SS", "SSS", "EX", "MONARCH"}:
        chance = 0.12

    if random.random() > chance:
        return None

    relic_id = random.choice(list(RELIC_POOL.keys()))
    relic = RELIC_POOL[relic_id]
    rarity = roll_relic_rarity(rank, enemy_name)
    multiplier = RARITY_MULTIPLIERS[rarity]
    scaled_bonuses = {key: round(float(value) * multiplier, 3) for key, value in relic["bonuses"].items()}
    return {
        "item_id": f"{relic_id}_{rarity}",
        "relic_base_id": relic_id,
        "name": f"{rarity.title()} {relic['name']}",
        "description": relic["description"],
        "rarity": rarity,
        "color": RARITY_COLORS[rarity],
        "bonuses": scaled_bonuses,
    }


def aggregate_relic_bonuses(items: list[dict]) -> dict[str, float]:
    total = {
        "max_hp": 0.0,
        "max_mana": 0.0,
        "stamina": 0.0,
        "speed": 0.0,
        "stamina_regen": 0.0,
        "projectile_speed": 0.0,
        "projectile_range": 0.0,
        "basic_mult": 0.0,
        "skill_1_mult": 0.0,
        "ult_mult": 0.0,
        "class_skill_mult": 0.0,
    }
    for item in items:
        if item.get("item_type") != "relic":
            continue
        for key, value in item.get("bonuses", {}).items():
            if key in total:
                total[key] += float(value)
    return total
