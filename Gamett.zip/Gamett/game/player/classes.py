from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class HunterClass:
    class_id: str
    name: str
    description: str
    stat_focus: str
    passive_bonus: str
    active_skill: str
    mastery_focus: str
    mastery_perk: str


HUNTER_CLASSES: dict[str, HunterClass] = {
    "striker": HunterClass(
        class_id="striker",
        name="Striker",
        description="Frontline hunter with balanced offense and survivability.",
        stat_focus="HP / attack / stamina",
        passive_bonus="Basic attacks feel stronger and safer for new players.",
        active_skill="Shockwave",
        mastery_focus="frontline pressure and attrition",
        mastery_perk="Mastery adds max HP, stronger basics, and sturdier clash windows.",
    ),
    "ranger": HunterClass(
        class_id="ranger",
        name="Ranger",
        description="Projectile specialist built around spacing and cooldown control.",
        stat_focus="Projectile damage / speed / mana",
        passive_bonus="Excels with Q projectile builds.",
        active_skill="Volley",
        mastery_focus="projectile precision and spacing control",
        mastery_perk="Mastery adds projectile damage, range, and speed scaling.",
    ),
    "awakened": HunterClass(
        class_id="awakened",
        name="Awakened",
        description="Late-game scaling hunter tuned for ult power and mobility.",
        stat_focus="Ult / speed / mana",
        passive_bonus="Best payoff once the skill tree is developed.",
        active_skill="Rift Burst",
        mastery_focus="burst windows and awakened mana flow",
        mastery_perk="Mastery adds mana, speed, and heavier ult/class-skill payoff.",
    ),
}


def get_hunter_class(class_id: str) -> HunterClass:
    return HUNTER_CLASSES.get(class_id, HUNTER_CLASSES["striker"])
