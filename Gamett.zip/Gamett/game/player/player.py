# game/player/player.py

from __future__ import annotations

import math
import random
from typing import Any

import pygame

from game.config import (
    PLAYER_RADIUS,
    PLAYER_BASE_SPEED,
    PLAYER_MAX_HP,
    PLAYER_MAX_MANA,
    PLAYER_MAX_STAMINA,
    PLAYER_DASH_SPEED,
    PLAYER_DASH_DURATION,
    PLAYER_DASH_COOLDOWN,
    PLAYER_DASH_STAMINA_COST,
    HEALING_POTION_HEAL,
    STARTING_HEALING_POTIONS,
    MANA_POTION_RESTORE,
    STAMINA_TONIC_RESTORE,
    STRIKER_SKILL_DAMAGE,
    STRIKER_SKILL_RANGE,
    STRIKER_SKILL_COOLDOWN,
    STRIKER_SKILL_STAMINA_COST,
    RANGER_SKILL_DAMAGE,
    RANGER_SKILL_COOLDOWN,
    RANGER_SKILL_MANA_COST,
    RANGER_SKILL_PROJECTILE_SPEED,
    RANGER_SKILL_PROJECTILE_RANGE,
    RANGER_SKILL_PROJECTILE_RADIUS,
    AWAKENED_SKILL_DAMAGE,
    AWAKENED_SKILL_RANGE,
    AWAKENED_SKILL_COOLDOWN,
    AWAKENED_SKILL_MANA_COST,
    BLUE,
    YELLOW,
    CYAN,
)
from game.core.entity import Entity
from game.core.stats import Stats
from game.core.cooldowns import Cooldowns
from game.player.inventory import Inventory
from game.player.classes import get_hunter_class
from game.player.builds import (
    CORE_STAT_ORDER,
    CORE_STAT_LABELS,
    CREATION_STAT_CAP,
    DEFAULT_CORE_STATS,
    SKILL_DEFS,
    SKILL_MODIFIER_ORDER,
    STARTING_BUILD_POINTS,
    cycle_skill_modifier,
    cycle_slot_skill,
    get_skill_def,
    get_level_stat_growth,
    get_skill_modifier,
    get_specializations,
    make_default_loadout,
    make_default_skill_modifiers,
    make_default_unlocked_skills,
    sanitize_core_stats,
    sanitize_loadout,
    sanitize_skill_modifiers,
)
from game.player.projectile import PlayerProjectile
from game.player.progression import Progression
from game.player.relics import aggregate_relic_bonuses, roll_relic
from game.player.skills import SkillSet


class Player(Entity):
    @staticmethod
    def xp_for_enemy_name(enemy_name: str = "") -> int:
        lowered = str(enemy_name).lower()
        if "ss" in lowered:
            return 300
        if "boss" in lowered:
            return 150
        return 25

    def __init__(self, x: float, y: float, name: str = "Hunter"):
        stats = Stats(
            max_hp=PLAYER_MAX_HP,
            max_mana=PLAYER_MAX_MANA,
            max_stamina=PLAYER_MAX_STAMINA,
            hp_regen=0.0,
            mana_regen=8.0,
            stamina_regen=18.0,
            attack_power=1.0,
            defense=0.0,
            speed=PLAYER_BASE_SPEED,
        )

        super().__init__(
            x=x,
            y=y,
            radius=PLAYER_RADIUS,
            color=BLUE,
            stats=stats,
            name=name,
        )

        self.base_speed = PLAYER_BASE_SPEED
        self.class_id = "striker"
        self.core_stats = dict(DEFAULT_CORE_STATS)
        self.build_points = STARTING_BUILD_POINTS
        self.unlocked_skills = make_default_unlocked_skills()
        self.equipped_skills = make_default_loadout(self.class_id)
        self.skill_modifiers = make_default_skill_modifiers()
        self.gold = 0
        self.bonus_hp_from_levels = 0.0
        self.bonus_mana_from_levels = 0.0
        self.bonus_stamina_from_levels = 0.0
        self.bonus_attack_power_from_levels = 0.0
        self.bonus_speed_from_levels = 0.0
        self.shop_bonus_hp = 0.0
        self.shop_bonus_mana = 0.0
        self.shop_bonus_attack = 0.0
        self.cooldowns = Cooldowns()

        self.inventory = Inventory()
        self.progression = Progression()
        self.skills = SkillSet()
        self.class_mastery: dict[str, dict[str, int]] = {}
        self.current_gate_rank = "E"
        self.relic_bonuses: dict[str, float] = {}

        self.inventory_open = False
        self.skill_tree_open = False

        self.is_dashing = False
        self.dash_timer = 0.0
        self.dash_dir_x = 0.0
        self.dash_dir_y = 0.0
        self.damage_flash_timer = 0.0
        self.damage_invuln_timer = 0.0

        self.last_attack_result: dict[str, Any] = {
            "type": None,
            "hit": False,
            "damage": 0.0,
            "range": 0.0,
            "killed": False,
            "target_name": None,
        }
        self.projectiles: list[PlayerProjectile] = []
        self.build_snapshot: dict[str, float] = {}
        self.recalculate_progression_bonuses()

    def get_core_stat(self, stat_id: str) -> int:
        return max(1, int(self.core_stats.get(stat_id, 1)))

    def get_equipped_skill_id(self, slot: str) -> str:
        return self.equipped_skills.get(slot, make_default_loadout(self.class_id).get(slot, ""))

    def get_equipped_skill_def(self, slot: str):
        return get_skill_def(self.get_equipped_skill_id(slot))

    def get_equipped_skill_name(self, slot: str) -> str:
        return self.get_equipped_skill_def(slot).name

    def get_loadout_summary(self) -> dict[str, str]:
        return {slot: self.get_equipped_skill_name(slot) for slot in self.equipped_skills}

    def get_skill_modifier_id(self, slot: str) -> str:
        return self.skill_modifiers.get(slot, "balanced")

    def get_skill_modifier_data(self, slot: str) -> dict:
        return get_skill_modifier(self.get_skill_modifier_id(slot))

    def cycle_skill_modifier(self, slot: str, direction: int = 1) -> str:
        self.skill_modifiers[slot] = cycle_skill_modifier(self.get_skill_modifier_id(slot), direction)
        self.recalculate_progression_bonuses()
        return self.skill_modifiers[slot]

    def invest_build_point(self, stat_id: str) -> tuple[bool, str]:
        stat_id = str(stat_id).lower()
        if stat_id not in self.core_stats:
            return False, "Unknown core stat"
        if self.build_points <= 0:
            return False, "No build points"
        if self.get_core_stat(stat_id) >= CREATION_STAT_CAP:
            return False, "Stat cap reached"
        self.core_stats[stat_id] = self.get_core_stat(stat_id) + 1
        self.build_points -= 1
        self.recalculate_progression_bonuses()
        return True, f"{CORE_STAT_LABELS[stat_id]} +1"

    def reset_core_build(self) -> None:
        spent = sum(max(0, self.get_core_stat(stat_id) - DEFAULT_CORE_STATS[stat_id]) for stat_id in CORE_STAT_ORDER)
        self.core_stats = dict(DEFAULT_CORE_STATS)
        self.build_points += spent
        self.recalculate_progression_bonuses()

    def cycle_equipped_skill(self, slot: str, direction: int = 1) -> str:
        new_skill_id = cycle_slot_skill(slot, self.get_equipped_skill_id(slot), direction, self.unlocked_skills)
        self.equipped_skills[slot] = new_skill_id
        return new_skill_id

    def _apply_level_bonus_count(self, bonus_levels: int) -> None:
        bonus_levels = max(0, int(bonus_levels))
        self.bonus_hp_from_levels = bonus_levels * 10.0
        self.bonus_mana_from_levels = bonus_levels * 5.0
        self.bonus_stamina_from_levels = bonus_levels * 5.0
        self.bonus_attack_power_from_levels = bonus_levels * 0.08
        self.bonus_speed_from_levels = bonus_levels * 3.0

    def get_class_profile(self):
        return get_hunter_class(self.class_id)

    def _ensure_class_mastery(self) -> None:
        for class_id in ("striker", "ranger", "awakened"):
            state = self.class_mastery.setdefault(class_id, {})
            state["level"] = max(1, int(state.get("level", 1)))
            state["xp"] = max(0, int(state.get("xp", 0)))

    def mastery_xp_to_next_level(self, mastery_level: int | None = None) -> int:
        mastery_level = mastery_level if mastery_level is not None else self.get_class_mastery_state()["level"]
        mastery_level = max(1, int(mastery_level))
        return 80 + (mastery_level - 1) * 45

    def get_class_mastery_state(self, class_id: str | None = None) -> dict[str, int]:
        self._ensure_class_mastery()
        return self.class_mastery.get(class_id or self.class_id, {"level": 1, "xp": 0})

    def gain_class_mastery(self, amount: int, class_id: str | None = None) -> list[int]:
        self._ensure_class_mastery()
        target_class = class_id or self.class_id
        state = self.class_mastery.setdefault(target_class, {"level": 1, "xp": 0})
        state["xp"] += max(0, int(amount))
        leveled = []
        while state["xp"] >= self.mastery_xp_to_next_level(state["level"]):
            state["xp"] -= self.mastery_xp_to_next_level(state["level"])
            state["level"] += 1
            leveled.append(state["level"])
        self.recalculate_progression_bonuses()
        return leveled

    def get_class_mastery_bonuses(self) -> dict[str, float]:
        mastery = self.get_class_mastery_state()
        level = mastery["level"]
        if self.class_id == "ranger":
            return {
                "bonus_hp": 0.0,
                "bonus_mana": level * 2.0,
                "bonus_speed": level * 1.5,
                "basic_mult": 1.0,
                "skill_1_mult": 1.0 + level * 0.035,
                "ult_mult": 1.0,
                "class_mult": 1.0 + level * 0.03,
                "skill_1_cd_mult": max(0.72, 1.0 - level * 0.015),
                "projectile_range": level * 10.0,
                "projectile_speed": level * 18.0,
            }
        if self.class_id == "awakened":
            return {
                "bonus_hp": level * 1.0,
                "bonus_mana": level * 4.0,
                "bonus_speed": level * 2.0,
                "basic_mult": 1.0,
                "skill_1_mult": 1.0 + level * 0.012,
                "ult_mult": 1.0 + level * 0.04,
                "class_mult": 1.0 + level * 0.035,
                "skill_1_cd_mult": max(0.80, 1.0 - level * 0.01),
                "projectile_range": level * 4.0,
                "projectile_speed": level * 8.0,
            }
        return {
            "bonus_hp": level * 4.0,
            "bonus_mana": 0.0,
            "bonus_speed": level * 0.8,
            "basic_mult": 1.0 + level * 0.025,
            "skill_1_mult": 1.0,
            "ult_mult": 1.0,
            "class_mult": 1.0 + level * 0.035,
            "skill_1_cd_mult": 1.0,
            "projectile_range": 0.0,
            "projectile_speed": 0.0,
        }

    def get_class_bonuses(self) -> dict[str, float]:
        mastery_bonuses = self.get_class_mastery_bonuses()
        if self.class_id == "ranger":
            return {
                "bonus_hp": -6.0 + mastery_bonuses["bonus_hp"],
                "bonus_mana": 16.0 + mastery_bonuses["bonus_mana"],
                "bonus_speed": 6.0 + mastery_bonuses["bonus_speed"],
                "basic_mult": 0.96 * mastery_bonuses["basic_mult"],
                "skill_1_mult": 1.18 * mastery_bonuses["skill_1_mult"],
                "ult_mult": 1.04 * mastery_bonuses["ult_mult"],
                "class_mult": mastery_bonuses["class_mult"],
                "skill_1_cd_mult": 0.92 * mastery_bonuses["skill_1_cd_mult"],
                "projectile_range": mastery_bonuses["projectile_range"],
                "projectile_speed": mastery_bonuses["projectile_speed"],
            }
        if self.class_id == "awakened":
            return {
                "bonus_hp": 0.0 + mastery_bonuses["bonus_hp"],
                "bonus_mana": 10.0 + mastery_bonuses["bonus_mana"],
                "bonus_speed": 10.0 + mastery_bonuses["bonus_speed"],
                "basic_mult": 0.94 * mastery_bonuses["basic_mult"],
                "skill_1_mult": 1.06 * mastery_bonuses["skill_1_mult"],
                "ult_mult": 1.18 * mastery_bonuses["ult_mult"],
                "class_mult": mastery_bonuses["class_mult"],
                "skill_1_cd_mult": 0.96 * mastery_bonuses["skill_1_cd_mult"],
                "projectile_range": mastery_bonuses["projectile_range"],
                "projectile_speed": mastery_bonuses["projectile_speed"],
            }
        return {
            "bonus_hp": 14.0 + mastery_bonuses["bonus_hp"],
            "bonus_mana": 0.0 + mastery_bonuses["bonus_mana"],
            "bonus_speed": 0.0 + mastery_bonuses["bonus_speed"],
            "basic_mult": 1.10 * mastery_bonuses["basic_mult"],
            "skill_1_mult": 1.0 * mastery_bonuses["skill_1_mult"],
            "ult_mult": 1.0 * mastery_bonuses["ult_mult"],
            "class_mult": mastery_bonuses["class_mult"],
            "skill_1_cd_mult": 1.0 * mastery_bonuses["skill_1_cd_mult"],
            "projectile_range": mastery_bonuses["projectile_range"],
            "projectile_speed": mastery_bonuses["projectile_speed"],
        }

    def get_specialization_state(self) -> dict:
        selected = self.progression.selected_specialization
        available = self.progression.available_specializations(self.class_id, self.get_class_mastery_state()["level"])
        for spec in available:
            if spec["spec_id"] == selected:
                return spec
        return {}

    def get_specialization_bonuses(self) -> dict[str, float]:
        spec = self.get_specialization_state()
        bonuses = {
            "max_hp": 0.0,
            "max_mana": 0.0,
            "stamina": 0.0,
            "speed": 0.0,
            "damage_mult": 1.0,
            "cooldown_mult": 1.0,
            "projectile_range": 0.0,
            "projectile_speed": 0.0,
            "lifesteal": 0.0,
        }
        raw = spec.get("bonuses", {}) if isinstance(spec, dict) else {}
        for key in bonuses:
            if key in ("damage_mult", "cooldown_mult"):
                bonuses[key] = float(raw.get(key, bonuses[key]))
            else:
                bonuses[key] = float(raw.get(key, bonuses[key]))
        return bonuses

    def load_persistent_state(self, data: dict) -> None:
        player_data = data.get("player", {}) if isinstance(data, dict) else {}
        self.name = str(player_data.get("name", self.name))
        self.class_id = str(player_data.get("class_id", self.class_id))
        self.core_stats = sanitize_core_stats(player_data.get("core_stats", DEFAULT_CORE_STATS))
        self.build_points = max(0, int(player_data.get("build_points", STARTING_BUILD_POINTS)))
        self.unlocked_skills = [skill_id for skill_id in player_data.get("unlocked_skills", make_default_unlocked_skills()) if skill_id in SKILL_DEFS]
        if not self.unlocked_skills:
            self.unlocked_skills = make_default_unlocked_skills()
        self.equipped_skills = sanitize_loadout(player_data.get("equipped_skills", {}), self.class_id)
        self.skill_modifiers = sanitize_skill_modifiers(player_data.get("skill_modifiers", {}))
        for skill_id in self.equipped_skills.values():
            if skill_id not in self.unlocked_skills:
                self.unlocked_skills.append(skill_id)
        self.gold = max(0, int(player_data.get("gold", 0)))
        self.shop_bonus_hp = max(0.0, float(player_data.get("shop_bonus_hp", 0.0)))
        self.shop_bonus_mana = max(0.0, float(player_data.get("shop_bonus_mana", 0.0)))
        self.shop_bonus_attack = max(0.0, float(player_data.get("shop_bonus_attack", 0.0)))
        self.class_mastery = dict(player_data.get("class_mastery", {}))
        self._ensure_class_mastery()
        self.progression = Progression.from_dict(player_data)
        self.inventory = Inventory.from_dict(data.get("inventory", {}))
        if self.inventory.get_item("healing_potion") is None:
            self.inventory.add_item("healing_potion", "Healing Potion", STARTING_HEALING_POTIONS, "consumable")
        self._apply_level_bonus_count(self.progression.level - 1)
        self.recalculate_progression_bonuses()
        self.stats.hp = self.stats.max_hp
        self.stats.mana = self.stats.max_mana
        self.stats.stamina = self.stats.max_stamina

    def to_persistent_state(self) -> dict:
        return {
            "player": {
                "name": self.name,
                "class_id": self.class_id,
                "core_stats": dict(self.core_stats),
                "build_points": self.build_points,
                "equipped_skills": dict(self.equipped_skills),
                "skill_modifiers": dict(self.skill_modifiers),
                "unlocked_skills": list(self.unlocked_skills),
                "gold": self.gold,
                "shop_bonus_hp": self.shop_bonus_hp,
                "shop_bonus_mana": self.shop_bonus_mana,
                "shop_bonus_attack": self.shop_bonus_attack,
                "class_mastery": {k: dict(v) for k, v in self.class_mastery.items()},
                **self.progression.to_dict(),
            },
            "inventory": self.inventory.to_dict(),
        }

    def handle_input(self, events: list[pygame.event.Event]) -> None:
        keybinds = getattr(self, "keybinds", {})
        inventory_key = int(keybinds.get("inventory", pygame.K_b))
        skill_tree_key = int(keybinds.get("skill_tree", pygame.K_k))
        for event in events:
            if event.type != pygame.KEYDOWN:
                continue

            if event.key == inventory_key:
                self.inventory_open = not self.inventory_open
                if self.inventory_open:
                    self.skill_tree_open = False
            elif event.key == skill_tree_key:
                self.skill_tree_open = not self.skill_tree_open
                if self.skill_tree_open:
                    self.inventory_open = False
            elif self.skill_tree_open and pygame.K_1 <= event.key <= pygame.K_8:
                slot = event.key - pygame.K_0
                class_mastery = self.get_class_mastery_state()["level"]
                mods = pygame.key.get_mods()
                if mods & pygame.KMOD_SHIFT:
                    rows = self.progression.skill_summary(
                        class_id=self.class_id,
                        class_mastery=class_mastery,
                        core_stats=self.core_stats,
                    )
                    if 0 < slot <= len(rows) and rows[slot - 1]["node_type"] == "passive":
                        unlocked, message = self.progression.toggle_passive(rows[slot - 1]["node_id"], class_mastery)
                        if unlocked:
                            self.recalculate_progression_bonuses()
                    else:
                        unlocked, message = False, "Shift+slot only equips visible passives"
                else:
                    unlocked, message, effects = self.progression.unlock_skill(
                        slot,
                        class_id=self.class_id,
                        class_mastery=class_mastery,
                        core_stats=self.core_stats,
                    )
                    if unlocked:
                        unlocked_skill_name = effects.get("unlock_skill_name")
                        if isinstance(unlocked_skill_name, str):
                            for skill_id, skill_def in SKILL_DEFS.items():
                                if skill_def.name == unlocked_skill_name and skill_id not in self.unlocked_skills:
                                    self.unlocked_skills.append(skill_id)
                                    break
                        branch_reward = effects.get("branch_reward")
                        if isinstance(branch_reward, dict):
                            mastery_xp = int(branch_reward.get("mastery_xp", 0))
                            if mastery_xp > 0:
                                self.gain_class_mastery(mastery_xp)
                        self.recalculate_progression_bonuses()
                self.last_attack_result = {
                    "type": "skill_tree",
                    "hit": False,
                    "damage": 0.0,
                    "range": 0.0,
                    "killed": False,
                    "target_name": message,
                }
            elif self.skill_tree_open and event.key in (pygame.K_p, pygame.K_v, pygame.K_f, pygame.K_g):
                stat_map = {
                    pygame.K_p: "power",
                    pygame.K_v: "vitality",
                    pygame.K_f: "focus",
                    pygame.K_g: "agility",
                }
                spent, message = self.progression.allocate_stat(stat_map[event.key])
                if spent:
                    self.recalculate_progression_bonuses()
                self.last_attack_result = {
                    "type": "stats",
                    "hit": False,
                    "damage": 0.0,
                    "range": 0.0,
                    "killed": False,
                    "target_name": message,
                }
            elif self.skill_tree_open and event.key in (pygame.K_z, pygame.K_x, pygame.K_c, pygame.K_v):
                slot_map = {
                    pygame.K_z: "lmb",
                    pygame.K_x: "q",
                    pygame.K_c: "f",
                    pygame.K_v: "y",
                }
                slot_id = slot_map[event.key]
                modifier_id = self.cycle_skill_modifier(slot_id)
                modifier_name = get_skill_modifier(modifier_id)["name"]
                self.last_attack_result = {
                    "type": "modifier",
                    "hit": False,
                    "damage": 0.0,
                    "range": 0.0,
                    "killed": False,
                    "target_name": f"{slot_id.upper()} mod -> {modifier_name}",
                }
            elif self.skill_tree_open and event.key == pygame.K_n:
                spec_name = self.progression.cycle_specialization(self.class_id, self.get_class_mastery_state()["level"])
                self.recalculate_progression_bonuses()
                self.last_attack_result = {
                    "type": "specialization",
                    "hit": False,
                    "damage": 0.0,
                    "range": 0.0,
                    "killed": False,
                    "target_name": f"Spec -> {spec_name}",
                }

    def update(self, dt: float, world_rect: pygame.Rect | None = None) -> None:
        self.cooldowns.update(dt)
        self.damage_flash_timer = max(0.0, self.damage_flash_timer - dt)
        self.damage_invuln_timer = max(0.0, self.damage_invuln_timer - dt)

        if not self.alive:
            super().update(dt, world_rect)
            return

        if self.is_dashing:
            self.dash_timer -= dt
            self.set_velocity(
                self.dash_dir_x * PLAYER_DASH_SPEED,
                self.dash_dir_y * PLAYER_DASH_SPEED,
            )

            if self.dash_timer <= 0:
                self.is_dashing = False
                self.dash_timer = 0.0
                self.stop()
        else:
            self._handle_movement_input()

        super().update(dt, world_rect)

    def _handle_movement_input(self) -> None:
        keys = pygame.key.get_pressed()
        keybinds = getattr(self, "keybinds", {})
        move_left = int(keybinds.get("move_left", pygame.K_a))
        move_right = int(keybinds.get("move_right", pygame.K_d))
        move_up = int(keybinds.get("move_up", pygame.K_w))
        move_down = int(keybinds.get("move_down", pygame.K_s))

        dx = 0.0
        dy = 0.0

        if keys[move_left]:
            dx -= 1.0
        if keys[move_right]:
            dx += 1.0
        if keys[move_up]:
            dy -= 1.0
        if keys[move_down]:
            dy += 1.0

        length = math.hypot(dx, dy)
        if length > 0:
            dx /= length
            dy /= length
            self.set_velocity(dx * self.base_speed, dy * self.base_speed)
        else:
            self.stop()

    def try_dash(self) -> bool:
        if self.is_dashing:
            return False

        if not self.cooldowns.ready("dash"):
            return False

        if not self.stats.spend_stamina(PLAYER_DASH_STAMINA_COST):
            return False

        dx, dy = self.facing_x, self.facing_y
        if dx == 0 and dy == 0:
            dx, dy = 1.0, 0.0

        length = math.hypot(dx, dy)
        if length > 0:
            dx /= length
            dy /= length
        else:
            dx, dy = 1.0, 0.0

        self.is_dashing = True
        self.dash_timer = PLAYER_DASH_DURATION
        self.dash_dir_x = dx
        self.dash_dir_y = dy
        self.cooldowns.set("dash", PLAYER_DASH_COOLDOWN * self.progression_bonuses["dash_cooldown_multiplier"])
        return True

    def take_damage(self, amount: float) -> float:
        if self.damage_invuln_timer > 0:
            return 0.0

        dealt = super().take_damage(amount)
        if dealt > 0:
            self.damage_flash_timer = 0.16
            self.damage_invuln_timer = 0.45
        return dealt

    def recalculate_progression_bonuses(self) -> None:
        bonuses = self.progression.get_combat_bonuses()
        class_bonuses = self.get_class_bonuses()
        specialization_bonuses = self.get_specialization_bonuses()
        relic_bonuses = aggregate_relic_bonuses(self.inventory.get_items_by_type("relic"))
        self.relic_bonuses = relic_bonuses
        self.progression_bonuses = bonuses

        strength = self.get_core_stat("strength")
        dexterity = self.get_core_stat("dexterity")
        vitality = self.get_core_stat("vitality")
        endurance = self.get_core_stat("endurance")
        intelligence = self.get_core_stat("intelligence")
        level_growth = get_level_stat_growth(self.progression.level)

        self.build_snapshot = {
            "melee_mult": 1.0 + ((strength - 1) + level_growth) * 0.055,
            "ranged_mult": 1.0 + ((dexterity - 1) + level_growth) * 0.055,
            "magic_mult": 1.0 + ((intelligence - 1) + level_growth) * 0.055,
            "hp_bonus": ((vitality - 1) + level_growth) * 16.0,
            "stamina_bonus": ((endurance - 1) + level_growth) * 16.0,
            "mana_bonus": ((intelligence - 1) + level_growth) * 16.0,
            "speed_bonus": ((dexterity - 1) + level_growth * 0.5) * 3.0,
            "stamina_regen_bonus": ((endurance - 1) + level_growth * 0.5) * 2.5,
            "mana_regen_bonus": ((intelligence - 1) + level_growth * 0.5) * 0.7,
            "attack_power_bonus": ((strength - 1) + level_growth * 0.4) * 0.025,
            "cooldown_mod": max(0.72, 1.0 - ((dexterity - 1) + level_growth * 0.35) * 0.02),
        }

        self.stats.max_hp = PLAYER_MAX_HP + self.bonus_hp_from_levels + bonuses["bonus_max_hp"] + class_bonuses["bonus_hp"] + self.shop_bonus_hp + relic_bonuses["max_hp"] + self.build_snapshot["hp_bonus"] + specialization_bonuses["max_hp"]
        self.stats.max_mana = PLAYER_MAX_MANA + self.bonus_mana_from_levels + bonuses["bonus_max_mana"] + class_bonuses["bonus_mana"] + self.shop_bonus_mana + relic_bonuses["max_mana"] + self.build_snapshot["mana_bonus"] + specialization_bonuses["max_mana"]
        self.stats.max_stamina = PLAYER_MAX_STAMINA + self.bonus_stamina_from_levels + bonuses["bonus_stamina"] + relic_bonuses["stamina"] + self.build_snapshot["stamina_bonus"] + specialization_bonuses["stamina"]
        self.stats.mana_regen = 8.0 + bonuses["bonus_mana_regen"] + self.build_snapshot["mana_regen_bonus"]
        self.stats.stamina_regen = 18.0 + bonuses["bonus_stamina_regen"] + relic_bonuses["stamina_regen"] + self.build_snapshot["stamina_regen_bonus"]
        self.stats.attack_power = 1.0 + self.bonus_attack_power_from_levels + self.shop_bonus_attack + bonuses["bonus_attack_power"] + self.build_snapshot["attack_power_bonus"]
        self.base_speed = PLAYER_BASE_SPEED + self.bonus_speed_from_levels + bonuses["bonus_speed"] + class_bonuses["bonus_speed"] + relic_bonuses["speed"] + self.build_snapshot["speed_bonus"] + specialization_bonuses["speed"]
        self.stats.speed = self.base_speed

        self.stats.hp = min(self.stats.hp, self.stats.max_hp)
        self.stats.mana = min(self.stats.mana, self.stats.max_mana)
        self.stats.stamina = min(self.stats.stamina, self.stats.max_stamina)

    def get_skill_damage(self, action_name: str, base_damage: float) -> float:
        multiplier = 1.0
        class_bonuses = self.get_class_bonuses()
        specialization_bonuses = self.get_specialization_bonuses()
        if action_name == "basic_attack":
            multiplier = self.progression_bonuses["basic_damage_multiplier"] * class_bonuses["basic_mult"] + self.relic_bonuses["basic_mult"]
        elif action_name == "skill_1":
            multiplier = self.progression_bonuses["skill_1_damage_multiplier"] * class_bonuses["skill_1_mult"] + self.relic_bonuses["skill_1_mult"]
        elif action_name == "ult":
            multiplier = self.progression_bonuses["ult_damage_multiplier"] * class_bonuses["ult_mult"] + self.relic_bonuses["ult_mult"]
        elif action_name == "class_skill":
            multiplier = self.progression_bonuses["ult_damage_multiplier"] * class_bonuses["class_mult"] + self.relic_bonuses["class_skill_mult"]
        slot_map = {
            "basic_attack": "lmb",
            "skill_1": "q",
            "class_skill": "f",
            "ult": "y",
        }
        stat_mult = 1.0
        slot = slot_map.get(action_name)
        slot_modifier_mult = 1.0
        if slot is not None:
            scaling_stat = self.get_equipped_skill_def(slot).scaling_stat
            slot_modifier_mult = self.get_skill_modifier_data(slot)["damage_mult"]
            if scaling_stat == "strength":
                stat_mult = self.build_snapshot.get("melee_mult", 1.0)
            elif scaling_stat == "dexterity":
                stat_mult = self.build_snapshot.get("ranged_mult", 1.0)
            elif scaling_stat == "intelligence":
                stat_mult = self.build_snapshot.get("magic_mult", 1.0)
        return base_damage * self.stats.attack_power * multiplier * stat_mult * slot_modifier_mult * specialization_bonuses["damage_mult"]

    def get_skill_cooldown(self, action_name: str, base_cooldown: float) -> float:
        slot_map = {
            "basic_attack": "lmb",
            "skill_1": "q",
            "class_skill": "f",
            "ult": "y",
        }
        modifier_mult = 1.0
        slot = slot_map.get(action_name)
        if slot is not None:
            modifier_mult = self.get_skill_modifier_data(slot)["cooldown_mult"]
        specialization_mult = self.get_specialization_bonuses()["cooldown_mult"]
        if action_name == "skill_1":
            return base_cooldown * self.progression_bonuses["skill_1_cooldown_multiplier"] * self.get_class_bonuses()["skill_1_cd_mult"] * self.build_snapshot.get("cooldown_mod", 1.0) * modifier_mult * specialization_mult
        return base_cooldown * self.build_snapshot.get("cooldown_mod", 1.0) * modifier_mult * specialization_mult

    def get_skill_mana_cost(self, action_name: str, base_cost: float) -> float:
        slot_map = {
            "basic_attack": "lmb",
            "skill_1": "q",
            "class_skill": "f",
            "ult": "y",
        }
        modifier_mult = 1.0
        slot = slot_map.get(action_name)
        if slot is not None:
            modifier_mult = self.get_skill_modifier_data(slot)["cost_mult"]
        if action_name == "ult":
            return base_cost * self.progression_bonuses["ult_mana_cost_multiplier"] * modifier_mult
        return base_cost * modifier_mult

    def get_projectile_range(self, base_range: float) -> float:
        return base_range + self.progression_bonuses["skill_1_bonus_range"] + self.get_class_bonuses()["projectile_range"] + self.relic_bonuses["projectile_range"] + self.get_skill_modifier_data("q")["range_bonus"] + self.get_specialization_bonuses()["projectile_range"]

    def get_projectile_speed(self, base_speed: float) -> float:
        return base_speed + self.progression_bonuses["skill_1_bonus_speed"] + self.get_class_bonuses()["projectile_speed"] + self.relic_bonuses["projectile_speed"] + self.get_skill_modifier_data("q")["speed_bonus"] + self.get_specialization_bonuses()["projectile_speed"]

    def _cast_and_build_result(self, enemies: list[Entity], skill_func, action_name: str) -> bool:
        before_alive = {id(e): e.alive for e in enemies}
        before_hp = {id(e): e.stats.hp for e in enemies if hasattr(e, "stats")}

        hit = skill_func(self, enemies)

        result = {
            "type": action_name,
            "hit": hit,
            "damage": 0.0,
            "range": 0.0,
            "killed": False,
            "target_name": None,
        }

        if hit:
            for e in enemies:
                if not hasattr(e, "stats"):
                    continue

                old_hp = before_hp.get(id(e), e.stats.hp)
                damage_done = max(0.0, old_hp - e.stats.hp)

                if damage_done > 0:
                    result["damage"] += damage_done
                    result["range"] = self.distance_to(e)
                    if result["target_name"] is None:
                        result["target_name"] = e.name

                was_alive = before_alive.get(id(e), False)
                if was_alive and not e.alive:
                    result["killed"] = True
                    result["target_name"] = e.name

        self.last_attack_result = result
        return hit

    def try_basic_attack(self, enemies: list[Entity]) -> bool:
        return self._cast_and_build_result(enemies, self.skills.basic_attack, "basic_attack")

    def try_skill_1(self, enemies: list[Entity]) -> bool:
        projectile = self.skills.skill_1(self, enemies)
        self.last_attack_result = {
            "type": "skill_1",
            "hit": False,
            "damage": 0.0,
            "range": 0.0,
            "killed": False,
            "target_name": None,
        }

        if projectile is None:
            return False

        self.projectiles.append(projectile)
        return True

    def try_skill_1_projectile(self, dir_x: float, dir_y: float, enemies: list[Entity]) -> bool:
        length = math.hypot(dir_x, dir_y)
        if length <= 0:
            return False

        dir_x /= length
        dir_y /= length
        self.facing_x = dir_x
        self.facing_y = dir_y

        projectile = self.skills.skill_1(self, enemies, dir_x=dir_x, dir_y=dir_y)
        self.last_attack_result = {
            "type": "skill_1",
            "hit": False,
            "damage": 0.0,
            "range": 0.0,
            "killed": False,
            "target_name": None,
        }

        if projectile is None:
            return False

        self.projectiles.append(projectile)
        return True

    def try_ult(self, enemies: list[Entity]) -> bool:
        return self._cast_and_build_result(enemies, self.skills.ult_skill, "ult")

    def get_class_skill_name(self) -> str:
        return self.get_equipped_skill_name("f")

    def try_class_skill(self, enemies: list[Entity], dir_x: float = 0.0, dir_y: float = 0.0) -> bool:
        self.last_attack_result = {
            "type": "class_skill",
            "hit": False,
            "damage": 0.0,
            "range": 0.0,
            "killed": False,
            "target_name": None,
        }

        if not self.alive or not self.cooldowns.ready("class_skill"):
            return False

        skill_id = self.get_equipped_skill_id("f")
        if skill_id == "volley":
            return self._try_ranger_volley(dir_x, dir_y)
        if skill_id == "rift_burst":
            return self._cast_class_aoe(
                enemies,
                damage=AWAKENED_SKILL_DAMAGE,
                range_=AWAKENED_SKILL_RANGE,
                cooldown=AWAKENED_SKILL_COOLDOWN,
                mana_cost=AWAKENED_SKILL_MANA_COST,
                color=(170, 110, 255),
            )
        return self._cast_class_aoe(
            enemies,
            damage=STRIKER_SKILL_DAMAGE,
            range_=STRIKER_SKILL_RANGE,
            cooldown=STRIKER_SKILL_COOLDOWN,
            stamina_cost=STRIKER_SKILL_STAMINA_COST,
            color=(255, 124, 96),
        )

    def _cast_class_aoe(
        self,
        enemies: list[Entity],
        damage: float,
        range_: float,
        cooldown: float,
        mana_cost: float = 0.0,
        stamina_cost: float = 0.0,
        color=(255, 255, 255),
    ) -> bool:
        adjusted_mana_cost = self.get_skill_mana_cost("class_skill", mana_cost) if mana_cost > 0 else 0.0
        if adjusted_mana_cost > 0 and not self.stats.spend_mana(adjusted_mana_cost):
            return False
        if stamina_cost > 0 and not self.stats.spend_stamina(stamina_cost):
            if adjusted_mana_cost > 0:
                self.stats.mana = min(self.stats.max_mana, self.stats.mana + adjusted_mana_cost)
            return False

        hit_any = False
        total_damage = 0.0
        killed_name = None
        target_name = None
        adjusted_damage = self.get_skill_damage("class_skill", damage)

        for enemy in enemies:
            if not getattr(enemy, "alive", True):
                continue
            if self.distance_to(enemy) > range_:
                continue

            was_alive = enemy.alive
            dealt = enemy.take_damage(adjusted_damage)
            if dealt <= 0:
                continue

            hit_any = True
            total_damage += dealt
            if target_name is None:
                target_name = enemy.name
            if was_alive and not enemy.alive:
                killed_name = enemy.name

        if not hit_any:
            if adjusted_mana_cost > 0:
                self.stats.mana = min(self.stats.max_mana, self.stats.mana + adjusted_mana_cost)
            if stamina_cost > 0:
                self.stats.stamina = min(self.stats.max_stamina, self.stats.stamina + stamina_cost)
            return False

        self.cooldowns.set("class_skill", self.get_skill_cooldown("class_skill", cooldown))
        self.damage_flash_timer = max(self.damage_flash_timer, 0.12)
        self.last_attack_result = {
            "type": "class_skill",
            "hit": True,
            "damage": total_damage,
            "range": range_,
            "killed": killed_name is not None,
            "target_name": killed_name or target_name,
            "fx_color": color,
        }
        return True

    def _try_ranger_volley(self, dir_x: float, dir_y: float) -> bool:
        mana_cost = self.get_skill_mana_cost("class_skill", RANGER_SKILL_MANA_COST)
        if not self.stats.spend_mana(mana_cost):
            return False

        length = math.hypot(dir_x, dir_y)
        if length <= 0:
            dir_x, dir_y = self.facing_x, self.facing_y
            length = math.hypot(dir_x, dir_y)
        if length <= 0:
            dir_x, dir_y = 1.0, 0.0
            length = 1.0
        dir_x /= length
        dir_y /= length

        self.facing_x = dir_x
        self.facing_y = dir_y

        for offset in (-0.18, 0.0, 0.18):
            cos_v = math.cos(offset)
            sin_v = math.sin(offset)
            shot_x = dir_x * cos_v - dir_y * sin_v
            shot_y = dir_x * sin_v + dir_y * cos_v
            spawn_x = self.x + shot_x * (self.radius + RANGER_SKILL_PROJECTILE_RADIUS + 2)
            spawn_y = self.y + shot_y * (self.radius + RANGER_SKILL_PROJECTILE_RADIUS + 2)
            self.projectiles.append(
                PlayerProjectile(
                    x=spawn_x,
                    y=spawn_y,
                    dir_x=shot_x,
                    dir_y=shot_y,
                    speed=self.get_projectile_speed(RANGER_SKILL_PROJECTILE_SPEED),
                    damage=self.get_skill_damage("class_skill", RANGER_SKILL_DAMAGE),
                    radius=RANGER_SKILL_PROJECTILE_RADIUS,
                    max_distance=self.get_projectile_range(RANGER_SKILL_PROJECTILE_RANGE),
                    color=(120, 255, 210),
                    action_name="class_skill",
                )
            )

        self.cooldowns.set("class_skill", self.get_skill_cooldown("class_skill", RANGER_SKILL_COOLDOWN))
        return True

    def reward_kill(self, enemy_name: str = "") -> list[int]:
        xp_gain = self.xp_for_enemy_name(enemy_name)
        mastery_gain = 4
        lowered = enemy_name.lower()
        if "elite" in lowered:
            mastery_gain = 8
        if "boss" in lowered:
            mastery_gain = 14
        if "ss" in lowered or "monarch" in lowered:
            mastery_gain = 20

        levels = self.progression.add_xp(xp_gain)
        self.gain_class_mastery(mastery_gain)

        for _ in levels:
            self.bonus_hp_from_levels += 10
            self.bonus_mana_from_levels += 5
            self.bonus_stamina_from_levels += 5
            self.bonus_attack_power_from_levels += 0.08
            self.bonus_speed_from_levels += 3
            self.build_points += 2

        self.recalculate_progression_bonuses()
        self.stats.hp = min(self.stats.max_hp, self.stats.hp + 10)
        self.stats.mana = min(self.stats.max_mana, self.stats.mana + 5)
        self.stats.stamina = min(self.stats.max_stamina, self.stats.stamina + 5)

        return levels

    def grant_loot_for_kill(self, enemy_name: str = "") -> str:
        lowered = enemy_name.lower()
        loot_parts: list[str] = []
        potion_qty = 0
        mana_qty = 0
        stamina_qty = 0
        gold_qty = 0

        if "ss" in lowered or "monarch" in lowered:
            potion_qty = random.randint(2, 3)
            mana_qty = random.randint(1, 2)
            stamina_qty = random.randint(1, 2)
            gold_qty = random.randint(18, 32)
        elif "boss" in lowered:
            potion_qty = random.randint(1, 2)
            mana_qty = 1 if random.random() < 0.85 else 0
            stamina_qty = 1 if random.random() < 0.75 else 0
            gold_qty = random.randint(10, 18)
        elif "elite" in lowered:
            potion_qty = 1 if random.random() < 0.65 else 0
            mana_qty = 1 if random.random() < 0.35 else 0
            stamina_qty = 1 if random.random() < 0.35 else 0
            gold_qty = random.randint(4, 8)
        else:
            potion_qty = 1 if random.random() < 0.28 else 0
            mana_qty = 1 if random.random() < 0.14 else 0
            stamina_qty = 1 if random.random() < 0.14 else 0
            gold_qty = random.randint(1, 3) if random.random() < 0.55 else 0

        if potion_qty > 0 and self.inventory.add_item("healing_potion", "Healing Potion", potion_qty, "consumable"):
            loot_parts.append(f"+{potion_qty} Healing Potion")
        if mana_qty > 0 and self.inventory.add_item("mana_potion", "Mana Potion", mana_qty, "consumable"):
            loot_parts.append(f"+{mana_qty} Mana Potion")
        if stamina_qty > 0 and self.inventory.add_item("stamina_tonic", "Stamina Tonic", stamina_qty, "consumable"):
            loot_parts.append(f"+{stamina_qty} Stamina Tonic")
        if gold_qty > 0:
            self.add_gold(gold_qty)
            loot_parts.append(f"+{gold_qty}G")

        relic = roll_relic(enemy_name, self.current_gate_rank)
        if relic is not None:
            added = self.inventory.add_item(
                relic["item_id"],
                relic["name"],
                1,
                "relic",
                description=relic["description"],
                bonuses=relic["bonuses"],
            )
            if added:
                loot_parts.append(f"+Relic {relic['name']}")
                self.recalculate_progression_bonuses()

        return " | ".join(loot_parts)

    def use_healing_potion(self) -> tuple[bool, str]:
        if not self.alive:
            return False, "Cannot use while dead"

        potion = self.inventory.get_item("healing_potion")
        if potion is None or potion.get("quantity", 0) <= 0:
            return False, "No Healing Potion"

        if self.stats.hp >= self.stats.max_hp:
            return False, "HP already full"

        healed = self.heal(HEALING_POTION_HEAL)
        if healed <= 0:
            return False, "Potion wasted"

        self.inventory.remove_item("healing_potion", 1)
        return True, f"Used Healing Potion +{int(healed)} HP"

    def use_mana_potion(self) -> tuple[bool, str]:
        if not self.alive:
            return False, "Cannot use while dead"

        potion = self.inventory.get_item("mana_potion")
        if potion is None or potion.get("quantity", 0) <= 0:
            return False, "No Mana Potion"

        if self.stats.mana >= self.stats.max_mana:
            return False, "Mana already full"

        restored = min(MANA_POTION_RESTORE, self.stats.max_mana - self.stats.mana)
        self.stats.mana += restored
        self.inventory.remove_item("mana_potion", 1)
        return True, f"Used Mana Potion +{int(restored)} Mana"

    def use_stamina_tonic(self) -> tuple[bool, str]:
        if not self.alive:
            return False, "Cannot use while dead"

        tonic = self.inventory.get_item("stamina_tonic")
        if tonic is None or tonic.get("quantity", 0) <= 0:
            return False, "No Stamina Tonic"

        if self.stats.stamina >= self.stats.max_stamina:
            return False, "Stamina already full"

        restored = min(STAMINA_TONIC_RESTORE, self.stats.max_stamina - self.stats.stamina)
        self.stats.stamina += restored
        self.inventory.remove_item("stamina_tonic", 1)
        return True, f"Used Stamina Tonic +{int(restored)} Stamina"

    def add_gold(self, amount: int) -> int:
        amount = max(0, int(amount))
        self.gold += amount
        return amount

    def spend_gold(self, amount: int) -> bool:
        amount = max(0, int(amount))
        if self.gold < amount:
            return False
        self.gold -= amount
        return True

    def get_debug_state(self) -> dict:
        return {
            "hp": round(self.stats.hp, 1),
            "mana": round(self.stats.mana, 1),
            "stamina": round(self.stats.stamina, 1),
            "dash_cd": round(self.cooldowns.remaining("dash"), 2),
            "basic_cd": round(self.cooldowns.remaining("basic_attack"), 2),
            "skill_1_cd": round(self.cooldowns.remaining("skill_1"), 2),
            "class_skill_cd": round(self.cooldowns.remaining("class_skill"), 2),
            "ult_cd": round(self.cooldowns.remaining("ult"), 2),
            "inventory_open": self.inventory_open,
            "skill_tree_open": self.skill_tree_open,
            "is_dashing": self.is_dashing,
            "invuln": round(self.damage_invuln_timer, 2),
            "projectiles": len(self.projectiles),
            "level": self.progression.level,
            "xp": self.progression.xp,
            "xp_next": self.progression.xp_to_next_level(),
            "stat_points": self.progression.stat_points,
            "skill_points": self.progression.skill_points,
            "class_id": self.class_id,
            "core_stats": dict(self.core_stats),
            "build_points": self.build_points,
            "loadout": self.get_loadout_summary(),
            "skill_modifiers": dict(self.skill_modifiers),
            "gold": self.gold,
            "class_mastery_level": self.get_class_mastery_state()["level"],
            "class_mastery_xp": self.get_class_mastery_state()["xp"],
            "passive_slots": self.progression.passive_summary(self.get_class_mastery_state()["level"]),
            "specialization": self.progression.selected_specialization,
        }

    def update_projectiles(self, dt: float, enemies: list[Entity], world_rect: pygame.Rect | None = None) -> None:
        remaining: list[PlayerProjectile] = []
        wall_rects = getattr(self, "navigation_walls", [])

        for projectile in self.projectiles:
            projectile.update(dt, world_rect, wall_rects)

            if not projectile.alive:
                continue

            hit_enemy = None
            for enemy in enemies:
                if projectile.collides_with(enemy):
                    hit_enemy = enemy
                    break

            if hit_enemy is not None:
                was_alive = hit_enemy.alive
                damage_done = hit_enemy.take_damage(projectile.damage)
                self.last_attack_result = {
                    "type": projectile.action_name,
                    "hit": damage_done > 0,
                    "damage": damage_done,
                    "range": self.distance_to(hit_enemy),
                    "killed": was_alive and not hit_enemy.alive,
                    "target_name": hit_enemy.name,
                }
                projectile.alive = False

            if projectile.alive:
                remaining.append(projectile)

        self.projectiles = remaining

    def draw(self, surface: pygame.Surface, cam_x: float = 0.0, cam_y: float = 0.0, draw_hp_bar: bool = True) -> None:
        if not self.alive:
            return

        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)

        shadow = pygame.Surface((int(self.radius * 2.6), int(self.radius * 1.3)), pygame.SRCALPHA)
        pygame.draw.ellipse(shadow, (0, 0, 0, 86), (0, 0, shadow.get_width(), shadow.get_height()))
        surface.blit(shadow, (sx - shadow.get_width() // 2, sy + int(self.radius * 0.55)))

        pygame.draw.circle(surface, (245, 250, 255), (sx, sy), int(self.radius + 2))
        pygame.draw.circle(surface, self.color, (sx, sy), int(self.radius))

        fx = sx + int(self.facing_x * self.radius)
        fy = sy + int(self.facing_y * self.radius)
        pygame.draw.line(surface, (255, 255, 255), (sx, sy), (fx, fy), 2)

        if self.cooldowns.remaining("skill_1") <= 0:
            pygame.draw.circle(surface, YELLOW, (sx, sy), int(self.radius + 4), 1)

        if self.cooldowns.remaining("ult") <= 0:
            pygame.draw.circle(surface, CYAN, (sx, sy), int(self.radius + 8), 1)

        if self.cooldowns.remaining("class_skill") <= 0:
            pygame.draw.circle(surface, (142, 255, 196), (sx, sy), int(self.radius + 12), 1)

        if self.damage_flash_timer > 0:
            pygame.draw.circle(surface, (255, 255, 255), (sx, sy), int(self.radius + 5), 2)

        if draw_hp_bar:
            self.draw_health_bar(surface, sx, sy)

        for projectile in self.projectiles:
            projectile.draw(surface, cam_x, cam_y)
