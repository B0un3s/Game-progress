# game/player/inventory.py

from __future__ import annotations


class Inventory:
    def __init__(self, max_slots: int = 24):
        self.max_slots = max(1, int(max_slots))
        self.items: list[dict] = []

    def add_item(self, item_id: str, name: str, quantity: int = 1, item_type: str = "misc", **extra) -> bool:
        quantity = max(1, int(quantity))

        for item in self.items:
            if item["item_id"] == item_id and item.get("item_type", "misc") != "relic":
                item["quantity"] += quantity
                for key, value in extra.items():
                    item[key] = value
                return True

        if len(self.items) >= self.max_slots:
            return False

        item = {
            "item_id": item_id,
            "name": name,
            "quantity": quantity,
            "item_type": item_type,
        }
        item.update(extra)
        self.items.append(item)
        return True

    def remove_item(self, item_id: str, quantity: int = 1) -> bool:
        quantity = max(1, int(quantity))

        for item in self.items:
            if item["item_id"] == item_id:
                if item["quantity"] < quantity:
                    return False

                item["quantity"] -= quantity

                if item["quantity"] <= 0:
                    self.items.remove(item)

                return True

        return False

    def has_item(self, item_id: str, quantity: int = 1) -> bool:
        quantity = max(1, int(quantity))

        for item in self.items:
            if item["item_id"] == item_id and item["quantity"] >= quantity:
                return True
        return False

    def get_item(self, item_id: str) -> dict | None:
        for item in self.items:
            if item["item_id"] == item_id:
                return item
        return None

    def get_items_by_type(self, item_type: str) -> list[dict]:
        return [item for item in self.items if item.get("item_type") == item_type]

    def clear(self) -> None:
        self.items.clear()

    def is_full(self) -> bool:
        return len(self.items) >= self.max_slots

    def free_slots(self) -> int:
        return self.max_slots - len(self.items)

    def to_dict(self) -> dict:
        return {
            "max_slots": self.max_slots,
            "items": [dict(item) for item in self.items],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Inventory":
        if not isinstance(data, dict):
            inv = cls()
            if isinstance(data, list):
                inv.items = list(data)
            return inv
        inv = cls(max_slots=data.get("max_slots", 24))
        inv.items = list(data.get("items", []))
        return inv
