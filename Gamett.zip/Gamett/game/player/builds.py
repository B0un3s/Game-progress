from __future__ import annotations

from dataclasses import dataclass


CORE_STAT_ORDER = ["strength", "dexterity", "vitality", "endurance", "intelligence"]
CORE_STAT_LABELS = {
    "strength": "STR",
    "dexterity": "DEX",
    "vitality": "VIT",
    "endurance": "END",
    "intelligence": "INT",
}
DEFAULT_CORE_STATS = {stat_id: 1 for stat_id in CORE_STAT_ORDER}
STARTING_BUILD_POINTS = 8
CREATION_STAT_CAP = 5
LOADOUT_SLOTS = ["lmb", "q", "f", "y"]
SKILL_MODIFIER_ORDER = ["balanced", "power", "tempo", "reach"]


@dataclass(frozen=True)
class SkillDefinition:
    skill_id: str
    name: str
    slot: str
    skill_type: str
    scaling_stat: str
    archetypes: tuple[str, ...]
    description: str


@dataclass(frozen=True)
class ArchetypeDefinition:
    archetype_id: str
    display_name: str
    stat_bias: str
    playstyle: str
    starting_loadout: dict[str, str]


SKILL_DEFS: dict[str, SkillDefinition] = {
    "vanguard_strike": SkillDefinition("vanguard_strike", "Vanguard Strike", "lmb", "melee", "strength", ("striker",), "Measured frontline strike with solid impact."),
    "quick_cut": SkillDefinition("quick_cut", "Quick Cut", "lmb", "melee", "dexterity", ("ranger", "striker"), "Fast low-commitment slash for mobile play."),
    "soul_siphon": SkillDefinition("soul_siphon", "Soul Siphon", "lmb", "magic", "intelligence", ("awakened",), "Short arcane swipe that feeds mana on contact."),
    "piercing_bolt": SkillDefinition("piercing_bolt", "Piercing Bolt", "q", "ranged", "dexterity", ("ranger", "awakened"), "Fast linear projectile with long reach."),
    "fan_knives": SkillDefinition("fan_knives", "Fan Knives", "q", "ranged", "dexterity", ("ranger",), "Wide spread throw that rewards spacing."),
    "rift_orb": SkillDefinition("rift_orb", "Rift Orb", "q", "magic", "intelligence", ("awakened",), "Slow orb with larger hit volume and magical pressure."),
    "shockwave": SkillDefinition("shockwave", "Shockwave", "f", "melee", "strength", ("striker",), "Close-range force burst for bruiser pressure."),
    "volley": SkillDefinition("volley", "Volley", "f", "ranged", "dexterity", ("ranger",), "Three-shot burst for ranged control."),
    "rift_burst": SkillDefinition("rift_burst", "Rift Burst", "f", "magic", "intelligence", ("awakened",), "Arcane eruption for hybrid burst windows."),
    "earthsplitter": SkillDefinition("earthsplitter", "Earthsplitter", "y", "melee", "strength", ("striker",), "Heavy ultimate that rewards close commitment."),
    "rain_of_fangs": SkillDefinition("rain_of_fangs", "Rain of Fangs", "y", "ranged", "dexterity", ("ranger",), "Multi-target ranged finisher."),
    "void_nova": SkillDefinition("void_nova", "Void Nova", "y", "magic", "intelligence", ("awakened",), "Large magical detonation with mana-focused payoff."),
}


ARCHETYPES: dict[str, ArchetypeDefinition] = {
    "striker": ArchetypeDefinition(
        archetype_id="striker",
        display_name="Striker",
        stat_bias="Strength / Vitality / Endurance",
        playstyle="Balanced melee hunter with strong frontline pressure.",
        starting_loadout={
            "lmb": "vanguard_strike",
            "q": "piercing_bolt",
            "f": "shockwave",
            "y": "earthsplitter",
        },
    ),
    "ranger": ArchetypeDefinition(
        archetype_id="ranger",
        display_name="Ranger",
        stat_bias="Dexterity / Endurance / Intelligence",
        playstyle="Fast skirmisher built around spacing and precision.",
        starting_loadout={
            "lmb": "quick_cut",
            "q": "fan_knives",
            "f": "volley",
            "y": "rain_of_fangs",
        },
    ),
    "awakened": ArchetypeDefinition(
        archetype_id="awakened",
        display_name="Awakened",
        stat_bias="Intelligence / Dexterity / Vitality",
        playstyle="Magic hybrid with explosive skill identity.",
        starting_loadout={
            "lmb": "soul_siphon",
            "q": "rift_orb",
            "f": "rift_burst",
            "y": "void_nova",
        },
    ),
}

SKILL_MODIFIERS = {
    "balanced": {
        "name": "Balanced",
        "description": "No bias. Reliable default tuning.",
        "damage_mult": 1.0,
        "cooldown_mult": 1.0,
        "cost_mult": 1.0,
        "range_bonus": 0.0,
        "speed_bonus": 0.0,
    },
    "power": {
        "name": "Power",
        "description": "Higher impact with slightly slower rotations.",
        "damage_mult": 1.18,
        "cooldown_mult": 1.08,
        "cost_mult": 1.06,
        "range_bonus": 0.0,
        "speed_bonus": 0.0,
    },
    "tempo": {
        "name": "Tempo",
        "description": "Faster cycle with lighter individual hits.",
        "damage_mult": 0.92,
        "cooldown_mult": 0.84,
        "cost_mult": 0.88,
        "range_bonus": 0.0,
        "speed_bonus": 0.0,
    },
    "reach": {
        "name": "Reach",
        "description": "Extended control space with slightly softer damage.",
        "damage_mult": 0.95,
        "cooldown_mult": 1.0,
        "cost_mult": 1.0,
        "range_bonus": 38.0,
        "speed_bonus": 54.0,
    },
}

SPECIALIZATIONS = {
    "striker": (
        {
            "spec_id": "juggernaut",
            "name": "Juggernaut",
            "description": "Turns branch completion into raw frontline dominance.",
            "required_branches": 1,
            "mastery_required": 8,
            "level_required": 75,
            "bonuses": {"max_hp": 42.0, "damage_mult": 1.08, "speed": -4.0},
        },
        {
            "spec_id": "reaver",
            "name": "Reaver",
            "description": "Aggressive finisher path with higher damage tempo.",
            "required_branches": 2,
            "mastery_required": 12,
            "level_required": 110,
            "bonuses": {"damage_mult": 1.12, "cooldown_mult": 0.94, "lifesteal": 0.03},
        },
        {
            "spec_id": "warlord",
            "name": "Warlord",
            "description": "Endgame capstone bruiser that rewards full class commitment.",
            "required_branches": 3,
            "mastery_required": 16,
            "level_required": 150,
            "bonuses": {"damage_mult": 1.1, "max_hp": 60.0, "stamina": 28.0},
        },
    ),
    "ranger": (
        {
            "spec_id": "deadeye",
            "name": "Deadeye",
            "description": "Sharper ranged scaling and projectile pressure.",
            "required_branches": 1,
            "mastery_required": 8,
            "level_required": 75,
            "bonuses": {"damage_mult": 1.08, "projectile_range": 60.0, "projectile_speed": 80.0},
        },
        {
            "spec_id": "shadowrunner",
            "name": "Shadowrunner",
            "description": "Leans into rapid repositioning and relentless uptime.",
            "required_branches": 2,
            "mastery_required": 12,
            "level_required": 110,
            "bonuses": {"speed": 18.0, "cooldown_mult": 0.9, "damage_mult": 1.04},
        },
        {
            "spec_id": "trapmaster",
            "name": "Trapmaster",
            "description": "Late-game control hunter with superior skill pacing.",
            "required_branches": 3,
            "mastery_required": 16,
            "level_required": 150,
            "bonuses": {"cooldown_mult": 0.88, "projectile_range": 90.0, "damage_mult": 1.08},
        },
    ),
    "awakened": (
        {
            "spec_id": "spellblade",
            "name": "Spellblade",
            "description": "Hybrid specialization that boosts close-range magic burst.",
            "required_branches": 1,
            "mastery_required": 8,
            "level_required": 75,
            "bonuses": {"damage_mult": 1.08, "max_mana": 28.0, "cooldown_mult": 0.96},
        },
        {
            "spec_id": "voidcaller",
            "name": "Voidcaller",
            "description": "Harder-hitting spell path with stronger mana reserves.",
            "required_branches": 2,
            "mastery_required": 12,
            "level_required": 110,
            "bonuses": {"damage_mult": 1.12, "max_mana": 44.0, "projectile_speed": 70.0},
        },
        {
            "spec_id": "phaseweaver",
            "name": "Phaseweaver",
            "description": "Late-game dimensional master with superior flow and reach.",
            "required_branches": 3,
            "mastery_required": 16,
            "level_required": 150,
            "bonuses": {"cooldown_mult": 0.88, "damage_mult": 1.08, "projectile_range": 70.0, "speed": 14.0},
        },
    ),
}


def sanitize_core_stats(stats: dict | None) -> dict[str, int]:
    sanitized = dict(DEFAULT_CORE_STATS)
    if isinstance(stats, dict):
        for stat_id in CORE_STAT_ORDER:
            sanitized[stat_id] = max(1, int(stats.get(stat_id, sanitized[stat_id])))
    return sanitized


def get_archetype(archetype_id: str) -> ArchetypeDefinition:
    return ARCHETYPES.get(str(archetype_id), ARCHETYPES["striker"])


def get_skill_def(skill_id: str) -> SkillDefinition:
    return SKILL_DEFS[skill_id]


def get_slot_skill_defs(slot: str) -> list[SkillDefinition]:
    return [skill for skill in SKILL_DEFS.values() if skill.slot == slot]


def make_default_loadout(archetype_id: str) -> dict[str, str]:
    archetype = get_archetype(archetype_id)
    return dict(archetype.starting_loadout)


def make_default_unlocked_skills() -> list[str]:
    return list({
        make_default_loadout("striker")[slot]
        for slot in LOADOUT_SLOTS
    })


def get_level_stat_growth(level: int) -> float:
    level = max(1, int(level))
    extra_levels = level - 1
    full = min(extra_levels, 20)
    extra_levels -= full
    mid = min(extra_levels, 30)
    extra_levels -= mid
    late = min(extra_levels, 50)
    extra_levels -= late
    endless = max(0, extra_levels)
    return full * 1.0 + mid * 0.7 + late * 0.4 + endless * 0.2


def make_default_skill_modifiers() -> dict[str, str]:
    return {slot: "balanced" for slot in LOADOUT_SLOTS}


def sanitize_skill_modifiers(modifiers: dict | None) -> dict[str, str]:
    sanitized = make_default_skill_modifiers()
    if isinstance(modifiers, dict):
        for slot in LOADOUT_SLOTS:
            modifier_id = str(modifiers.get(slot, sanitized[slot]))
            if modifier_id in SKILL_MODIFIERS:
                sanitized[slot] = modifier_id
    return sanitized


def get_skill_modifier(modifier_id: str) -> dict:
    return SKILL_MODIFIERS.get(str(modifier_id), SKILL_MODIFIERS["balanced"])


def cycle_skill_modifier(current_modifier_id: str, direction: int = 1) -> str:
    if current_modifier_id not in SKILL_MODIFIER_ORDER:
        return SKILL_MODIFIER_ORDER[0]
    index = SKILL_MODIFIER_ORDER.index(current_modifier_id)
    return SKILL_MODIFIER_ORDER[(index + direction) % len(SKILL_MODIFIER_ORDER)]


def get_specializations(archetype_id: str) -> tuple[dict, ...]:
    return SPECIALIZATIONS.get(str(archetype_id), ())


def sanitize_loadout(loadout: dict | None, archetype_id: str) -> dict[str, str]:
    sanitized = make_default_loadout(archetype_id)
    if isinstance(loadout, dict):
        for slot in LOADOUT_SLOTS:
            skill_id = str(loadout.get(slot, sanitized[slot]))
            if skill_id in SKILL_DEFS and SKILL_DEFS[skill_id].slot == slot:
                sanitized[slot] = skill_id
    return sanitized


def cycle_slot_skill(slot: str, current_skill_id: str, direction: int = 1, unlocked_ids: list[str] | None = None) -> str:
    available = [skill.skill_id for skill in get_slot_skill_defs(slot) if unlocked_ids is None or skill.skill_id in unlocked_ids]
    if not available:
        return current_skill_id
    if current_skill_id not in available:
        return available[0]
    index = available.index(current_skill_id)
    return available[(index + direction) % len(available)]
