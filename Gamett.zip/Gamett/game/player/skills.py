# game/player/skills.py

from __future__ import annotations

from game.config import (
    PLAYER_BASIC_DAMAGE,
    PLAYER_BASIC_RANGE,
    PLAYER_BASIC_COOLDOWN,
    PLAYER_SKILL1_DAMAGE,
    PLAYER_SKILL1_RANGE,
    PLAYER_SKILL1_COOLDOWN,
    PLAYER_SKILL1_MANA_COST,
    PLAYER_SKILL1_PROJECTILE_SPEED,
    PLAYER_SKILL1_PROJECTILE_RADIUS,
    PLAYER_ULT_DAMAGE,
    PLAYER_ULT_RANGE,
    PLAYER_ULT_COOLDOWN,
    PLAYER_ULT_MANA_COST,
)
from game.player.projectile import PlayerProjectile


class Skill:
    def __init__(self, name: str, damage: float, mana_cost: float, cooldown: float, range_: float):
        self.name = name
        self.damage = float(damage)
        self.mana_cost = float(mana_cost)
        self.cooldown = float(cooldown)
        self.range = float(range_)

    def can_cast(self, player) -> bool:
        mana_cost = player.get_skill_mana_cost(self.name, self.mana_cost)
        if not getattr(player, "alive", True):
            return False
        if player.stats.mana < mana_cost:
            return False
        if not player.cooldowns.ready(self.name):
            return False
        return True

    def cast(self, player, enemies: list) -> bool:
        if not self.can_cast(player):
            return False

        best_target = None
        best_dist = 999999.0

        for enemy in enemies:
            if not getattr(enemy, "alive", True):
                continue

            dist = player.distance_to(enemy)
            if dist <= self.range and dist < best_dist:
                best_dist = dist
                best_target = enemy

        if best_target is None:
            return False

        if not player.stats.spend_mana(player.get_skill_mana_cost(self.name, self.mana_cost)):
            return False

        player.cooldowns.set(self.name, player.get_skill_cooldown(self.name, self.cooldown))
        best_target.take_damage(player.get_skill_damage(self.name, self.damage))
        return True


class AoeSkill(Skill):
    def cast(self, player, enemies: list) -> bool:
        if not self.can_cast(player):
            return False

        targets = []

        for enemy in enemies:
            if not getattr(enemy, "alive", True):
                continue

            dist = player.distance_to(enemy)
            if dist <= self.range:
                targets.append(enemy)

        if not targets:
            return False

        if not player.stats.spend_mana(player.get_skill_mana_cost(self.name, self.mana_cost)):
            return False

        player.cooldowns.set(self.name, player.get_skill_cooldown(self.name, self.cooldown))

        for target in targets:
            target.take_damage(player.get_skill_damage(self.name, self.damage))

        return True


class SkillSet:
    def __init__(self):
        self.basic = Skill(
            name="basic_attack",
            damage=PLAYER_BASIC_DAMAGE,
            mana_cost=0,
            cooldown=PLAYER_BASIC_COOLDOWN,
            range_=PLAYER_BASIC_RANGE,
        )

        self.skill1 = Skill(
            name="skill_1",
            damage=PLAYER_SKILL1_DAMAGE,
            mana_cost=PLAYER_SKILL1_MANA_COST,
            cooldown=PLAYER_SKILL1_COOLDOWN,
            range_=PLAYER_SKILL1_RANGE,
        )

        self.ult = AoeSkill(
            name="ult",
            damage=PLAYER_ULT_DAMAGE,
            mana_cost=PLAYER_ULT_MANA_COST,
            cooldown=PLAYER_ULT_COOLDOWN,
            range_=PLAYER_ULT_RANGE,
        )

    def basic_attack(self, player, enemies):
        skill_id = player.get_equipped_skill_id("lmb")
        if skill_id == "quick_cut":
            return self._cast_custom_targeted(player, enemies, base_damage=PLAYER_BASIC_DAMAGE * 0.82, cooldown=PLAYER_BASIC_COOLDOWN * 0.62, range_=PLAYER_BASIC_RANGE * 0.92)
        if skill_id == "soul_siphon":
            hit = self._cast_custom_targeted(player, enemies, base_damage=PLAYER_BASIC_DAMAGE * 0.94, cooldown=PLAYER_BASIC_COOLDOWN * 0.9, range_=PLAYER_BASIC_RANGE * 1.18)
            if hit:
                player.stats.restore_mana(4.0)
            return hit
        return self._cast_custom_targeted(player, enemies, base_damage=PLAYER_BASIC_DAMAGE * 1.12, cooldown=PLAYER_BASIC_COOLDOWN * 1.05, range_=PLAYER_BASIC_RANGE * 1.06)

    def _cast_custom_targeted(self, player, enemies: list, *, base_damage: float, cooldown: float, range_: float) -> bool:
        if not getattr(player, "alive", True):
            return False
        if not player.cooldowns.ready("basic_attack"):
            return False

        best_target = None
        best_dist = 999999.0
        for enemy in enemies:
            if not getattr(enemy, "alive", True):
                continue
            dist = player.distance_to(enemy)
            if dist <= range_ and dist < best_dist:
                best_dist = dist
                best_target = enemy

        if best_target is None:
            return False

        player.cooldowns.set("basic_attack", player.get_skill_cooldown("basic_attack", cooldown))
        best_target.take_damage(player.get_skill_damage("basic_attack", base_damage))
        return True

    def _spawn_projectile(
        self,
        player,
        dir_x: float,
        dir_y: float,
        *,
        speed_mult: float,
        damage_mult: float,
        radius_delta: float,
        range_mult: float,
        color,
    ):
        if not self.skill1.can_cast(player):
            return None

        if not player.stats.spend_mana(player.get_skill_mana_cost(self.skill1.name, self.skill1.mana_cost)):
            return None

        player.cooldowns.set(
            self.skill1.name,
            player.get_skill_cooldown(self.skill1.name, self.skill1.cooldown),
        )

        if dir_x == 0 and dir_y == 0:
            dir_x, dir_y = 1.0, 0.0

        radius = max(4.0, PLAYER_SKILL1_PROJECTILE_RADIUS + radius_delta)
        spawn_x = player.x + dir_x * (player.radius + radius + 2)
        spawn_y = player.y + dir_y * (player.radius + radius + 2)

        return PlayerProjectile(
            x=spawn_x,
            y=spawn_y,
            dir_x=dir_x,
            dir_y=dir_y,
            speed=player.get_projectile_speed(PLAYER_SKILL1_PROJECTILE_SPEED * speed_mult),
            damage=player.get_skill_damage(self.skill1.name, self.skill1.damage * damage_mult),
            radius=radius,
            max_distance=player.get_projectile_range(self.skill1.range * range_mult),
            color=color,
            action_name="skill_1",
        )

    def skill_1(self, player, enemies, dir_x: float | None = None, dir_y: float | None = None):
        if dir_x is None or dir_y is None:
            dir_x, dir_y = player.facing_x, player.facing_y
        if dir_x == 0 and dir_y == 0:
            dir_x, dir_y = 1.0, 0.0

        skill_id = player.get_equipped_skill_id("q")
        if skill_id == "fan_knives":
            return self._spawn_projectile(
                player,
                dir_x,
                dir_y,
                speed_mult=1.25,
                damage_mult=0.92,
                radius_delta=-1,
                range_mult=1.25,
                color=(110, 220, 255),
            )
        if skill_id == "rift_orb":
            return self._spawn_projectile(
                player,
                dir_x,
                dir_y,
                speed_mult=0.95,
                damage_mult=1.08,
                radius_delta=4,
                range_mult=0.95,
                color=(170, 110, 255),
            )
        return self._spawn_projectile(
            player,
            dir_x,
            dir_y,
            speed_mult=0.82,
            damage_mult=1.18,
            radius_delta=2,
            range_mult=0.72,
            color=(255, 138, 92),
        )

    def ult_skill(self, player, enemies):
        if not self.ult.can_cast(player):
            return False

        skill_id = player.get_equipped_skill_id("y")
        if skill_id == "rain_of_fangs":
            targets = [enemy for enemy in enemies if getattr(enemy, "alive", True)]
            targets.sort(key=player.distance_to)
            targets = [enemy for enemy in targets if player.distance_to(enemy) <= self.ult.range * 2.4][:4]
            if not targets:
                return False

            if not player.stats.spend_mana(player.get_skill_mana_cost(self.ult.name, self.ult.mana_cost)):
                return False
            player.cooldowns.set(self.ult.name, player.get_skill_cooldown(self.ult.name, self.ult.cooldown))

            damage = player.get_skill_damage(self.ult.name, self.ult.damage * 0.9)
            for target in targets:
                target.take_damage(damage)
            return True

        if skill_id == "void_nova":
            targets = [
                enemy for enemy in enemies
                if getattr(enemy, "alive", True) and player.distance_to(enemy) <= self.ult.range * 1.55
            ]
            if not targets:
                return False

            if not player.stats.spend_mana(player.get_skill_mana_cost(self.ult.name, self.ult.mana_cost)):
                return False
            player.cooldowns.set(self.ult.name, player.get_skill_cooldown(self.ult.name, self.ult.cooldown))

            damage = player.get_skill_damage(self.ult.name, self.ult.damage * 1.18)
            hit_count = 0
            for target in targets:
                dealt = target.take_damage(damage)
                if dealt > 0:
                    hit_count += 1
            if hit_count > 0:
                player.stats.restore_mana(min(24.0, 6.0 * hit_count))
            return hit_count > 0

        targets = [
            enemy for enemy in enemies
            if getattr(enemy, "alive", True) and player.distance_to(enemy) <= self.ult.range * 1.15
        ]
        if not targets:
            return False

        if not player.stats.spend_mana(player.get_skill_mana_cost(self.ult.name, self.ult.mana_cost)):
            return False
        player.cooldowns.set(self.ult.name, player.get_skill_cooldown(self.ult.name, self.ult.cooldown))

        damage = player.get_skill_damage(self.ult.name, self.ult.damage * 1.25)
        hit_count = 0
        for target in targets:
            dealt = target.take_damage(damage)
            if dealt > 0:
                hit_count += 1
        if hit_count > 0:
            player.stats.restore_stamina(min(30.0, 10.0 * hit_count))
        return hit_count > 0
