# game/ui/menu.py

from __future__ import annotations

import math
import pygame

from game.config import WHITE, CYAN, RED, GREEN, GRAY, GATE_RANK_ORDER
from game.player.classes import HUNTER_CLASSES, get_hunter_class
from game.player.builds import CORE_STAT_LABELS


class MenuUI:
    """
    Cinematic main menu/title screen inspired by the reference image.

    No external images needed. Everything is drawn with pygame shapes:
    - huge logo top-left
    - vertical left menu
    - central hunter silhouette + glowing portal
    - right class/loadout/control panels
    - bottom status bar
    """

    def __init__(self):
        pygame.font.init()
        self.frame = 0
        self.mouse_pos = (-1, -1)
        self._interactive_regions: list[tuple[pygame.Rect, str]] = []
        self.title_focus = "begin_hunt"
        self.pending_keybind_action: str | None = None
        self.keybind_labels: dict[str, str] = {}
        self._make_default_fonts()

    # ------------------------------------------------------------------
    # FONTS / HELPERS
    # ------------------------------------------------------------------

    def _make_default_fonts(self):
        self.font_logo = pygame.font.SysFont("georgia", 78, bold=True)
        self.font_logo_shadow = pygame.font.SysFont("georgia", 88, bold=True)
        self.font_title = pygame.font.SysFont("trebuchetms", 25, bold=True)
        self.font_menu = pygame.font.SysFont("trebuchetms", 25, bold=True)
        self.font_body = pygame.font.SysFont("trebuchetms", 18)
        self.font_body_bold = pygame.font.SysFont("trebuchetms", 18, bold=True)
        self.font_small = pygame.font.SysFont("trebuchetms", 14)
        self.font_tiny = pygame.font.SysFont("trebuchetms", 12)

    def _clamp(self, value, lo, hi):
        return max(lo, min(hi, value))

    def _make_fonts(self, surface):
        w, h = surface.get_size()
        scale = min(w / 1280, h / 720)

        self.font_logo = pygame.font.SysFont("georgia", self._clamp(int(78 * scale), 48, 96), bold=True)
        self.font_logo_shadow = pygame.font.SysFont("georgia", self._clamp(int(88 * scale), 58, 110), bold=True)
        self.font_title = pygame.font.SysFont("trebuchetms", self._clamp(int(25 * scale), 18, 31), bold=True)
        self.font_menu = pygame.font.SysFont("trebuchetms", self._clamp(int(25 * scale), 18, 31), bold=True)
        self.font_body = pygame.font.SysFont("trebuchetms", self._clamp(int(18 * scale), 14, 22))
        self.font_body_bold = pygame.font.SysFont("trebuchetms", self._clamp(int(18 * scale), 14, 22), bold=True)
        self.font_small = pygame.font.SysFont("trebuchetms", self._clamp(int(14 * scale), 11, 17))
        self.font_tiny = pygame.font.SysFont("trebuchetms", self._clamp(int(12 * scale), 9, 14))

    def _text(self, surface, text, font, color, x, y):
        img = font.render(str(text), True, color)
        surface.blit(img, (int(x), int(y)))
        return img

    def _center_text_in(self, surface, rect, text, font, color):
        img = font.render(str(text), True, color)
        surface.blit(img, (rect.centerx - img.get_width() // 2, rect.centery - img.get_height() // 2))
        return img

    def _wrap(self, text, font, max_width):
        words = str(text).split()
        if not words:
            return [""]
        lines = []
        current = words[0]
        for word in words[1:]:
            test = current + " " + word
            if font.size(test)[0] <= max_width:
                current = test
            else:
                lines.append(current)
                current = word
        lines.append(current)
        return lines

    def _wrapped(self, surface, text, font, color, x, y, max_width, gap=5, max_lines=None):
        lines = self._wrap(text, font, max_width)
        if max_lines is not None:
            lines = lines[:max_lines]
        for line in lines:
            self._text(surface, line, font, color, x, y)
            y += font.get_height() + gap
        return y

    def _lerp(self, a, b, t):
        return int(a + (b - a) * t)

    def _poly_button_rect(self, rect, cut=22):
        return [
            (rect.x, rect.y),
            (rect.right - cut, rect.y),
            (rect.right, rect.centery),
            (rect.right - cut, rect.bottom),
            (rect.x, rect.bottom),
        ]

    def set_mouse_pos(self, pos: tuple[int, int]) -> None:
        self.mouse_pos = (int(pos[0]), int(pos[1]))

    def _begin_interaction_frame(self) -> None:
        self._interactive_regions = []

    def _register_interaction(self, rect: pygame.Rect, action: str) -> None:
        self._interactive_regions.append((rect.copy(), action))

    def _is_hovered(self, rect: pygame.Rect) -> bool:
        return rect.collidepoint(self.mouse_pos)

    def handle_click(self, pos: tuple[int, int]) -> str | None:
        tab_order = ["begin_hunt", "options", "loadout", "codex"]
        for rect, action in reversed(self._interactive_regions):
            if rect.collidepoint(pos):
                if action == "title_next":
                    current_index = tab_order.index(self.title_focus) if self.title_focus in tab_order else 0
                    self.title_focus = tab_order[(current_index + 1) % len(tab_order)]
                    return None
                if action in {"title_options", "title_loadout", "title_codex"}:
                    self.title_focus = action.removeprefix("title_")
                    return None
                return action
        return None

    # ------------------------------------------------------------------
    # BACKGROUND ART
    # ------------------------------------------------------------------

    def _draw_background(self, surface):
        self.frame += 1
        w, h = surface.get_size()

        top = (1, 4, 12)
        mid = (5, 13, 34)
        bot = (7, 18, 38)

        for y in range(h):
            t = y / max(1, h - 1)
            if t < 0.55:
                k = t / 0.55
                c = (
                    self._lerp(top[0], mid[0], k),
                    self._lerp(top[1], mid[1], k),
                    self._lerp(top[2], mid[2], k),
                )
            else:
                k = (t - 0.55) / 0.45
                c = (
                    self._lerp(mid[0], bot[0], k),
                    self._lerp(mid[1], bot[1], k),
                    self._lerp(mid[2], bot[2], k),
                )
            pygame.draw.line(surface, c, (0, y), (w, y))

        fx = pygame.Surface((w, h), pygame.SRCALPHA)

        # mountains / ruined skyline
        ground = int(h * 0.76)
        pygame.draw.polygon(fx, (2, 5, 12, 210), [(0, ground + 50), (0, h), (w, h), (w, ground + 34)])
        for i in range(22):
            x = int(i * w / 21)
            height = int(h * (0.12 + (i % 5) * 0.025))
            pygame.draw.polygon(
                fx,
                (5, 9, 18, 185),
                [(x - 75, ground + 30), (x + 20, ground - height), (x + 110, ground + 30)],
            )

        # big portal center-right
        cx = int(w * 0.58)
        cy = int(h * 0.43)
        base = int(min(w, h) * 0.265)
        pulse = math.sin(self.frame * 0.045) * 5

        for i in range(14):
            rr = int(base + 40 - i * 10 + pulse)
            alpha = max(12, 78 - i * 4)
            if rr <= 20:
                continue
            pygame.draw.circle(fx, (35, 105, 255, alpha), (cx, cy), rr, 4)

        # broken stone ring
        for i in range(32):
            ang = i * math.tau / 32 + self.frame * 0.001
            r1 = base + 16 + (i % 3) * 4
            r2 = base + 42 + (i % 4) * 5
            a1 = ang - 0.035
            a2 = ang + 0.035
            p1 = (cx + math.cos(a1) * r1, cy + math.sin(a1) * r1)
            p2 = (cx + math.cos(a2) * r1, cy + math.sin(a2) * r1)
            p3 = (cx + math.cos(a2) * r2, cy + math.sin(a2) * r2)
            p4 = (cx + math.cos(a1) * r2, cy + math.sin(a1) * r2)
            col = (14, 28, 52, 230) if i % 5 else (24, 52, 100, 230)
            pygame.draw.polygon(fx, col, [p1, p2, p3, p4])
            pygame.draw.line(fx, (55, 145, 255, 120), p3, p4, 1)

        # portal spiral
        for i in range(26):
            rr = int(base * 0.88 - i * 5 + math.sin(self.frame * 0.04 + i) * 3)
            if rr < 10:
                continue
            rect = pygame.Rect(cx - rr, cy - rr, rr * 2, rr * 2)
            start = i * 0.31 + self.frame * 0.025
            end = start + 1.25
            alpha = max(20, 140 - i * 4)
            pygame.draw.arc(fx, (75, 170, 255, alpha), rect, start, end, 3)

        pygame.draw.circle(fx, (10, 25, 65, 130), (cx, cy), int(base * 0.80))
        pygame.draw.circle(fx, (2, 6, 18, 170), (cx, cy), int(base * 0.38))
        pygame.draw.circle(fx, (100, 215, 255, 45), (cx, cy), int(base * 0.55), 3)
        pygame.draw.line(fx, (75, 145, 255, 130), (cx, 0), (cx, cy - base - 30), 2)

        # stairs/path to portal
        for i in range(12):
            y = int(ground - 20 + i * 13)
            width = int(110 + i * 45)
            alpha = max(15, 70 - i * 4)
            pygame.draw.line(fx, (60, 130, 220, alpha), (cx - width // 2, y), (cx + width // 2, y), 2)

        # floating rocks
        for i in range(22):
            ang = i * 1.77
            rx = cx + int(math.cos(ang) * (base + 90 + (i % 4) * 28))
            ry = cy + int(math.sin(ang) * (base * 0.82 + (i % 3) * 25))
            size = 6 + (i % 5) * 4
            pygame.draw.polygon(
                fx,
                (8, 13, 24, 210),
                [(rx, ry - size), (rx + size, ry), (rx + size // 2, ry + size), (rx - size, ry + size // 2)],
            )
            pygame.draw.line(fx, (65, 120, 205, 80), (rx - size, ry), (rx + size, ry), 1)

        # hunter silhouette in front
        self._draw_hunter_to_layer(fx, int(w * 0.36), int(h * 0.70), int(h * 0.31))

        # fog
        for i in range(7):
            yy = int(h * 0.72 + i * 20)
            off = int(math.sin(self.frame * 0.01 + i) * 40)
            pygame.draw.polygon(
                fx,
                (35, 95, 170, max(5, 22 - i * 2)),
                [(-80, yy), (w * 0.25 + off, yy - 35), (w * 0.62 - off, yy + 8), (w + 80, yy - 25), (w + 80, h + 80), (-80, h + 80)],
            )

        # embers / blue dust
        for i in range(110):
            x = int((i * 97 + self.frame * (0.5 + i % 3)) % w)
            y = int((i * 53 + self.frame * 0.35) % h)
            if i % 9 == 0:
                pygame.draw.circle(fx, (255, 110, 45, 105), (x, y), 1)
            else:
                pygame.draw.circle(fx, (110, 205, 255, 45), (x, y), 1)

        surface.blit(fx, (0, 0))

        # vignette and left readability gradient
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(shade, (0, 0, 0, 65), (0, 0, w, h))
        pygame.draw.rect(shade, (0, 0, 0, 110), (0, 0, int(w * 0.36), h))
        pygame.draw.rect(shade, (0, 0, 0, 105), (0, int(h * 0.84), w, int(h * 0.16)))
        pygame.draw.rect(shade, (0, 0, 0, 95), (0, 0, w, int(h * 0.08)))
        surface.blit(shade, (0, 0))

    def _draw_hunter_to_layer(self, layer, x, ground_y, height):
        # cloak
        head_y = ground_y - height
        body_y = head_y + int(height * 0.18)
        cloak = [
            (x - int(height * 0.18), ground_y),
            (x - int(height * 0.13), body_y),
            (x - int(height * 0.04), head_y + int(height * 0.12)),
            (x + int(height * 0.05), head_y + int(height * 0.12)),
            (x + int(height * 0.15), body_y),
            (x + int(height * 0.20), ground_y),
            (x + int(height * 0.05), ground_y - 16),
            (x, ground_y),
            (x - int(height * 0.05), ground_y - 14),
        ]
        pygame.draw.polygon(layer, (1, 3, 8, 245), cloak)
        pygame.draw.polygon(layer, (35, 105, 190, 105), cloak, 2)
        pygame.draw.circle(layer, (1, 3, 8, 250), (x, head_y + 25), int(height * 0.055))
        pygame.draw.rect(layer, (1, 3, 8, 250), (x - 16, body_y, 32, int(height * 0.39)), border_radius=14)
        pygame.draw.line(layer, (90, 210, 255, 150), (x - 7, head_y + 24), (x + 8, head_y + 24), 2)
        pygame.draw.circle(layer, (65, 190, 255, 145), (x, body_y + 48), 4)
        # sword
        pygame.draw.line(layer, (155, 215, 250, 160), (x + 40, body_y + 25), (x + 82, ground_y - 10), 3)
        # floor glow
        pygame.draw.ellipse(layer, (65, 155, 255, 40), (x - 86, ground_y - 16, 172, 30))

    # ------------------------------------------------------------------
    # UI COMPONENTS
    # ------------------------------------------------------------------

    def _panel(self, surface, rect, accent=(70, 150, 255), fill=(4, 9, 20, 165), cut=20):
        p = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pts = [(0, 0), (rect.width - cut, 0), (rect.width, cut), (rect.width, rect.height), (0, rect.height)]
        pygame.draw.polygon(p, fill, pts)
        pygame.draw.lines(p, (*accent, 170), True, pts, 1)
        pygame.draw.line(p, (255, 255, 255, 22), (18, 12), (rect.width - 34, 12), 1)
        surface.blit(p, rect.topleft)

    def _draw_icon_diamond(self, surface, center, accent, active=False):
        x, y = center
        r = 17
        pts = [(x, y - r), (x + r, y), (x, y + r), (x - r, y)]
        pygame.draw.polygon(surface, (10, 18, 38), pts)
        pygame.draw.polygon(surface, accent, pts, 2)
        if active:
            pygame.draw.polygon(surface, (*accent, 45), pts)
        pygame.draw.polygon(surface, (160, 220, 255), [(x, y - 8), (x + 7, y), (x, y + 8), (x - 7, y)], 1)

    def _menu_button(self, surface, rect, label, sub, icon_type, action, active=False):
        self._register_interaction(rect, action)
        hovered = self._is_hovered(rect)
        accent = (72, 165, 255) if active else (65, 92, 130)
        fill = (8, 20, 42, 210) if active else (3, 8, 18, 165)
        if hovered and not active:
            accent = (92, 185, 255)
            fill = (7, 18, 38, 195)
        pts = self._poly_button_rect(rect, 26)

        if active or hovered:
            glow = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            pygame.draw.polygon(glow, (72, 165, 255, 42 if active else 24), pts)
            surface.blit(glow, (0, 0))

        pygame.draw.polygon(surface, fill, pts)
        pygame.draw.lines(surface, (*accent, 220), True, pts, 2 if active else 1)

        ix = rect.x + 34
        iy = rect.centery
        if icon_type == "diamond":
            self._draw_icon_diamond(surface, (ix, iy), (92, 185, 255), active)
        elif icon_type == "gear":
            pygame.draw.circle(surface, (120, 140, 175), (ix, iy), 12, 3)
            pygame.draw.circle(surface, (120, 140, 175), (ix, iy), 4)
        elif icon_type == "sword":
            pygame.draw.line(surface, (130, 150, 185), (ix - 10, iy + 10), (ix + 12, iy - 12), 4)
            pygame.draw.line(surface, (130, 150, 185), (ix - 8, iy - 2), (ix + 2, iy + 8), 3)
        elif icon_type == "book":
            pygame.draw.rect(surface, (130, 150, 185), (ix - 13, iy - 12, 11, 24), 2)
            pygame.draw.rect(surface, (130, 150, 185), (ix + 2, iy - 12, 11, 24), 2)
        else:
            pygame.draw.circle(surface, (130, 150, 185), (ix, iy), 13, 3)
            pygame.draw.line(surface, (130, 150, 185), (ix, iy - 9), (ix, iy + 2), 3)

        self._text(surface, sub, self.font_tiny, (92, 165, 255) if active or hovered else (115, 130, 155), rect.x + 76, rect.y + 13)
        self._text(surface, label, self.font_menu, (245, 248, 255) if active or hovered else (155, 166, 190), rect.x + 76, rect.y + 29)

        if active:
            arr = self.font_title.render("»", True, (90, 205, 255))
            surface.blit(arr, (rect.right - 50, rect.centery - arr.get_height() // 2 - 2))

    def _fit_font(self, family, text, max_width, start_size, min_size, bold=True):
        size = start_size
        font = pygame.font.SysFont(family, size, bold=bold)
        while size > min_size and font.size(text)[0] > max_width:
            size -= 2
            font = pygame.font.SysFont(family, size, bold=bold)
        return font

    def _draw_logo(self, surface, safe_right_x):
        w, h = surface.get_size()
        x = int(w * 0.045)
        y = int(h * 0.105)

        title = "SHADOWFALL"
        max_logo_w = max(280, safe_right_x - x - int(w * 0.035))

        logo_font = self._fit_font("georgia", title, max_logo_w, self.font_logo.get_height(), 42, True)
        shadow_font = pygame.font.SysFont("georgia", logo_font.get_height() + 10, bold=True)
        subtitle_font = self._fit_font("trebuchetms", "G A T E   H U N T E R", max_logo_w, self.font_title.get_height(), 16, True)

        self._text(surface, "ANOMALY RESPONSE ACTION RPG", self.font_small, (150, 170, 210), x + int(max_logo_w * 0.20), y - 36)

        back = shadow_font.render(title, True, (1, 6, 20))
        glow = logo_font.render(title, True, (55, 150, 255))
        main = logo_font.render(title, True, (240, 246, 255))
        shade = logo_font.render(title, True, (120, 155, 210))

        surface.blit(back, (x + 7, y + 12))
        surface.blit(glow, (x + 1, y + 1))
        surface.blit(shade, (x + 4, y + 7))
        surface.blit(main, (x, y))

        line_y = y + main.get_height() - 6
        pygame.draw.line(surface, (60, 165, 255), (x + 10, line_y), (x + main.get_width() - 8, line_y), 2)
        pygame.draw.circle(surface, (110, 220, 255), (x + int(main.get_width() * 0.35), line_y), 4)

        sub = subtitle_font.render("G A T E   H U N T E R", True, (222, 232, 255))
        surface.blit(sub, (x + max(0, main.get_width() // 2 - sub.get_width() // 2), line_y + 24))

    def _draw_class_panel(self, surface, rect, selected_class):
        current = get_hunter_class(selected_class)
        self._panel(surface, rect, accent=(72, 145, 255), fill=(3, 8, 18, 180), cut=22)
        self._text(surface, "HUNTER CLASS", self.font_title, (220, 228, 250), rect.x + 24, rect.y + 20)
        pygame.draw.line(surface, (72, 145, 255), (rect.x + 24, rect.y + 55), (rect.x + rect.width - 80, rect.y + 55), 1)

        rows = [
            ("1", "striker", HUNTER_CLASSES["striker"].name),
            ("2", "ranger", HUNTER_CLASSES["ranger"].name),
            ("3", "awakened", HUNTER_CLASSES["awakened"].name),
        ]
        y = rect.y + 80
        for key, class_id, name in rows:
            row_rect = pygame.Rect(rect.x + 20, y - 6, rect.width - 40, 36)
            self._register_interaction(row_rect, f"title_class:{class_id}")
            hovered = self._is_hovered(row_rect)
            active = name == current.name
            self._draw_icon_diamond(surface, (rect.x + 38, y + 12), (75, 165, 255), active)
            if active or hovered:
                pygame.draw.rect(surface, (35, 95, 180, 120 if active else 72), (rect.x + 62, y - 5, rect.width - 90, 36), border_radius=6)
            self._text(surface, key, self.font_small, (105, 165, 240) if active or hovered else (110, 125, 150), rect.x + 68, y + 2)
            self._text(surface, name.upper(), self.font_body_bold, (235, 242, 255) if active or hovered else (160, 172, 198), rect.x + 95, y)
            y += 45

        pygame.draw.line(surface, (80, 100, 140), (rect.x + 24, y + 6), (rect.right - 25, y + 6), 1)
        self._wrapped(surface, current.description, self.font_small, (180, 192, 214), rect.x + 24, y + 27, rect.width - 48, gap=6, max_lines=3)

    def _draw_loadout_panel(self, surface, rect, loadout_names):
        self._panel(surface, rect, accent=(142, 92, 230), fill=(3, 8, 18, 175), cut=22)
        self._text(surface, "LOADOUT", self.font_title, (220, 215, 245), rect.x + 24, rect.y + 18)
        pygame.draw.line(surface, (142, 92, 230), (rect.x + 24, rect.y + 52), (rect.x + rect.width - 50, rect.y + 52), 1)

        usable_w = rect.width - 110
        value_font = self.font_small

        y = rect.y + 70
        row_h = max(28, int(rect.height * 0.155))
        for slot in ("lmb", "q", "f", "y"):
            if y + row_h > rect.bottom - 36:
                break

            key = slot.upper()
            val = str(loadout_names.get(slot, "-"))
            val_font = value_font
            while val_font.size(val)[0] > usable_w and val_font.get_height() > 10:
                val_font = pygame.font.SysFont("trebuchetms", val_font.get_height() - 1)

            key_rect = pygame.Rect(rect.x + 25, y - 1, 42, 24)
            pygame.draw.rect(surface, (5, 12, 28, 190), key_rect, border_radius=5)
            pygame.draw.rect(surface, (70, 145, 255, 120), key_rect, 1, border_radius=5)
            self._center_text_in(surface, key_rect, key, self.font_small, (100, 195, 255))
            self._text(surface, val, val_font, (205, 215, 232), rect.x + 78, y + 2)
            y += row_h

        buy_y = rect.bottom - 32
        self._text(surface, "4-0", self.font_small, (255, 190, 95), rect.x + 26, buy_y)
        self._text(surface, "Buy upgrades", self.font_small, (255, 190, 95), rect.x + 76, buy_y)

    def _draw_controls_panel(self, surface, rect):
        self._panel(surface, rect, accent=(72, 145, 255), fill=(3, 8, 18, 160), cut=18)
        self._text(surface, "CONTROLS", self.font_title, (220, 228, 250), rect.x + 24, rect.y + 18)
        pygame.draw.line(surface, (72, 145, 255), (rect.x + 24, rect.y + 52), (rect.x + rect.width - 50, rect.y + 52), 1)

        y = rect.y + 73
        self._text(surface, "Q/W/E/R/T", self.font_small, (105, 205, 255), rect.x + 24, y)
        label = "+ STR/DEX/VIT/END/INT"
        max_w = max(40, rect.width - 155)
        label_font = self._fit_font("trebuchetms", label, max_w, self.font_small.get_height(), 10, bold=False)
        self._text(surface, label, label_font, (180, 192, 214), rect.x + 142, y)

        if rect.height > 115:
            esc = pygame.Rect(rect.x + 24, rect.y + 107, 42, 25)
            pygame.draw.rect(surface, (5, 12, 28, 190), esc, border_radius=5)
            pygame.draw.rect(surface, (70, 145, 255, 120), esc, 1, border_radius=5)
            self._center_text_in(surface, esc, "ESC", self.font_small, (105, 205, 255))
            self._text(surface, "Quit", self.font_small, (180, 192, 214), rect.x + 80, rect.y + 111)

    def _draw_bottom_bar(self, surface, highest_rank, gold, mastery, build_points, max_right_x=None):
        w, h = surface.get_size()
        max_right_x = max_right_x or int(w * 0.60)
        rect_w = max(520, max_right_x - int(w * 0.045))
        rect_w = min(rect_w, int(w * 0.58))
        rect = pygame.Rect(int(w * 0.045), h - 72, rect_w, 52)
        self._panel(surface, rect, accent=(72, 145, 255), fill=(3, 8, 18, 172), cut=22)

        items = [
            ("HIGHEST CLEAR", str(highest_rank)),
            ("GOLD", str(gold)),
            ("MASTERY", str(mastery)),
            ("BUILD POINTS", str(build_points)),
        ]
        gap = rect.width / 4
        for i, (label, value) in enumerate(items):
            cx = int(rect.x + i * gap + 36)
            self._draw_icon_diamond(surface, (cx, rect.y + 26), (80, 150, 255), i == 0)
            self._text(surface, label, self.font_tiny, (145, 160, 190), cx + 34, rect.y + 13)
            self._text(surface, value, self.font_body_bold, (235, 242, 255), cx + 34, rect.y + 29)
            if i < 3:
                sx = int(rect.x + (i + 1) * gap)
                pygame.draw.line(surface, (80, 100, 140), (sx, rect.y + 11), (sx, rect.bottom - 11), 1)

    def _draw_version_dots(self, surface):
        w, h = surface.get_size()
        self._text(surface, "v0.1.0", self.font_tiny, (120, 135, 160), w - 90, h - 78)
        x = w - 128
        y = h - 38
        for i in range(7):
            color = (70, 155, 255) if i == 0 else (55, 65, 85)
            pts = [(x + i * 18, y - 6), (x + i * 18 + 6, y), (x + i * 18, y + 6), (x + i * 18 - 6, y)]
            pygame.draw.polygon(surface, color, pts)
            pygame.draw.polygon(surface, (110, 180, 255, 80), pts, 1)

    def _draw_focus_badges(self, surface, x: int, y: int, badges: list[tuple[str, tuple[int, int, int]]]) -> None:
        bx = x
        for text, accent in badges:
            width = max(86, self.font_tiny.size(text)[0] + 22)
            rect = pygame.Rect(bx, y, width, 22)
            pygame.draw.rect(surface, (8, 18, 34, 210), rect, border_radius=11)
            pygame.draw.rect(surface, accent, rect, 1, border_radius=11)
            self._center_text_in(surface, rect, text, self.font_tiny, (230, 238, 255))
            bx += width + 10

    def _draw_focus_panel(self, surface, rect: pygame.Rect, selected_class: str, loadout_names: dict[str, str]) -> None:
        current = get_hunter_class(selected_class)
        shadow = pygame.Surface((rect.width + 18, rect.height + 18), pygame.SRCALPHA)
        pygame.draw.rect(shadow, (0, 0, 0, 95), shadow.get_rect(), border_radius=24)
        surface.blit(shadow, (rect.x - 10, rect.y + 12))

        if self.title_focus == "options":
            self._panel(surface, rect, accent=(82, 180, 255), fill=(4, 10, 22, 180), cut=22)
            self._text(surface, "SYSTEM", self.font_tiny, (115, 185, 255), rect.x + 24, rect.y + 16)
            self._text(surface, "KEY CONFIGURATION", self.font_title, (230, 238, 255), rect.x + 24, rect.y + 34)
            rows = [
                ("move_up", "Move Up"),
                ("move_left", "Move Left"),
                ("move_down", "Move Down"),
                ("move_right", "Move Right"),
                ("skill_1", "Skill 1"),
                ("ult", "Ultimate"),
                ("dash", "Dash"),
                ("class_skill", "Class Skill"),
                ("advance_room", "Advance Room"),
                ("heal_potion", "Heal Potion"),
                ("mana_potion", "Mana Potion"),
                ("stamina_tonic", "Stamina Tonic"),
                ("pause", "Pause"),
                ("debug", "Debug"),
                ("inventory", "Inventory"),
                ("skill_tree", "Skill Tree"),
            ]
            left_x = rect.x + 24
            top_y = rect.y + 72
            col_gap = 20
            col_w = (rect.width - 48 - col_gap) // 2
            row_h = 28
            for index, (action, label) in enumerate(rows):
                col = index // 8
                row = index % 8
                row_rect = pygame.Rect(left_x + col * (col_w + col_gap), top_y + row * row_h, col_w, 24)
                bind_rect = pygame.Rect(row_rect.right - 92, row_rect.y, 92, 24)
                self._register_interaction(bind_rect, f"rebind:{action}")
                hovered = self._is_hovered(bind_rect)
                waiting = self.pending_keybind_action == action
                self._text(surface, label, self.font_small, (195, 206, 226), row_rect.x, row_rect.y + 3)
                pygame.draw.rect(surface, (9, 18, 34, 210), bind_rect, border_radius=5)
                pygame.draw.rect(surface, (255, 196, 92) if waiting else ((110, 190, 255) if hovered else (72, 145, 255)), bind_rect, 1, border_radius=5)
                bind_label = "PRESS KEY" if waiting else self.keybind_labels.get(action, "-")
                self._center_text_in(surface, bind_rect, bind_label, self.font_tiny, (255, 215, 140) if waiting else (110, 205, 255))
            footer = "Select a slot, press a key, Esc cancels."
            self._text(surface, footer, self.font_tiny, (150, 166, 190), rect.x + 24, rect.bottom - 22)
            return

        content = {
            "begin_hunt": {
                "eyebrow": "OPERATION",
                "title": "BEGIN HUNT",
                "accent": (82, 180, 255),
                "badges": [("Solo Run", (82, 180, 255)), ("Mouse Ready", (82, 180, 255))],
                "lines": [
                    "Enter the next active gate and begin a fresh anomaly run.",
                    "Your selected hunter, loadout, and saved binds will be used immediately.",
                ],
            },
            "loadout": {
                "eyebrow": "COMBAT DECK",
                "title": "ACTIVE LOADOUT",
                "accent": (180, 118, 255),
                "badges": [(current.name, (180, 118, 255)), ("4 Slots", (180, 118, 255))],
                "lines": [
                    f"LMB  {loadout_names.get('lmb', '-')}",
                    f"Q  {loadout_names.get('q', '-')}    F  {loadout_names.get('f', '-')}",
                    f"Y  {loadout_names.get('y', '-')}",
                ],
            },
            "codex": {
                "eyebrow": "INTEL FILE",
                "title": "HUNTER CODEX",
                "accent": (255, 188, 92),
                "badges": [(current.name, (255, 188, 92)), ("Class Brief", (255, 188, 92))],
                "lines": [
                    f"{current.name}: {current.description}",
                    f"Active skill: {current.active_skill}",
                    f"Mastery: {current.mastery_focus}",
                ],
            },
        }
        info = content.get(self.title_focus, content["begin_hunt"])
        self._panel(surface, rect, accent=info["accent"], fill=(4, 10, 22, 180), cut=22)
        self._text(surface, info["eyebrow"], self.font_tiny, info["accent"], rect.x + 24, rect.y + 16)
        self._text(surface, info["title"], self.font_title, (230, 238, 255), rect.x + 24, rect.y + 34)
        pygame.draw.line(surface, (*info["accent"], 220), (rect.x + 24, rect.y + 68), (rect.right - 126, rect.y + 68), 1)
        self._draw_focus_badges(surface, rect.x + 24, rect.y + 82, info["badges"])
        y = rect.y + 118
        for line in info["lines"]:
            y = self._wrapped(surface, line, self.font_small, (195, 206, 226), rect.x + 24, y, rect.width - 48, gap=5, max_lines=3)
            y += 6

    def _draw_next_tab_button(self, surface, rect: pygame.Rect) -> None:
        self._register_interaction(rect, "title_next")
        hovered = self._is_hovered(rect)
        fill = (8, 20, 42, 210) if hovered else (3, 8, 18, 185)
        accent = (92, 185, 255) if hovered else (72, 145, 255)
        self._panel(surface, rect, accent=accent, fill=fill, cut=16)
        self._center_text_in(surface, rect, "NEXT TAB", self.font_tiny, (235, 244, 255))

    # ------------------------------------------------------------------
    # TITLE SCREEN
    # ------------------------------------------------------------------

    def draw_title_screen(
        self,
        surface: pygame.Surface,
        selected_class: str = "striker",
        highest_rank: str = "E",
        gold: int = 0,
        class_mastery_level: int = 1,
        shop_bonus_hp: int = 0,
        shop_bonus_mana: int = 0,
        shop_bonus_attack: int = 0,
        build_points: int = 0,
        core_stats: dict | None = None,
        loadout_names: dict | None = None,
        title_message: str = "",
    ) -> None:
        self._make_fonts(surface)
        self._begin_interaction_frame()
        self._draw_background(surface)

        w, h = surface.get_size()
        loadout_names = loadout_names or {}

        # dynamic layout. Right panels get their own safe area, logo/menu never enters it.
        margin = int(w * 0.045)
        right_w = self._clamp(int(w * 0.215), 270, 360)
        rx = w - right_w - margin
        safe_right_x = rx - int(w * 0.035)

        self._draw_logo(surface, safe_right_x)

        focus_rect = pygame.Rect(int(w * 0.365), int(h * 0.155), max(320, int(w * 0.295)), max(152, int(h * 0.23)))
        self._draw_focus_panel(surface, focus_rect, selected_class, loadout_names)
        next_rect = pygame.Rect(focus_rect.right - 112, focus_rect.y + 18, 96, 28)
        self._draw_next_tab_button(surface, next_rect)

        # left menu
        x = margin
        y = int(h * 0.405)
        bw = min(int(w * 0.235), max(300, safe_right_x - x - 40))
        bh = self._clamp(int(h * 0.078), 48, 66)
        gap = self._clamp(int(h * 0.018), 8, 16)
        menu = [
            ("BEGIN HUNT", "DEPLOY NOW", "diamond", "title_begin_hunt", self.title_focus == "begin_hunt"),
            ("OPTIONS", "SYSTEM", "gear", "title_options", self.title_focus == "options"),
            ("LOADOUT", "COMBAT DECK", "sword", "title_loadout", self.title_focus == "loadout"),
            ("HUNTER CODEX", "INTEL FILE", "book", "title_codex", self.title_focus == "codex"),
            ("EXIT GAME", "RETURN TO DESKTOP", "power", "title_exit", False),
        ]
        for i, (label, sub, icon, action, active) in enumerate(menu):
            self._menu_button(surface, pygame.Rect(x, y + i * (bh + gap), bw, bh), label, sub, icon, action, active)

        # right info stack - computed to avoid vertical/text overlap
        top_y = int(h * 0.115)
        bottom_limit = h - 86
        stack_gap = self._clamp(int(h * 0.026), 12, 22)
        controls_h = self._clamp(int(h * 0.145), 110, 145)
        class_h = self._clamp(int(h * 0.315), 210, 285)
        loadout_h = max(190, bottom_limit - top_y - class_h - controls_h - stack_gap * 2)
        loadout_h = min(loadout_h, int(h * 0.285))

        class_rect = pygame.Rect(rx, top_y, right_w, class_h)
        loadout_rect = pygame.Rect(rx, class_rect.bottom + stack_gap, right_w, loadout_h)
        controls_rect = pygame.Rect(rx, loadout_rect.bottom + stack_gap, right_w, controls_h)

        if controls_rect.bottom > bottom_limit:
            overflow = controls_rect.bottom - bottom_limit
            loadout_rect.height = max(165, loadout_rect.height - overflow)
            controls_rect.y = loadout_rect.bottom + stack_gap

        self._draw_class_panel(surface, class_rect, selected_class)
        self._draw_loadout_panel(surface, loadout_rect, loadout_names)
        self._draw_controls_panel(surface, controls_rect)

        self._draw_bottom_bar(surface, highest_rank, gold, class_mastery_level, build_points, rx - 20)
        self._draw_version_dots(surface)

        if title_message:
            msg = self.font_small.render(title_message, True, (255, 215, 145))
            surface.blit(msg, (x, h - 105))

    # ------------------------------------------------------------------
    # RUN SUMMARY + MODALS
    # ------------------------------------------------------------------

    def _draw_run_summary(self, surface: pygame.Surface, run_summary: dict, top_y: int) -> None:
        if not run_summary:
            return

        w = surface.get_width()
        panel = pygame.Rect(w // 2 - 330, top_y, 660, 158)
        self._panel(surface, panel, accent=(105, 130, 175), fill=(4, 8, 18, 214), cut=18)

        lines = [
            f"Gate: {run_summary.get('gate_name', '?')}    Rank: {run_summary.get('rank', '?')}",
            f"Class: {run_summary.get('class_name', '?')}    Skill: {run_summary.get('class_skill', '?')}",
            f"Rooms: {run_summary.get('rooms_reached', 0)}/{run_summary.get('rooms_total', 0)}    Kills: {run_summary.get('kills', 0)}",
            f"XP: {run_summary.get('xp_earned', 0)}    Gold: {run_summary.get('gold_earned', 0)}    Levels: {run_summary.get('levels_gained', 0)}",
            f"Mastery: {run_summary.get('mastery_gained', 0)}    Flawless: {'YES' if run_summary.get('flawless', False) else 'NO'}",
        ]

        y = panel.y + 19
        for line in lines:
            self._text(surface, line, self.font_small, (212, 220, 236), panel.x + 24, y)
            y += 25

    def _modal_button(self, surface, y, text, accent, action):
        w = surface.get_width()
        rect = pygame.Rect(w // 2 - 210, y, 420, 48)
        self._register_interaction(rect, action)
        hovered = self._is_hovered(rect)
        fill = (4, 12, 26, 225) if hovered else (2, 6, 14, 205)
        self._panel(surface, rect, accent=accent, fill=fill, cut=16)
        self._center_text_in(surface, rect, text, self.font_body_bold, (235, 244, 255))

    def _draw_modal(self, surface, title, subtitle, accent, fill, options, run_summary=None):
        self._make_fonts(surface)
        self._begin_interaction_frame()
        self._draw_background(surface)

        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 155))
        surface.blit(overlay, (0, 0))

        w, h = surface.get_size()
        card_h = 455 if run_summary else 320
        card = pygame.Rect(w // 2 - 420, h // 2 - card_h // 2, 840, card_h)
        self._panel(surface, card, accent=accent, fill=fill, cut=26)

        title_img = self.font_logo.render(title, True, accent)
        surface.blit(title_img, (card.centerx - title_img.get_width() // 2, card.y + 34))
        sub_img = self.font_body.render(subtitle, True, (205, 215, 232))
        surface.blit(sub_img, (card.centerx - sub_img.get_width() // 2, card.y + 137))

        if run_summary:
            self._draw_run_summary(surface, run_summary, card.y + 174)
            y = card.y + 350
        else:
            y = card.y + 185

        for label, action in options:
            self._modal_button(surface, y, label, accent, action)
            y += 58

    def draw_pause_menu(self, surface: pygame.Surface) -> None:
        self._draw_modal(
            surface,
            "PAUSED",
            "The gate is frozen. Choose your next move.",
            (210, 225, 255),
            (4, 8, 18, 224),
            [("[ ESC ]  RESUME", "pause_resume"), ("[ T ]  TITLE SCREEN", "pause_title"), ("[ Q ]  QUIT GAME", "pause_quit")],
        )

    def draw_death_screen(self, surface: pygame.Surface, run_summary: dict | None = None) -> None:
        self._draw_modal(
            surface,
            "HUNTER FALLEN",
            "The anomaly survived. Your next run starts stronger.",
            (235, 78, 78),
            (22, 4, 6, 228),
            [("[ R ]  RETRY RUN", "dead_retry"), ("[ T ]  TITLE SCREEN", "dead_title"), ("[ Q ]  QUIT GAME", "dead_quit")],
            run_summary or {},
        )

    def draw_clear_screen(self, surface: pygame.Surface, run_summary: dict | None = None) -> None:
        self._draw_modal(
            surface,
            "DOMAIN PURGED",
            "The gate collapsed. A higher rank is waiting.",
            (95, 235, 135),
            (4, 18, 8, 228),
            [("[ R ]  NEXT RUN", "clear_retry"), ("[ T ]  TITLE SCREEN", "clear_title"), ("[ Q ]  QUIT GAME", "clear_quit")],
            run_summary or {},
        )
