from __future__ import annotations


def format_debug_block(title: str, lines: list[str]) -> list[str]:
    return [title] + [f"  {line}" for line in lines]
