from __future__ import annotations

import pygame

from game.config import SCREEN_WIDTH, SCREEN_HEIGHT, WHITE


class HUD:
    def __init__(self):
        pygame.font.init()

        self.font_tiny = pygame.font.SysFont("trebuchetms", 14)
        self.font_small = pygame.font.SysFont("trebuchetms", 16)
        self.font_medium = pygame.font.SysFont("trebuchetms", 22, bold=True)
        self.font_big = pygame.font.SysFont("georgia", 28, bold=True)

        self.kill_feed_timer = 0.0
        self.last_kill_feed_text = ""

    def draw(self, screen, player, gate, last_kill_feed: str = "") -> None:
        if player is None:
            return

        if last_kill_feed:
            self.last_kill_feed_text = last_kill_feed
            self.kill_feed_timer = 2.2

        self._draw_top_left_vitals(screen, player)
        self._draw_gate_panel(screen, gate)
        self._draw_bottom_left_status(screen, player)
        self._draw_skill_bar(screen, player)
        self._draw_consumable_slot(screen, player)
        self._draw_boss_bar(screen, gate)
        self._draw_kill_feed(screen)
        self._draw_inventory_overlay(screen, player)
        self._draw_skill_tree_overlay(screen, player)

    def update(self, dt: float) -> None:
        if self.kill_feed_timer > 0:
            self.kill_feed_timer -= dt
            if self.kill_feed_timer < 0:
                self.kill_feed_timer = 0

    def _draw_glass_panel(
        self,
        screen,
        rect: pygame.Rect,
        alpha: int = 132,
        border=(130, 136, 154),
        radius: int = 14,
        fill=(8, 10, 16),
    ) -> None:
        panel = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pygame.draw.rect(panel, (*fill, alpha), (0, 0, rect.width, rect.height), border_radius=radius)
        pygame.draw.rect(panel, (255, 255, 255, 18), (1, 1, rect.width - 2, rect.height // 2), border_radius=radius)
        pygame.draw.rect(panel, (*border, 185), (0, 0, rect.width, rect.height), 1, border_radius=radius)
        screen.blit(panel, rect.topleft)

    def _draw_meter(
        self,
        screen,
        x: int,
        y: int,
        width: int,
        height: int,
        current: float,
        maximum: float,
        color,
        back=(28, 30, 38),
        border=(110, 118, 136),
    ) -> None:
        maximum = max(1.0, maximum)
        ratio = max(0.0, min(1.0, current / maximum))
        bg_rect = pygame.Rect(x, y, width, height)
        fill_rect = pygame.Rect(x, y, int(width * ratio), height)

        pygame.draw.rect(screen, back, bg_rect, border_radius=max(4, height // 2))
        if fill_rect.width > 0:
            pygame.draw.rect(screen, color, fill_rect, border_radius=max(4, height // 2))
            shine_h = max(2, height // 3)
            pygame.draw.rect(
                screen,
                (255, 255, 255, 34),
                (fill_rect.x, fill_rect.y, fill_rect.width, shine_h),
                border_radius=max(4, height // 2),
            )
        pygame.draw.rect(screen, border, bg_rect, 1, border_radius=max(4, height // 2))

    def _draw_panel(self, screen, rect: pygame.Rect, alpha: int = 180, border=(92, 98, 122)) -> None:
        self._draw_glass_panel(screen, rect, alpha=alpha, border=border, radius=18, fill=(11, 14, 24))

    def _draw_bar(
        self,
        screen,
        x: int,
        y: int,
        width: int,
        height: int,
        current: float,
        maximum: float,
        fill_color,
        back_color=(30, 35, 46),
        border_color=(110, 118, 136),
        text: str = "",
    ) -> None:
        self._draw_meter(screen, x, y, width, height, current, maximum, fill_color, back=back_color, border=border_color)

        if text:
            label = self.font_small.render(text, True, WHITE)
            label_rect = label.get_rect(center=(x + width // 2, y + height // 2))
            screen.blit(label, label_rect)

    def _get_item_count(self, player, item_id: str) -> int:
        if hasattr(player, "inventory") and hasattr(player.inventory, "get_item"):
            item = player.inventory.get_item(item_id)
            if item is not None:
                return int(item.get("quantity", 0))
        return 0

    def _draw_top_left_vitals(self, screen, player) -> None:
        root_x = 28
        root_y = 28

        crest = pygame.Rect(root_x, root_y, 42, 42)
        crest_panel = pygame.Surface((crest.width, crest.height), pygame.SRCALPHA)
        points = [(21, 0), (38, 8), (42, 21), (34, 38), (21, 42), (7, 35), (0, 21), (6, 8)]
        pygame.draw.polygon(crest_panel, (18, 19, 24, 188), points)
        pygame.draw.polygon(crest_panel, (112, 112, 118, 205), points, 1)
        pygame.draw.polygon(crest_panel, (255, 255, 255, 16), [(21, 4), (34, 10), (30, 20), (21, 18), (11, 22), (8, 10)])
        screen.blit(crest_panel, crest.topleft)

        bar_x = crest.right + 10
        bar_w = 220
        stats = player.stats

        self._draw_meter(screen, bar_x, root_y + 4, bar_w, 8, stats.hp, stats.max_hp, (170, 52, 48), border=(115, 88, 88))
        self._draw_meter(screen, bar_x, root_y + 18, int(bar_w * 0.88), 7, stats.mana, stats.max_mana, (52, 94, 178), border=(88, 104, 136))
        self._draw_meter(screen, bar_x, root_y + 31, int(bar_w * 0.95), 7, stats.stamina, stats.max_stamina, (64, 136, 88), border=(92, 120, 102))

    def _draw_bottom_left_status(self, screen, player) -> None:
        base_x = 28
        base_y = SCREEN_HEIGHT - 92

        class_name = str(getattr(player.get_class_profile(), "name", "Hunter"))
        mastery_level = int(player.get_class_mastery_state().get("level", 1)) if hasattr(player, "get_class_mastery_state") else 1

        name_img = self.font_medium.render(getattr(player, "name", "Hunter"), True, (230, 230, 236))
        class_img = self.font_small.render(f"{class_name} M{mastery_level}", True, (188, 192, 204))
        level_img = self.font_small.render(f"Lv. {player.progression.level}", True, (192, 192, 204))
        gold_img = self.font_small.render(f"{getattr(player, 'gold', 0)}", True, (205, 188, 120))

        screen.blit(name_img, (base_x, base_y))
        screen.blit(class_img, (base_x, base_y + 20))
        screen.blit(level_img, (base_x, base_y + 46))

        coin = self.font_small.render("G", True, (185, 162, 104))
        screen.blit(coin, (base_x + 64, base_y + 46))
        screen.blit(gold_img, (base_x + 80, base_y + 46))

    def _draw_gate_panel(self, screen, gate) -> None:
        if gate is None:
            return

        rank = getattr(gate, "rank", "?")
        display_name = getattr(gate, "display_name", f"{rank}-Rank Gate")
        room_index = getattr(gate, "current_room_index", 0)
        room_count = len(getattr(gate, "rooms", [])) if getattr(gate, "rooms", None) is not None else 0
        accent = getattr(gate, "accent_color", (156, 156, 176))

        title = self.font_medium.render(display_name, True, (226, 226, 232))
        room = self.font_small.render(f"Room {room_index + 1}/{max(1, room_count)}", True, (198, 198, 208))

        center_x = SCREEN_WIDTH // 2
        title_x = center_x - title.get_width() // 2
        room_x = center_x - room.get_width() // 2
        title_y = 20
        room_y = title_y + 22

        line_y = title_y + 12
        line_w = 82
        pygame.draw.line(screen, (*accent, 110), (title_x - line_w - 12, line_y), (title_x - 12, line_y), 1)
        pygame.draw.line(screen, (*accent, 110), (title_x + title.get_width() + 12, line_y), (title_x + title.get_width() + line_w, line_y), 1)
        screen.blit(title, (title_x, title_y))
        screen.blit(room, (room_x, room_y))

    def _draw_skill_slot(self, screen, rect: pygame.Rect, key_name: str, cd: float, accent, quantity: str = "") -> None:
        self._draw_glass_panel(screen, rect, alpha=138, border=accent, radius=10, fill=(10, 10, 16))

        inner = rect.inflate(-6, -6)
        pygame.draw.rect(screen, (18, 18, 24), inner, border_radius=8)
        glow = pygame.Surface((inner.width, inner.height), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*accent, 42), (inner.width // 2, inner.height // 2), min(inner.width, inner.height) // 2)
        screen.blit(glow, inner.topleft)

        ring_center = (rect.centerx, rect.centery - 4)
        pygame.draw.circle(screen, (38, 40, 52), ring_center, 13, 2)
        pygame.draw.circle(screen, accent, ring_center, 12, 2)

        key = self.font_small.render(key_name, True, (230, 232, 236))
        key_rect = key.get_rect(center=(rect.centerx, rect.bottom - 12))
        screen.blit(key, key_rect)

        if cd > 0:
            state = self.font_tiny.render(f"{cd:.1f}", True, (255, 176, 176))
            state_rect = state.get_rect(center=ring_center)
            screen.blit(state, state_rect)
        elif quantity:
            qty = self.font_small.render(quantity, True, (230, 232, 236))
            qty_rect = qty.get_rect(center=ring_center)
            screen.blit(qty, qty_rect)

    def _draw_skill_bar(self, screen, player) -> None:
        slot_w = 42
        slot_h = 52
        gap = 12
        total_w = slot_w * 4 + gap * 3
        start_x = SCREEN_WIDTH // 2 - total_w // 2
        y = SCREEN_HEIGHT - 72

        skills = [
            ("LMB", player.cooldowns.remaining("basic_attack"), (134, 74, 56)),
            ("Q", player.cooldowns.remaining("skill_1"), (166, 128, 58)),
            ("F", player.cooldowns.remaining("class_skill"), (60, 104, 186)),
            ("Y", player.cooldowns.remaining("ult"), (126, 78, 170)),
        ]

        for i, (key_name, cd, accent) in enumerate(skills):
            x = start_x + i * (slot_w + gap)
            self._draw_skill_slot(screen, pygame.Rect(x, y, slot_w, slot_h), key_name, cd, accent)

    def _draw_consumable_slot(self, screen, player) -> None:
        potion_count = self._get_item_count(player, "healing_potion")
        rect = pygame.Rect(SCREEN_WIDTH - 86, SCREEN_HEIGHT - 90, 58, 72)
        self._draw_glass_panel(screen, rect, alpha=142, border=(138, 128, 116), radius=10, fill=(12, 10, 8))

        bottle = pygame.Surface((24, 40), pygame.SRCALPHA)
        pygame.draw.ellipse(bottle, (132, 84, 42, 220), (4, 10, 16, 22))
        pygame.draw.ellipse(bottle, (206, 164, 88, 200), (7, 14, 10, 14))
        pygame.draw.rect(bottle, (110, 88, 68, 220), (10, 3, 4, 10), border_radius=2)
        pygame.draw.rect(bottle, (184, 166, 126, 180), (9, 1, 6, 4), border_radius=2)
        screen.blit(bottle, (rect.x + 16, rect.y + 10))

        key = self.font_small.render("H", True, (214, 214, 220))
        qty = self.font_medium.render(str(potion_count), True, (226, 226, 232))
        screen.blit(key, (rect.x + 14, rect.bottom - 20))
        screen.blit(qty, (rect.right - qty.get_width() - 10, rect.bottom - 24))

    def _draw_boss_bar(self, screen, gate) -> None:
        if gate is None or not hasattr(gate, "current_room"):
            return

        room = gate.current_room()
        if room is None:
            return
        boss = getattr(room, "boss", None)
        if boss is None or not getattr(boss, "alive", False) or not hasattr(boss, "stats"):
            return

        frame = pygame.Rect(SCREEN_WIDTH // 2 - 260, 58, 520, 34)
        self._draw_glass_panel(screen, frame, alpha=148, border=(128, 88, 112), radius=12, fill=(20, 8, 12))

        boss_name = self.font_small.render(getattr(boss, "name", "Boss"), True, (238, 226, 232))
        screen.blit(boss_name, (frame.x + 12, frame.y + 5))

        self._draw_meter(
            screen,
            frame.x + 12,
            frame.y + 18,
            frame.width - 24,
            8,
            boss.stats.hp,
            boss.stats.max_hp,
            (156, 58, 112),
            back=(40, 20, 28),
            border=(124, 88, 110),
        )

    def _draw_kill_feed(self, screen) -> None:
        if self.kill_feed_timer <= 0 or not self.last_kill_feed_text:
            return

        alpha_ratio = min(1.0, self.kill_feed_timer / 2.2)
        width = min(420, max(220, 28 + len(self.last_kill_feed_text) * 9))
        rect = pygame.Rect(SCREEN_WIDTH // 2 - width // 2, SCREEN_HEIGHT // 2 - 118, width, 34)
        self._draw_glass_panel(screen, rect, alpha=int(118 * alpha_ratio), border=(214, 174, 98), radius=12, fill=(26, 18, 8))

        text_surface = self.font_small.render(self.last_kill_feed_text, True, (245, 226, 152))
        text_surface.set_alpha(int(255 * alpha_ratio))
        text_rect = text_surface.get_rect(center=rect.center)
        screen.blit(text_surface, text_rect)

    def _draw_overlay_shell(self, screen, title_text: str, subtitle_text: str, width: int, height: int):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((2, 4, 10, 152))
        screen.blit(overlay, (0, 0))

        rect = pygame.Rect(SCREEN_WIDTH // 2 - width // 2, SCREEN_HEIGHT // 2 - height // 2, width, height)
        self._draw_panel(screen, rect, alpha=232, border=(109, 128, 168))

        title = self.font_big.render(title_text, True, WHITE)
        title_rect = title.get_rect(midtop=(rect.centerx, rect.y + 16))
        screen.blit(title, title_rect)

        subtitle = self.font_small.render(subtitle_text, True, (204, 210, 224))
        subtitle_rect = subtitle.get_rect(midtop=(rect.centerx, rect.y + 56))
        screen.blit(subtitle, subtitle_rect)
        return rect

    def _draw_inventory_overlay(self, screen, player) -> None:
        if not getattr(player, "inventory_open", False):
            return

        relic_count = 0
        if hasattr(player, "inventory") and hasattr(player.inventory, "get_items_by_type"):
            relic_count = len(player.inventory.get_items_by_type("relic"))

        panel_rect = self._draw_overlay_shell(
            screen,
            "Inventory",
            f"Press B to close | H heal | J mana | G stamina | Relics {relic_count}",
            520,
            392,
        )

        items = []
        if hasattr(player, "inventory") and hasattr(player.inventory, "items"):
            items = player.inventory.items

        if not items:
            empty = self.font_medium.render("No items collected yet", True, (220, 220, 220))
            empty_rect = empty.get_rect(center=(panel_rect.centerx, panel_rect.centery + 10))
            screen.blit(empty, empty_rect)
            return

        content_x = panel_rect.x + 24
        content_y = panel_rect.y + 98
        max_lines = 8
        shown_items = items[:max_lines]
        row_y = content_y

        for i, item in enumerate(shown_items):
            row_height = 44 if isinstance(item, dict) and item.get("item_type") == "relic" else 24
            row_rect = pygame.Rect(content_x, row_y, panel_rect.width - 48, row_height)
            pygame.draw.rect(screen, (23, 28, 38), row_rect, border_radius=8)
            pygame.draw.rect(screen, (86, 100, 128), row_rect, 1, border_radius=8)

            if isinstance(item, dict):
                name = str(item.get("name", "Unknown Item"))
                qty = item.get("quantity", 1)
                item_type = str(item.get("item_type", "misc")).upper()
                left = f"{i + 1}. {name}"
                right = f"{item_type} x{qty}"
                name_color = tuple(item.get("color", WHITE)) if item.get("item_type") == "relic" else WHITE
            else:
                left = f"{i + 1}. {str(item)}"
                right = ""
                name_color = WHITE

            img = self.font_small.render(left, True, name_color)
            screen.blit(img, (row_rect.x + 10, row_rect.y + 3))
            if right:
                right_color = name_color if isinstance(item, dict) and item.get("item_type") == "relic" else (186, 195, 214)
                right_img = self.font_small.render(right, True, right_color)
                right_rect = right_img.get_rect(midright=(row_rect.right - 10, row_rect.y + 12))
                screen.blit(right_img, right_rect)

            if isinstance(item, dict) and item.get("item_type") == "relic":
                desc = str(item.get("description", ""))
                if desc:
                    desc_img = self.font_small.render(desc, True, (214, 210, 174))
                    screen.blit(desc_img, (row_rect.x + 16, row_rect.y + 22))

            row_y += row_height + 8

        if len(items) > max_lines:
            more = self.font_small.render(f"...and {len(items) - max_lines} more", True, (200, 200, 210))
            screen.blit(more, (content_x, panel_rect.bottom - 28))

    def _draw_skill_tree_overlay(self, screen, player) -> None:
        if not getattr(player, "skill_tree_open", False):
            return

        panel_rect = self._draw_overlay_shell(
            screen,
            "Skill Tree",
            f"Level {player.progression.level}  |  Skill {player.progression.skill_points}  |  Stat {player.progression.stat_points}  |  1-8 rank/unlock | Shift+1-8 equip passive | Z/X/C/V mods | N spec | K close",
            760,
            618,
        )

        stat_panel = pygame.Rect(panel_rect.x + 24, panel_rect.y + 92, panel_rect.width - 48, 78)
        pygame.draw.rect(screen, (20, 24, 34), stat_panel, border_radius=14)
        pygame.draw.rect(screen, (96, 110, 142), stat_panel, 2, border_radius=14)
        stat_rows = player.progression.stat_summary()
        for i, row in enumerate(stat_rows):
            block_x = stat_panel.x + 14 + i * 176
            key_img = self.font_small.render(f"[{row['key']}]", True, (255, 224, 125))
            name_img = self.font_medium.render(f"{row['name']} {row['amount']}", True, WHITE)
            desc_img = self.font_small.render(row["description"], True, (194, 202, 220))
            screen.blit(key_img, (block_x, stat_panel.y + 10))
            screen.blit(name_img, (block_x + 36, stat_panel.y + 6))
            screen.blit(desc_img, (block_x, stat_panel.y + 40))

        passive_state = player.progression.passive_summary(player.get_class_mastery_state()["level"])
        branch_rows = player.progression.branch_summary(player.class_id)
        branch_text = "   ".join(
            f"{row['branch'][:3].upper()} {row['unlocked']}/{row['total']}{' *' if row['reward_ready'] else ''}"
            for row in branch_rows
        )
        spec_name = player.progression.selected_specialization or "None"
        passive_text = self.font_small.render(
            f"Passives {passive_state['equipped']}/{passive_state['limit']}  |  Spec {spec_name}  |  Branches {branch_text}",
            True,
            (208, 214, 226),
        )
        screen.blit(passive_text, (panel_rect.x + 28, panel_rect.y + 176))

        rows = player.progression.skill_summary(
            class_id=player.class_id,
            class_mastery=player.get_class_mastery_state()["level"],
            core_stats=player.core_stats,
        )
        start_x = panel_rect.x + 24
        start_y = panel_rect.y + 206
        columns = 2
        card_w = 344
        card_h = 74
        gap_x = 18
        gap_y = 16

        for i, row in enumerate(rows):
            col = i % columns
            row_index = i // columns
            x = start_x + col * (card_w + gap_x)
            y = start_y + row_index * (card_h + gap_y)
            card = pygame.Rect(x, y, card_w, card_h)

            rank = row["rank"]
            max_rank = row["max_rank"]
            if rank >= max_rank:
                fill = (23, 63, 42)
                border = (89, 196, 126)
                status_color = (141, 255, 178)
            elif row["can_unlock"]:
                fill = (58, 47, 20)
                border = (233, 193, 88)
                status_color = (255, 224, 125)
            else:
                fill = (26, 29, 39)
                border = (80, 86, 102)
                status_color = (188, 194, 210)

            pygame.draw.rect(screen, fill, card, border_radius=14)
            pygame.draw.rect(screen, border, card, 2, border_radius=14)

            slot_pill = pygame.Rect(card.x + 10, card.y + 10, 28, 20)
            pygame.draw.rect(screen, border, slot_pill, border_radius=10)
            slot_img = self.font_small.render(str(row["slot"]), True, (12, 14, 22))
            slot_rect = slot_img.get_rect(center=slot_pill.center)
            screen.blit(slot_img, slot_rect)

            title = self.font_medium.render(row["name"], True, WHITE)
            screen.blit(title, (card.x + 48, card.y + 8))

            equip_suffix = " [Equipped]" if row["equipped"] else ""
            branch = self.font_small.render(f"{row['branch']}  {rank}/{max_rank}{equip_suffix}", True, (196, 204, 220))
            screen.blit(branch, (card.x + 48, card.y + 34))

            if row["node_type"] == "passive" and row["passive_category"]:
                detail_text = f"{row['tier']} {row['passive_category']} passive"
            else:
                detail_text = row["description"]
            detail = self.font_small.render(detail_text, True, (215, 219, 229))
            screen.blit(detail, (card.x + 10, card.y + 54))

            status = self.font_small.render(row["status"], True, status_color)
            status_rect = status.get_rect(topright=(card.right - 10, card.y + 10))
            screen.blit(status, status_rect)
