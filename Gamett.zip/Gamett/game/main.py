# game/main.py

from __future__ import annotations

import math
from pathlib import Path
import sys
import random
import pygame

if __package__ in {None, ""}:
    # Allow running this file directly: `python game/main.py`.
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from game.ai.adaptation import CombatMemory
from game.ai.global_learning import GlobalLearningDB
from game.config import (
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    FPS,
    GAME_TITLE,
    WORLD_WIDTH,
    WORLD_HEIGHT,
    BLACK,
    DRAW_DEBUG_TEXT,
    GATE_RANK_ORDER,
)
from game.player.player import Player
from game.player.classes import HUNTER_CLASSES, get_hunter_class
from game.player.builds import (
    CORE_STAT_ORDER,
    CORE_STAT_LABELS,
    CREATION_STAT_CAP,
    DEFAULT_CORE_STATS,
    STARTING_BUILD_POINTS,
    cycle_slot_skill,
    get_skill_def,
    make_default_loadout,
    make_default_unlocked_skills,
    sanitize_core_stats,
    sanitize_loadout,
)
from game.dungeons.gate import Gate
from game.dungeons.rewards import gate_clear_rewards
from game.save_system import SaveSystem
from game.save_system import DEFAULT_KEYBINDS
from game.ui.hud import HUD
from game.ui.menu import MenuUI


STATE_TITLE = "title"
STATE_LOADING = "loading"
STATE_PLAYING = "playing"
STATE_PAUSED = "paused"
STATE_DEAD = "dead"
STATE_CLEARED = "cleared"
SHOW_DEBUG_UI_DEFAULT = bool(DRAW_DEBUG_TEXT)
LOADING_SCREEN_DURATION = 3.2


def handle_loading_screen_input(event: pygame.event.Event, current_state: str) -> str:
    """Handle loading-screen input without allowing an immediate skip."""
    if event.type != pygame.KEYDOWN:
        return current_state

    if event.key == pygame.K_ESCAPE:
        return STATE_TITLE

    return current_state


RANK_CLEAR_REQUIREMENTS = {
    "E": 0,
    "D": 1,
    "C": 2,
    "B": 4,
    "A": 6,
    "S": 9,
    "SS": 12,
    "SSS": 16,
    "EX": 20,
    "MONARCH": 26,
}

SHOP_ITEMS = {
    pygame.K_4: {
        "label": "Healing Bundle",
        "cost": 30,
        "apply": "healing_bundle",
    },
    pygame.K_5: {
        "label": "Mana Draft",
        "cost": 35,
        "apply": "mana_bundle",
    },
    pygame.K_6: {
        "label": "Stamina Tonic",
        "cost": 35,
        "apply": "stamina_bundle",
    },
    pygame.K_7: {
        "label": "Potion Refill",
        "cost": 50,
        "apply": "potions",
    },
    pygame.K_8: {
        "label": "Vitality Boost",
        "cost": 90,
        "apply": "hp",
    },
    pygame.K_9: {
        "label": "Sharpening Sigil",
        "cost": 90,
        "apply": "attack",
    },
    pygame.K_0: {
        "label": "Mana Surge",
        "cost": 90,
        "apply": "mana",
    },
}

LOADING_VARIANTS = (
    {
        "name": "NULL CROWN BREACH",
        "subtitle": "Reality lock is failing on purpose.",
        "steps": ("Calibrating hunter signature", "Folding corridor geometry", "Threat choir detected", "Opening kill lane"),
        "threat": "CROWN STATIC",
        "command": "BREAK THE ROOM BEFORE IT LEARNS YOUR NAME",
    },
    {
        "name": "ABYSSAL DROP PROTOCOL",
        "subtitle": "The gate is staring back. Good.",
        "steps": ("Igniting mana anchors", "Waking tactical memory", "Indexing hostile mutations", "Dropping into rupture"),
        "threat": "DEEP SIGNAL",
        "command": "DESCEND WITH INTENT",
    },
    {
        "name": "MONOLITH SYNC",
        "subtitle": "Something ancient just accepted your challenge.",
        "steps": ("Reading boss omens", "Sharpening shadow vectors", "Compressing entry wound", "Authorizing violence"),
        "threat": "OBELISK HEARTBEAT",
        "command": "MAKE THE ANCIENT THING REGRET CONSENT",
    },
    {
        "name": "STARLESS DEPLOYMENT",
        "subtitle": "No sky, no backup, no problem.",
        "steps": ("Charging portal teeth", "Loading combat instincts", "Marking escape vectors", "Crossing event edge"),
        "threat": "NOCTURNE CASCADE",
        "command": "HIT FIRST. HIT LOUD.",
    },
)

REBINDALE_ACTIONS = (
    "move_up",
    "move_down",
    "move_left",
    "move_right",
    "skill_1",
    "ult",
    "dash",
    "class_skill",
    "advance_room",
    "heal_potion",
    "mana_potion",
    "stamina_tonic",
    "pause",
    "debug",
    "inventory",
    "skill_tree",
)


def normalize_keybind_name(name: str) -> str:
    return str(name or "").strip().lower()


def normalize_keybinds(raw_keybinds: dict | None) -> dict[str, str]:
    merged = dict(DEFAULT_KEYBINDS)
    if isinstance(raw_keybinds, dict):
        for action, name in raw_keybinds.items():
            if action in merged:
                normalized = normalize_keybind_name(name)
                if normalized:
                    merged[action] = normalized
    return merged


def resolve_keybinds(raw_keybinds: dict | None) -> dict[str, int]:
    resolved: dict[str, int] = {}
    for action, name in normalize_keybinds(raw_keybinds).items():
        try:
            resolved[action] = pygame.key.key_code(name)
        except ValueError:
            resolved[action] = pygame.key.key_code(DEFAULT_KEYBINDS[action])
    return resolved


def keybind_display_name(key_name: str) -> str:
    name = normalize_keybind_name(key_name)
    if not name:
        return "-"
    mapping = {
        "space": "Space",
        "escape": "Esc",
        "left shift": "LShift",
        "right shift": "RShift",
        "left ctrl": "LCtrl",
        "right ctrl": "RCtrl",
        "left alt": "LAlt",
        "right alt": "RAlt",
        "mouse 1": "Mouse1",
    }
    return mapping.get(name, name.upper())


def clamp(value: float, min_value: float, max_value: float) -> float:
    return max(min_value, min(value, max_value))


def get_desktop_window_size() -> tuple[int, int]:
    sizes = pygame.display.get_desktop_sizes()
    if sizes:
        return sizes[0]
    return SCREEN_WIDTH, SCREEN_HEIGHT


def get_present_rect(window_size: tuple[int, int]) -> pygame.Rect:
    window_w, window_h = window_size
    scale = min(window_w / SCREEN_WIDTH, window_h / SCREEN_HEIGHT)
    draw_w = max(1, int(SCREEN_WIDTH * scale))
    draw_h = max(1, int(SCREEN_HEIGHT * scale))
    draw_x = (window_w - draw_w) // 2
    draw_y = (window_h - draw_h) // 2
    return pygame.Rect(draw_x, draw_y, draw_w, draw_h)


def get_scaled_mouse_pos(window_size: tuple[int, int]) -> tuple[int, int]:
    return window_to_virtual_pos(pygame.mouse.get_pos(), window_size)


def window_to_virtual_pos(pos: tuple[int, int], window_size: tuple[int, int]) -> tuple[int, int]:
    mouse_x, mouse_y = pos
    present_rect = get_present_rect(window_size)

    if present_rect.width <= 0 or present_rect.height <= 0:
        return 0, 0

    clamped_x = clamp(mouse_x, present_rect.left, present_rect.right - 1)
    clamped_y = clamp(mouse_y, present_rect.top, present_rect.bottom - 1)

    virtual_x = int((clamped_x - present_rect.left) * SCREEN_WIDTH / present_rect.width)
    virtual_y = int((clamped_y - present_rect.top) * SCREEN_HEIGHT / present_rect.height)
    return virtual_x, virtual_y


def present_frame(window: pygame.Surface, frame: pygame.Surface, window_size: tuple[int, int]) -> None:
    window.fill(BLACK)
    present_rect = get_present_rect(window_size)
    scaled = pygame.transform.smoothscale(frame, present_rect.size)
    window.blit(scaled, present_rect.topleft)


def get_camera(player: Player) -> tuple[float, float]:
    cam_x = clamp(player.x - SCREEN_WIDTH / 2, 0, max(0, WORLD_WIDTH - SCREEN_WIDTH))
    cam_y = clamp(player.y - SCREEN_HEIGHT / 2, 0, max(0, WORLD_HEIGHT - SCREEN_HEIGHT))
    return cam_x, cam_y


def draw_world_bounds(surface: pygame.Surface, cam_x: float, cam_y: float) -> None:
    rect = pygame.Rect(-cam_x, -cam_y, WORLD_WIDTH, WORLD_HEIGHT)
    pygame.draw.rect(surface, (70, 70, 70), rect, 3)


def lerp_color(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    t = max(0.0, min(1.0, t))
    return (
        int(a[0] + (b[0] - a[0]) * t),
        int(a[1] + (b[1] - a[1]) * t),
        int(a[2] + (b[2] - a[2]) * t),
    )


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * max(0.0, min(1.0, t))


def draw_vertical_gradient(surface: pygame.Surface, top_color: tuple[int, int, int], bottom_color: tuple[int, int, int]) -> None:
    w, h = surface.get_size()
    for y in range(h):
        t = y / max(1, h - 1)
        color = (
            int(lerp(top_color[0], bottom_color[0], t)),
            int(lerp(top_color[1], bottom_color[1], t)),
            int(lerp(top_color[2], bottom_color[2], t)),
        )
        pygame.draw.line(surface, color, (0, y), (w, y))


def draw_glow_circle(surface: pygame.Surface, pos: tuple[int, int], radius: int, color: tuple[int, int, int], alpha: int) -> None:
    glow = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
    for r in range(radius, 0, -6):
        a = int(alpha * (r / radius) ** 2)
        pygame.draw.circle(glow, (*color, a), (radius, radius), r)
    surface.blit(glow, (pos[0] - radius, pos[1] - radius))


def draw_soft_rect(
    surface: pygame.Surface,
    rect: pygame.Rect,
    color: tuple[int, int, int],
    alpha: int,
    radius: int = 18,
) -> None:
    s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(s, (*color, alpha), (0, 0, rect.width, rect.height), border_radius=radius)
    surface.blit(s, rect.topleft)


def get_gate_palette(gate: Gate | None) -> dict[str, tuple[int, int, int]]:
    rank = getattr(gate, "rank", "E")
    palettes = {
        "E": {"sky_top": (8, 10, 14), "sky_bottom": (18, 22, 28), "stone_dark": (18, 20, 26), "stone": (28, 32, 40), "stone_light": (42, 48, 60), "edge_dark": (10, 12, 16), "fog": (120, 130, 150), "glow": (255, 120, 40), "glow_dark": (160, 60, 20), "gate": (90, 190, 255), "gate_soft": (70, 120, 180)},
        "D": {"sky_top": (8, 14, 18), "sky_bottom": (20, 30, 38), "stone_dark": (16, 24, 30), "stone": (26, 38, 48), "stone_light": (40, 58, 70), "edge_dark": (8, 10, 14), "fog": (126, 140, 154), "glow": (94, 182, 226), "glow_dark": (36, 92, 136), "gate": (110, 206, 255), "gate_soft": (78, 134, 188)},
        "C": {"sky_top": (6, 16, 18), "sky_bottom": (18, 34, 36), "stone_dark": (14, 26, 28), "stone": (24, 40, 42), "stone_light": (36, 58, 60), "edge_dark": (8, 12, 14), "fog": (112, 144, 138), "glow": (86, 214, 188), "glow_dark": (30, 114, 94), "gate": (96, 220, 206), "gate_soft": (66, 134, 128)},
        "B": {"sky_top": (10, 16, 10), "sky_bottom": (22, 34, 20), "stone_dark": (20, 24, 18), "stone": (34, 40, 30), "stone_light": (52, 60, 46), "edge_dark": (12, 14, 10), "fog": (128, 138, 112), "glow": (168, 208, 84), "glow_dark": (80, 116, 32), "gate": (168, 220, 110), "gate_soft": (108, 146, 74)},
        "A": {"sky_top": (16, 10, 10), "sky_bottom": (34, 18, 16), "stone_dark": (28, 18, 18), "stone": (46, 30, 30), "stone_light": (70, 48, 48), "edge_dark": (14, 10, 10), "fog": (152, 124, 118), "glow": (255, 144, 82), "glow_dark": (162, 68, 28), "gate": (255, 184, 116), "gate_soft": (156, 104, 70)},
        "S": {"sky_top": (14, 10, 22), "sky_bottom": (28, 18, 38), "stone_dark": (22, 18, 32), "stone": (38, 28, 54), "stone_light": (58, 42, 78), "edge_dark": (10, 8, 16), "fog": (134, 120, 154), "glow": (255, 110, 124), "glow_dark": (148, 42, 58), "gate": (184, 128, 255), "gate_soft": (102, 80, 170)},
        "SS": {"sky_top": (12, 8, 20), "sky_bottom": (24, 12, 34), "stone_dark": (22, 14, 28), "stone": (38, 22, 46), "stone_light": (58, 34, 72), "edge_dark": (8, 6, 14), "fog": (146, 118, 152), "glow": (230, 88, 144), "glow_dark": (136, 34, 82), "gate": (220, 114, 198), "gate_soft": (122, 68, 148)},
        "SSS": {"sky_top": (10, 8, 22), "sky_bottom": (18, 12, 40), "stone_dark": (16, 14, 30), "stone": (28, 24, 54), "stone_light": (44, 40, 84), "edge_dark": (8, 6, 16), "fog": (126, 126, 164), "glow": (168, 116, 255), "glow_dark": (84, 58, 162), "gate": (198, 152, 255), "gate_soft": (106, 92, 182)},
        "EX": {"sky_top": (8, 6, 20), "sky_bottom": (20, 10, 46), "stone_dark": (14, 10, 30), "stone": (24, 18, 60), "stone_light": (38, 34, 96), "edge_dark": (6, 4, 14), "fog": (118, 116, 164), "glow": (126, 104, 255), "glow_dark": (62, 48, 166), "gate": (152, 132, 255), "gate_soft": (82, 74, 192)},
        "MONARCH": {"sky_top": (14, 10, 4), "sky_bottom": (36, 28, 10), "stone_dark": (30, 24, 12), "stone": (52, 42, 20), "stone_light": (82, 66, 34), "edge_dark": (16, 12, 4), "fog": (170, 148, 108), "glow": (255, 206, 92), "glow_dark": (168, 118, 36), "gate": (255, 228, 132), "gate_soft": (176, 138, 78)},
    }
    return palettes.get(rank, palettes["E"])


def draw_dungeon_background(
    surface: pygame.Surface,
    gate: Gate,
    cam_x: float,
    cam_y: float,
    t: float,
    combat_active: bool = False,
) -> None:
    w, h = surface.get_size()
    palette = get_gate_palette(gate)
    room = gate.current_room()
    room_rect = room.room_bounds.move(-cam_x, -cam_y)
    seed = gate.seed + gate.current_room_index * 997
    rng = random.Random(seed)
    accent = getattr(gate, "accent_color", palette["gate"])
    parallax_x = int((cam_x / max(1, WORLD_WIDTH)) * 36)
    parallax_y = int((cam_y / max(1, WORLD_HEIGHT)) * 20)
    center_rect = pygame.Rect(w // 2 - 210, int(h * 0.38), 420, 250)
    center_floor_rect = pygame.Rect(w // 2 - 240, int(h * 0.48), 480, 180)
    clarity_alpha = 26 if combat_active else 14

    draw_vertical_gradient(surface, palette["sky_top"], palette["sky_bottom"])
    draw_soft_rect(surface, room_rect, palette["stone_dark"], 255, radius=18)
    draw_glow_circle(surface, (w // 2 - parallax_x, int(h * 0.56) - parallax_y // 2), 160, palette["gate_soft"], 10 if not combat_active else 6)

    tile = 64
    grid = pygame.Surface((w, h), pygame.SRCALPHA)
    for x in range(room_rect.left, room_rect.right + 1, tile):
        pygame.draw.line(grid, (*palette["stone_light"], 16), (x, room_rect.top), (x, room_rect.bottom), 1)
    for y in range(room_rect.top, room_rect.bottom + 1, tile):
        pygame.draw.line(grid, (*palette["stone_light"], 16), (room_rect.left, y), (room_rect.right, y), 1)
    surface.blit(grid, (0, 0))

    for _ in range(34):
        x = rng.randint(80, w - 80)
        y = rng.randint(80, h - 80)
        if center_floor_rect.collidepoint(x, y) and rng.random() < 0.75:
            continue
        rx = rng.randint(25, 70)
        ry = rng.randint(12, 36)
        stain = pygame.Surface((rx * 2, ry * 2), pygame.SRCALPHA)
        pygame.draw.ellipse(stain, (10, 10, 12, 20), (0, 0, rx * 2, ry * 2))
        surface.blit(stain, (x - rx, y - ry))

    for _ in range(56):
        x = rng.randint(120, w - 120)
        y = rng.randint(120, h - 120)
        if center_floor_rect.collidepoint(x, y) and rng.random() < 0.8:
            continue
        length = rng.randint(18, 70)
        angle = rng.uniform(0, math.tau)
        pieces = rng.randint(2, 5)
        px, py = x, y
        for _ in range(pieces):
            nx = px + math.cos(angle) * rng.randint(length // 4, length // 2)
            ny = py + math.sin(angle) * rng.randint(length // 4, length // 2)
            pygame.draw.line(surface, lerp_color(palette["stone_light"], (0, 0, 0), 0.38), (px, py), (nx, ny), 2)
            if rng.random() < 0.55:
                bx = px + math.cos(angle + rng.uniform(-1.2, 1.2)) * rng.randint(8, 18)
                by = py + math.sin(angle + rng.uniform(-1.2, 1.2)) * rng.randint(8, 18)
                pygame.draw.line(surface, lerp_color(palette["stone"], (0, 0, 0), 0.34), (px, py), (bx, by), 1)
            px, py = nx, ny

    pygame.draw.rect(surface, palette["edge_dark"], (0, 0, w, 60))
    pygame.draw.rect(surface, palette["edge_dark"], (0, h - 60, w, 60))
    pygame.draw.rect(surface, palette["edge_dark"], (0, 0, 60, h))
    pygame.draw.rect(surface, palette["edge_dark"], (w - 60, 0, 60, h))
    pygame.draw.rect(surface, lerp_color(palette["stone"], (0, 0, 0), 0.42), (50, 50, w - 100, h - 100), width=20, border_radius=12)
    floor_focus = pygame.Surface((center_floor_rect.width, center_floor_rect.height), pygame.SRCALPHA)
    pygame.draw.ellipse(floor_focus, (*palette["stone_light"], 18 if not combat_active else 26), (0, 12, center_floor_rect.width, center_floor_rect.height - 24))
    surface.blit(floor_focus, center_floor_rect.topleft)

    for wall in room.wall_rects:
        screen_wall = wall.move(-cam_x, -cam_y)
        shadow = screen_wall.inflate(18, 18)
        shadow_surf = pygame.Surface((shadow.width, shadow.height), pygame.SRCALPHA)
        pygame.draw.rect(shadow_surf, (0, 0, 0, 52), shadow_surf.get_rect(), border_radius=14)
        surface.blit(shadow_surf, shadow.topleft)
        pygame.draw.rect(surface, lerp_color(palette["stone_dark"], (0, 0, 0), 0.12), screen_wall, border_radius=10)
        pygame.draw.rect(surface, lerp_color(palette["stone_light"], accent, 0.08), screen_wall, 2, border_radius=10)
        if screen_wall.width > screen_wall.height:
            groove_y = screen_wall.centery
            pygame.draw.line(surface, lerp_color(palette["stone"], (0, 0, 0), 0.18), (screen_wall.left + 8, groove_y), (screen_wall.right - 8, groove_y), 2)
        else:
            groove_x = screen_wall.centerx
            pygame.draw.line(surface, lerp_color(palette["stone"], (0, 0, 0), 0.18), (groove_x, screen_wall.top + 8), (groove_x, screen_wall.bottom - 8), 2)

    for _ in range(3):
        arc_w = rng.randint(80, 130)
        arc_h = rng.randint(120, 180)
        x = rng.randint(120, w - 120 - arc_w)
        y = rng.randint(30, 90)
        x -= parallax_x // 3
        pygame.draw.rect(surface, lerp_color(palette["stone_dark"], (0, 0, 0), 0.18), (x, y + arc_h // 3, arc_w, arc_h - arc_h // 3))
        pygame.draw.arc(surface, lerp_color(palette["stone"], (0, 0, 0), 0.08), (x, y, arc_w, arc_h), math.pi, math.tau, 8)
        pygame.draw.line(surface, lerp_color(palette["stone"], (0, 0, 0), 0.08), (x, y + arc_h // 2), (x, y + arc_h), 8)
        pygame.draw.line(surface, lerp_color(palette["stone"], (0, 0, 0), 0.08), (x + arc_w, y + arc_h // 2), (x + arc_w, y + arc_h), 8)

    pillar_positions = [
        (180, 190), (310, 170),
        (w - 180, 190), (w - 310, 170),
        (200, h - 190), (340, h - 170),
        (w - 200, h - 190), (w - 340, h - 170),
    ]
    for px, py in pillar_positions:
        if rng.random() >= 0.8:
            continue
        x = px + rng.randint(-18, 18) - parallax_x // 2
        y = py + rng.randint(-14, 14) - parallax_y // 2
        broken = rng.choice([True, False])
        pillar_h = 120 if not broken else 82
        base = pygame.Rect(x - 18, y - pillar_h // 2, 36, pillar_h)
        pygame.draw.rect(surface, lerp_color(palette["stone"], accent, 0.06), base, border_radius=6)
        pygame.draw.rect(surface, palette["stone_light"], base, 2, border_radius=6)
        pygame.draw.rect(surface, lerp_color(palette["stone_dark"], (0, 0, 0), 0.08), (x - 26, y + pillar_h // 2 - 8, 52, 16), border_radius=6)
        pygame.draw.rect(surface, palette["stone"], (x - 22, y - pillar_h // 2 - 8, 44, 12), border_radius=4)

        if broken:
            for _ in range(4):
                rx = x + rng.randint(-28, 28)
                ry = y + rng.randint(20, 48)
                rr = rng.randint(5, 10)
                pygame.draw.circle(surface, lerp_color(palette["stone_dark"], (0, 0, 0), 0.2), (rx, ry), rr)
                pygame.draw.circle(surface, palette["stone"], (rx, ry), rr, 1)

    for bx, by in [(150, h // 2 + 70), (w - 150, h // 2 + 70)]:
        bx -= parallax_x // 2
        pygame.draw.rect(surface, (46, 36, 26), (bx - 12, by - 20, 24, 38), border_radius=4)
        pygame.draw.rect(surface, (68, 54, 40), (bx - 16, by - 30, 32, 16), border_radius=6)
        draw_glow_circle(surface, (bx, by - 30), 34, palette["glow"], 34 if not combat_active else 24)

        flame = pygame.Surface((80, 100), pygame.SRCALPHA)
        pulse = math.sin(t * 4.2 + bx * 0.02) * 3
        points1 = [(40, 18 + pulse), (30, 46), (36, 62), (24, 80), (56, 80), (46, 58), (52, 44)]
        points2 = [(40, 28 + pulse), (34, 50), (40, 64), (30, 78), (50, 78), (44, 60), (48, 50)]
        pygame.draw.polygon(flame, (*palette["glow_dark"], 220), points1)
        pygame.draw.polygon(flame, (*palette["glow"], 240), points2)
        pygame.draw.polygon(flame, (255, 220, 130, 220), [(40, 36 + pulse), (36, 50), (40, 60), (35, 72), (46, 72), (43, 58), (45, 50)])
        surface.blit(flame, (bx - 40, by - 90))

    gx = w // 2 - parallax_x
    gy = 84 - parallax_y // 2
    gate_w = 108
    gate_h = 152
    pygame.draw.rect(surface, lerp_color(palette["stone"], (0, 0, 0), 0.12), (gx - gate_w // 2, gy + 60, gate_w, gate_h - 60))
    pygame.draw.arc(surface, palette["stone_light"], (gx - gate_w // 2, gy, gate_w, gate_h), math.pi, math.tau, 8)
    pygame.draw.line(surface, palette["stone_light"], (gx - gate_w // 2, gy + gate_h // 2), (gx - gate_w // 2, gy + gate_h), 8)
    pygame.draw.line(surface, palette["stone_light"], (gx + gate_w // 2, gy + gate_h // 2), (gx + gate_w // 2, gy + gate_h), 8)
    pulse = 0.5 + 0.5 * math.sin(t * 1.2)
    draw_glow_circle(surface, (gx, gy + 84), 62, palette["gate"], int(16 + pulse * 10))
    draw_glow_circle(surface, (gx, gy + 88), 30, palette["gate"], int(22 + pulse * 12))

    spiral = pygame.Surface((120, 120), pygame.SRCALPHA)
    cx, cy = 60, 60
    for i in range(3):
        r = 40 - i * 8
        ang1 = 0.8 + i * 0.24 + t * 0.32
        ang2 = 4.5 + i * 0.24 + t * 0.32
        pygame.draw.arc(spiral, (*palette["gate"], 74), (cx - r, cy - r, r * 2, r * 2), ang1, ang2, 1)
    pygame.draw.circle(spiral, (*accent, 42), (cx, cy), 10)
    surface.blit(spiral, (gx - 60, gy + 30))

    if room.room_type == "boss":
        sigil_center = (w // 2, int(h * 0.72))
        for radius, alpha in [(126, 34), (92, 28), (56, 22)]:
            ring = pygame.Surface((radius * 2 + 10, radius * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(ring, (*accent, alpha), (ring.get_width() // 2, ring.get_height() // 2), radius, 2)
            surface.blit(ring, (sigil_center[0] - ring.get_width() // 2, sigil_center[1] - ring.get_height() // 2))

    for _ in range(26):
        x = rng.choice([rng.randint(60, 250), rng.randint(w - 250, w - 60), rng.randint(80, w - 80)])
        y = rng.choice([rng.randint(80, 180), rng.randint(h - 180, h - 80), rng.randint(h - 140, h - 60)])
        if center_floor_rect.collidepoint(x, y) and rng.random() < 0.85:
            continue
        size = rng.randint(10, 30)
        for _ in range(rng.randint(2, 4)):
            ox = rng.randint(-size, size)
            oy = rng.randint(-size // 2, size // 2)
            rr = rng.randint(3, size // 3 + 3)
            pygame.draw.circle(surface, lerp_color(palette["stone_dark"], (0, 0, 0), 0.14), (x + ox, y + oy), rr)
            pygame.draw.circle(surface, palette["stone"], (x + ox, y + oy), rr, 1)

    fog = pygame.Surface((w, h), pygame.SRCALPHA)
    for i in range(3):
        fog_y = int(h * 0.64 + i * 36 + ((seed + i * 17) % 12 - 6))
        speed = 5 + (seed + i * 11) % 8
        offset = (seed * (i + 3)) % 9999
        alpha = (8 + ((seed + i * 7) % 8)) if not combat_active else (5 + ((seed + i * 7) % 5))
        for band in range(-1, 3):
            fog_x = int((t * speed + offset + band * 420) % (w + 300)) - 150
            ellipse_rect = pygame.Rect(fog_x, fog_y, 240, 34)
            if ellipse_rect.colliderect(center_rect):
                continue
            pygame.draw.ellipse(fog, (*palette["fog"], alpha), ellipse_rect)
    surface.blit(fog, (0, 0))

    for i in range(12):
        ex = (seed * (i + 5) * 17 + int(t * 18) * (i % 2 + 1)) % (w + 120) - 60
        ey = int(h * 0.52 + ((seed * (i + 7) * 19 - int(t * (10 + i % 4) * 6)) % int(h * 0.42)))
        if center_rect.collidepoint(int(ex), ey):
            continue
        rr = 1 + (i % 2)
        ember_color = lerp_color(palette["glow"], palette["stone_light"], 0.45)
        pygame.draw.circle(surface, ember_color, (int(ex), int(ey)), rr)

    if combat_active:
        combat_dim = pygame.Surface((w, h), pygame.SRCALPHA)
        combat_dim.fill((0, 0, 0, 18))
        surface.blit(combat_dim, (0, 0))
        clarity = pygame.Surface((center_rect.width, center_rect.height), pygame.SRCALPHA)
        pygame.draw.ellipse(clarity, (255, 255, 255, clarity_alpha), (0, 10, center_rect.width, center_rect.height - 20))
        surface.blit(clarity, center_rect.topleft)

    vignette = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(vignette, (0, 0, 0, 100), (0, 0, w, h))
    pygame.draw.rect(vignette, (0, 0, 0, 0), (120, 100, w - 240, h - 180), border_radius=80)
    surface.blit(vignette, (0, 0))


def draw_room_banner(surface: pygame.Surface, hud: HUD, gate: Gate) -> None:
    room = gate.current_room()
    title = f"{getattr(gate, 'display_name', gate.rank)}  |  ROOM {gate.current_room_index + 1}/{len(gate.rooms)}"
    encounter = getattr(room, "encounter_theme", "standard").replace("_", " ").title()
    subtitle = f"{getattr(gate, 'theme_name', 'Unknown Domain')}  |  {room.room_type.upper()}  |  {encounter}"
    accent = getattr(gate, "accent_color", (255, 255, 255))

    banner_rect = pygame.Rect(SCREEN_WIDTH // 2 - 250, 10, 500, 58)
    hud._draw_panel(surface, banner_rect, alpha=188, border=accent)
    img = hud.font_big.render(title, True, (255, 255, 255))
    sub = hud.font_small.render(subtitle, True, accent)
    surface.blit(img, (SCREEN_WIDTH // 2 - img.get_width() // 2, 16))
    surface.blit(sub, (SCREEN_WIDTH // 2 - sub.get_width() // 2, 46))


def draw_controls(surface: pygame.Surface, hud: HUD) -> None:
    lines = [
        "WASD = Move",
        "E = Dash",
        "Hold LMB = Basic Attack",
        "Hold Q = Projectile",
        "F = Class Skill",
        "Hold Y/Z = ULT",
        "H = Healing Potion",
        "J = Mana Potion",
        "G = Stamina Tonic",
        "B = Inventory",
        "K = Skill Tree",
        "SPACE = Next Room",
        "ESC = Pause",
    ]

    card = pygame.Rect(SCREEN_WIDTH - 286, SCREEN_HEIGHT - 258, 258, 230)
    hud._draw_panel(surface, card, alpha=182, border=(98, 114, 144))
    x = card.x + 16
    y = card.y + 12

    title = hud.font_medium.render("Field Controls", True, (255, 255, 255))
    surface.blit(title, (x, y))

    for i, line in enumerate(lines):
        img = hud.font_small.render(line, True, (220, 220, 220))
        surface.blit(img, (x, y + 30 + i * 18))


def spawn_player_for_room(player: Player, gate: Gate) -> None:
    room = gate.current_room()
    player.set_position(*room.player_spawn)


def build_run_summary(player: Player, gate: Gate) -> dict:
    return {
        "class_name": player.get_class_profile().name,
        "class_skill": player.get_class_profile().active_skill,
        "rank": gate.rank,
        "gate_name": getattr(gate, "display_name", gate.rank),
        "theme_name": getattr(gate, "theme_name", "Unknown Domain"),
        "level_start": player.progression.level,
        "mastery_start": player.get_class_mastery_state()["level"],
        "mastery_xp_start": player.get_class_mastery_state()["xp"],
        "rooms_total": max(0, len(gate.rooms) - 1),
        "rooms_reached": 0,
        "kills": 0,
        "xp_earned": 0,
        "gold_start": player.gold,
        "gold_earned": 0,
        "levels_gained": 0,
        "mastery_gained": 0,
        "damage_taken": 0,
        "flawless": True,
    }


def finalize_run_summary(run_summary: dict, player: Player, gate: Gate) -> dict:
    summary = dict(run_summary)
    summary["rooms_reached"] = max(summary.get("rooms_reached", 0), gate.current_room_index)
    summary["gold_earned"] = max(0, player.gold - summary.get("gold_start", player.gold))
    current_mastery = player.get_class_mastery_state()
    summary["mastery_gained"] = max(0, current_mastery["level"] - summary.get("mastery_start", current_mastery["level"]))
    if summary["mastery_gained"] <= 0:
        summary["mastery_gained"] = max(0, current_mastery["xp"] - summary.get("mastery_xp_start", current_mastery["xp"]))
    return summary


def reward_if_kill_happened(player: Player) -> str:
    if not player.last_attack_result.get("killed"):
        return ""

    killed_name = player.last_attack_result.get("target_name") or "Enemy"
    player.reward_kill(killed_name)
    loot_text = player.grant_loot_for_kill(killed_name)
    player.last_attack_result["killed"] = False
    if loot_text:
        return f"Killed: {killed_name} | {loot_text}"
    return f"Killed: {killed_name}"


def persist_boss_learning_if_needed(gate: Gate) -> None:
    room = gate.current_room()

    if room.room_type != "boss":
        return

    boss = getattr(room, "boss", None)
    if boss is None:
        return

    if not hasattr(boss, "persist_learning"):
        return

    if boss.alive:
        return

    if getattr(boss, "_learning_persisted", False):
        return

    boss.persist_learning()


def get_available_ranks(progress: dict) -> list[str]:
    gates_cleared = int(progress.get("gates_cleared", 0))
    available = [rank for rank in GATE_RANK_ORDER if gates_cleared >= RANK_CLEAR_REQUIREMENTS.get(rank, 0)]
    return available or ["E"]


def spend_title_build_point(save_data: dict, stat_id: str) -> str:
    player_data = save_data.setdefault("player", {})
    core_stats = sanitize_core_stats(player_data.get("core_stats", DEFAULT_CORE_STATS))
    points = max(0, int(player_data.get("build_points", STARTING_BUILD_POINTS)))
    if points <= 0:
        return "No build points"
    if stat_id not in core_stats:
        return ""
    if core_stats[stat_id] >= CREATION_STAT_CAP:
        return f"{CORE_STAT_LABELS[stat_id]} capped"
    core_stats[stat_id] += 1
    player_data["core_stats"] = core_stats
    player_data["build_points"] = points - 1
    return f"{CORE_STAT_LABELS[stat_id]} +1"


def reset_title_build(save_data: dict) -> str:
    player_data = save_data.setdefault("player", {})
    current = sanitize_core_stats(player_data.get("core_stats", DEFAULT_CORE_STATS))
    refund = sum(max(0, current[stat_id] - DEFAULT_CORE_STATS[stat_id]) for stat_id in CORE_STAT_ORDER)
    player_data["core_stats"] = dict(DEFAULT_CORE_STATS)
    player_data["build_points"] = max(0, int(player_data.get("build_points", STARTING_BUILD_POINTS))) + refund
    return "Core build reset"


def cycle_title_skill(save_data: dict, slot: str, direction: int = 1) -> str:
    player_data = save_data.setdefault("player", {})
    class_id = str(player_data.get("class_id", "striker"))
    unlocked = [skill_id for skill_id in player_data.get("unlocked_skills", make_default_unlocked_skills()) if skill_id in make_default_unlocked_skills()]
    if not unlocked:
        unlocked = make_default_unlocked_skills()
    loadout = sanitize_loadout(player_data.get("equipped_skills", {}), class_id)
    loadout[slot] = cycle_slot_skill(slot, loadout.get(slot, ""), direction, unlocked)
    player_data["equipped_skills"] = loadout
    return get_skill_def(loadout[slot]).name


def create_run(save_data: dict | None = None) -> tuple[Player, Gate, HUD]:
    save_data = save_data or {}
    progress = save_data.get("progress", {})
    available_ranks = get_available_ranks(progress)
    weights = {
        "E": 14,
        "D": 12,
        "C": 10,
        "B": 8,
        "A": 6,
        "S": 4,
        "SS": 3,
        "SSS": 2,
        "EX": 1,
        "MONARCH": 1,
    }
    chosen_rank = random.choices(available_ranks, weights=[weights[r] for r in available_ranks], k=1)[0]
    player_name = save_data.get("player", {}).get("name", "Sung-Type Hunter")
    player = Player(220, 360, name=player_name)
    player.keybinds = resolve_keybinds(save_data.get("player", {}).get("keybinds"))
    player.load_persistent_state(save_data)
    gate = Gate(rank=chosen_rank)
    player.current_gate_rank = chosen_rank
    gate.apply_balance(player)
    hud = HUD()
    spawn_player_for_room(player, gate)
    return player, gate, hud


def draw_loading_screen(
    surface: pygame.Surface,
    elapsed: float,
    duration: float,
    player: Player | None,
    gate: Gate | None,
    variant: dict,
) -> None:
    """Cinematic Interstellar-inspired loading screen.

    Style goals:
    - no glitch, no scanlines, no aggressive HUD spam
    - black-hole / event-horizon center piece
    - tesseract-like perspective light grid
    - slow gravitational motion and clean film UI
    """
    w, h = surface.get_size()
    progress = clamp(elapsed / max(0.1, duration), 0.0, 1.0)
    t = elapsed

    palette = get_gate_palette(gate)
    rank = str(getattr(gate, "rank", "E"))
    gate_seed = int(getattr(gate, "seed", 0) or 0)
    accent = getattr(gate, "accent_color", palette["gate"])

    # Keep the palette cold and cinematic. Gate color is used only as subtle accent.
    space_top = (1, 3, 10)
    space_mid = (4, 7, 16)
    space_bottom = (8, 11, 22)
    ice = (205, 226, 255)
    soft_ice = (130, 158, 194)
    warm_disk = (230, 204, 160)

    cx, cy = w // 2, int(h * 0.48)
    zoom = 1.0 + progress * 0.34

    draw_vertical_gradient(surface, space_top, space_bottom)

    # Deep space star field. Deterministic so it does not shimmer like noise.
    star_rng = random.Random(9317 + gate_seed)
    for i in range(260):
        sx = star_rng.randint(0, w)
        sy = star_rng.randint(0, h)
        layer = star_rng.random()
        drift_x = int(math.sin(t * (0.04 + layer * 0.08) + i) * (2 + layer * 8))
        drift_y = int(progress * layer * 12)
        size = 1 if layer < 0.88 else 2
        alpha = int(55 + layer * 120)
        color = (180, 205, 240, alpha) if i % 9 else (255, 244, 220, alpha)
        pygame.draw.circle(surface, color, ((sx + drift_x) % w, (sy + drift_y) % h), size)

    # Tesseract perspective lines: quiet, geometric, infinite-depth feel.
    tesseract = pygame.Surface((w, h), pygame.SRCALPHA)
    horizon_y = int(h * 0.51)
    vanishing = (cx, horizon_y)

    for layer in range(1, 18):
        depth = layer / 18.0
        scale = 1.0 / (depth * 2.4 + 0.18)
        rect_w = int(w * 0.18 * scale * zoom)
        rect_h = int(h * 0.12 * scale * zoom)
        alpha = int(8 + (1.0 - depth) * 34)
        rect = pygame.Rect(0, 0, rect_w, rect_h)
        rect.center = vanishing
        pygame.draw.rect(tesseract, (*ice, alpha), rect, 1, border_radius=2)

    vertical_count = 18
    for i in range(vertical_count + 1):
        k = i / vertical_count
        top_x = int(lerp(60, w - 60, k))
        bottom_x = int(lerp(-w * 0.14, w * 1.14, k))
        wobble = int(math.sin(t * 0.25 + i * 0.7) * 8)
        pygame.draw.line(
            tesseract,
            (*ice, 22),
            (top_x + wobble, int(h * 0.13)),
            (bottom_x - wobble, int(h * 0.88)),
            1,
        )

    horizontal_count = 13
    for i in range(horizontal_count):
        k = i / max(1, horizontal_count - 1)
        y = int(lerp(int(h * 0.18), int(h * 0.84), k))
        alpha = int(10 + (1.0 - abs(k - 0.5) * 2.0) * 20)
        pygame.draw.line(tesseract, (*ice, alpha), (70, y), (w - 70, y), 1)

    # Extra bookshelf-like ribs, inspired by the final-scene tesseract without copying it literally.
    rib_rng = random.Random(1776 + gate_seed)
    for i in range(46):
        x = rib_rng.randint(80, w - 80)
        y = rib_rng.randint(int(h * 0.15), int(h * 0.82))
        length = rib_rng.randint(34, 120)
        alpha = rib_rng.randint(10, 36)
        pygame.draw.line(tesseract, (*accent, alpha), (x, y), (x, y + length), 1)
        if i % 3 == 0:
            pygame.draw.line(tesseract, (*ice, alpha // 2), (x - 10, y), (x + 10, y), 1)

    surface.blit(tesseract, (0, 0))

    # Gargantua-inspired black hole: accretion disk + lensing arcs + dark center.
    blackhole = pygame.Surface((w, h), pygame.SRCALPHA)
    disk_w = int(430 * zoom)
    disk_h = int(108 * zoom)

    for i in range(16):
        spread = i / 15.0
        rect = pygame.Rect(0, 0, disk_w + i * 28, disk_h + i * 8)
        rect.center = (cx, cy)
        alpha = int(58 * (1.0 - spread))
        color = lerp_color(warm_disk, ice, spread * 0.45)
        pygame.draw.ellipse(blackhole, (*color, alpha), rect, 2)

    # Rotating arcs around the singularity.
    for i in range(10):
        r = int((92 + i * 24) * zoom)
        rect = pygame.Rect(cx - r, cy - r, r * 2, r * 2)
        start = t * (0.12 + i * 0.012) + i * 0.48
        arc_color = lerp_color(ice, accent, 0.18)
        pygame.draw.arc(blackhole, (*arc_color, max(18, 74 - i * 6)), rect, start, start + 1.9, 2)

    draw_glow_circle(blackhole, (cx, cy), int(170 * zoom), ice, 20)
    pygame.draw.circle(blackhole, (0, 0, 0, 235), (cx, cy), int(78 * zoom))
    pygame.draw.circle(blackhole, (5, 8, 16, 255), (cx, cy), int(62 * zoom))
    pygame.draw.circle(blackhole, (*ice, 80), (cx, cy), int(84 * zoom), 2)
    pygame.draw.circle(blackhole, (*accent, 34), (cx, cy), int(118 * zoom), 1)
    surface.blit(blackhole, (0, 0))

    # Slow gravitational rays pulling toward the center.
    rays = pygame.Surface((w, h), pygame.SRCALPHA)
    for i in range(34):
        angle = i * math.tau / 34.0 + math.sin(t * 0.08) * 0.08
        outer = min(w, h) * (0.62 + 0.08 * math.sin(i))
        inner = 105 * zoom
        x1 = int(cx + math.cos(angle) * outer)
        y1 = int(cy + math.sin(angle) * outer * 0.58)
        x2 = int(cx + math.cos(angle + 0.04) * inner)
        y2 = int(cy + math.sin(angle + 0.04) * inner * 0.58)
        pygame.draw.line(rays, (*ice, 9 + (i % 4) * 4), (x1, y1), (x2, y2), 1)
    surface.blit(rays, (0, 0))

    # Cinematic letterbox and vignette.
    overlay = pygame.Surface((w, h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 28))
    pygame.draw.rect(overlay, (0, 0, 0, 180), (0, 0, w, int(h * 0.105)))
    pygame.draw.rect(overlay, (0, 0, 0, 190), (0, int(h * 0.895), w, int(h * 0.105)))
    pygame.draw.rect(overlay, (0, 0, 0, 70), (0, 0, int(w * 0.08), h))
    pygame.draw.rect(overlay, (0, 0, 0, 70), (int(w * 0.92), 0, int(w * 0.08), h))
    surface.blit(overlay, (0, 0))

    font_title = pygame.font.SysFont("georgia", 46, bold=True)
    font_body = pygame.font.SysFont("trebuchetms", 18)
    font_small = pygame.font.SysFont("trebuchetms", 13)
    font_tiny = pygame.font.SysFont("trebuchetms", 11, bold=True)

    title = "THE EVENT HORIZON"
    subtitle = "Space is folding. Time is no longer stable."
    hunter = getattr(player, "name", "Hunter") if player is not None else "Hunter"

    title_img = font_title.render(title, True, (238, 246, 255))
    subtitle_img = font_body.render(subtitle, True, soft_ice)
    surface.blit(title_img, (cx - title_img.get_width() // 2, int(h * 0.145)))
    surface.blit(subtitle_img, (cx - subtitle_img.get_width() // 2, int(h * 0.145) + 56))

    meta = f"GATE RANK {rank}  /  HUNTER {hunter}  /  TESSERACT LINK ACTIVE"
    meta_img = font_tiny.render(meta, True, (150, 176, 210))
    surface.blit(meta_img, (cx - meta_img.get_width() // 2, int(h * 0.145) + 86))

    # Minimal loading indicator: no arcade percentage spam, just clean cinematic progress.
    bar_w = int(w * 0.42)
    bar = pygame.Rect(cx - bar_w // 2, h - int(h * 0.065), bar_w, 4)
    pygame.draw.rect(surface, (34, 44, 62), bar, border_radius=3)
    fill = pygame.Rect(bar.x, bar.y, int(bar.width * progress), bar.height)
    pygame.draw.rect(surface, ice, fill, border_radius=3)

    status_phases = (
        "Mapping gravitational corridor",
        "Synchronizing spatial coordinates",
        "Crossing event horizon",
        "Stabilizing gate exit",
    )
    phase_index = min(len(status_phases) - 1, int(progress * len(status_phases)))
    status = status_phases[phase_index]
    status_img = font_small.render(status, True, (168, 188, 215))
    surface.blit(status_img, (cx - status_img.get_width() // 2, bar.y - 28))

    # Subtle final fade, not a flash.
    if progress > 0.86:
        fade_t = (progress - 0.86) / 0.14
        fade = pygame.Surface((w, h), pygame.SRCALPHA)
        fade.fill((235, 245, 255, int(42 * fade_t)))
        surface.blit(fade, (0, 0))

def sync_player_save(save_system: SaveSystem, save_data: dict, player: Player) -> dict:
    merged = dict(save_data)
    merged.update(player.to_persistent_state())
    save_system.save(merged)
    return merged


def register_gate_clear(save_system: SaveSystem, save_data: dict, gate: Gate) -> dict:
    progress = save_data.setdefault("progress", {})
    progress["gates_cleared"] = int(progress.get("gates_cleared", 0)) + 1
    progress["bosses_killed"] = int(progress.get("bosses_killed", 0)) + 1

    previous_rank = str(progress.get("highest_gate_rank_cleared", "E")).upper()
    previous_index = GATE_RANK_ORDER.index(previous_rank) if previous_rank in GATE_RANK_ORDER else 0
    current_index = GATE_RANK_ORDER.index(gate.rank) if gate.rank in GATE_RANK_ORDER else 0
    if current_index > previous_index:
        progress["highest_gate_rank_cleared"] = gate.rank

    save_system.save(save_data)
    return save_data


def apply_gate_clear_rewards(player: Player, gate: Gate) -> str:
    current_mastery = player.get_class_mastery_state()["level"]
    rewards = gate_clear_rewards(
        gate.rank,
        rooms_cleared=gate.current_room_index,
        kills=getattr(player, "_last_run_kills", 0),
        flawless=getattr(player, "_last_run_flawless", False),
        mastery_level=current_mastery,
    )
    gold_gain = player.add_gold(rewards.get("gold", 0))
    potion_gain = max(0, int(rewards.get("potions", 0)))
    mana_gain = max(0, int(rewards.get("mana", 0)))
    stamina_gain = max(0, int(rewards.get("stamina", 0)))
    mastery_gain = max(0, int(rewards.get("mastery_xp", 0)))
    if potion_gain > 0:
        player.inventory.add_item("healing_potion", "Healing Potion", potion_gain, "consumable")
    if mana_gain > 0:
        player.inventory.add_item("mana_potion", "Mana Potion", mana_gain, "consumable")
    if stamina_gain > 0:
        player.inventory.add_item("stamina_tonic", "Stamina Tonic", stamina_gain, "consumable")
    player.gain_class_mastery(mastery_gain)
    return f"Cleared {gate.rank} | +{gold_gain}G | +{potion_gain} HP | +{mana_gain} MP | +{stamina_gain} ST | +{mastery_gain} Mastery"


def buy_shop_item(save_system: SaveSystem, save_data: dict, item_key: int) -> tuple[dict, str]:
    item = SHOP_ITEMS.get(item_key)
    if item is None:
        return save_data, ""

    player_data = save_data.setdefault("player", {})
    gold = int(player_data.get("gold", 0))
    if gold < item["cost"]:
        return save_data, "Not enough gold"

    player_data["gold"] = gold - item["cost"]

    if item["apply"] == "potions":
        inventory = save_data.setdefault("inventory", {"max_slots": 24, "items": []})
        items = inventory.setdefault("items", [])
        existing = next((it for it in items if it.get("item_id") == "healing_potion"), None)
        if existing is None:
            items.append({
                "item_id": "healing_potion",
                "name": "Healing Potion",
                "quantity": 3,
                "item_type": "consumable",
            })
        else:
            existing["quantity"] = int(existing.get("quantity", 0)) + 3
        message = "Bought Potion Refill x3"
    elif item["apply"] == "healing_bundle":
        inventory = save_data.setdefault("inventory", {"max_slots": 24, "items": []})
        items = inventory.setdefault("items", [])
        existing = next((it for it in items if it.get("item_id") == "healing_potion"), None)
        if existing is None:
            items.append({"item_id": "healing_potion", "name": "Healing Potion", "quantity": 2, "item_type": "consumable"})
        else:
            existing["quantity"] = int(existing.get("quantity", 0)) + 2
        message = "Bought Healing Bundle x2"
    elif item["apply"] == "mana_bundle":
        inventory = save_data.setdefault("inventory", {"max_slots": 24, "items": []})
        items = inventory.setdefault("items", [])
        existing = next((it for it in items if it.get("item_id") == "mana_potion"), None)
        if existing is None:
            items.append({"item_id": "mana_potion", "name": "Mana Potion", "quantity": 2, "item_type": "consumable"})
        else:
            existing["quantity"] = int(existing.get("quantity", 0)) + 2
        message = "Bought Mana Draft x2"
    elif item["apply"] == "stamina_bundle":
        inventory = save_data.setdefault("inventory", {"max_slots": 24, "items": []})
        items = inventory.setdefault("items", [])
        existing = next((it for it in items if it.get("item_id") == "stamina_tonic"), None)
        if existing is None:
            items.append({"item_id": "stamina_tonic", "name": "Stamina Tonic", "quantity": 2, "item_type": "consumable"})
        else:
            existing["quantity"] = int(existing.get("quantity", 0)) + 2
        message = "Bought Stamina Tonic x2"
    elif item["apply"] == "hp":
        player_data["level"] = int(player_data.get("level", 1))
        player_data.setdefault("shop_bonus_hp", 0)
        player_data["shop_bonus_hp"] += 12
        message = "Bought Vitality Boost +12 HP"
    elif item["apply"] == "attack":
        player_data["level"] = int(player_data.get("level", 1))
        player_data.setdefault("shop_bonus_attack", 0.0)
        player_data["shop_bonus_attack"] += 0.08
        message = "Bought Sharpening Sigil +8% Attack"
    else:
        player_data["level"] = int(player_data.get("level", 1))
        player_data.setdefault("shop_bonus_mana", 0)
        player_data["shop_bonus_mana"] += 12
        message = "Bought Mana Surge +12 Mana"

    save_system.save(save_data)
    return save_data, message


def record_to_enemies(enemies: list, method_name: str, *args) -> None:
    for enemy in enemies:
        method = getattr(enemy, method_name, None)
        if callable(method):
            method(*args)


def infer_dash_direction(player: Player, gate: Gate) -> str:
    enemies = [enemy for enemy in gate.get_active_enemies() if getattr(enemy, "alive", False)]
    if not enemies:
        return "back"

    nearest = min(enemies, key=lambda enemy: player.distance_to(enemy))
    to_enemy_x = nearest.x - player.x
    to_enemy_y = nearest.y - player.y
    enemy_len = math.hypot(to_enemy_x, to_enemy_y)
    move_len = math.hypot(player.facing_x, player.facing_y)
    if enemy_len <= 0 or move_len <= 0:
        return "back"

    to_enemy_x /= enemy_len
    to_enemy_y /= enemy_len
    move_x = player.facing_x / move_len
    move_y = player.facing_y / move_len

    forward_dot = move_x * to_enemy_x + move_y * to_enemy_y
    side_dot = move_x * (-to_enemy_y) + move_y * to_enemy_x

    if forward_dot >= 0.55:
        return "forward"
    if forward_dot <= -0.55:
        return "back"
    if side_dot >= 0:
        return "left"
    return "right"


def sync_global_player_profile(global_db: GlobalLearningDB, world_memory: CombatMemory, *, persist: bool = False) -> None:
    global_db.set_player_profile_memory(world_memory.to_dict())
    if persist:
        global_db.save()


def record_global_player_action(
    global_db: GlobalLearningDB | None,
    world_memory: CombatMemory | None,
    action_name: str,
    direction: str | None = None,
    *,
    persist: bool = False,
) -> None:
    if global_db is None or world_memory is None:
        return
    if action_name == "basic_attack":
        world_memory.record_basic_attack()
    elif action_name in {"skill_1", "class_skill"}:
        world_memory.record_skill_1()
    elif action_name == "ult":
        world_memory.record_ult()
    elif action_name == "dash":
        world_memory.record_dash(direction or "back")
    sync_global_player_profile(global_db, world_memory, persist=persist)


def observe_global_combat(global_db: GlobalLearningDB, world_memory: CombatMemory, player: Player, gate: Gate, dt: float) -> None:
    enemies = gate.get_active_enemies()
    if not enemies:
        return
    distances = [player.distance_to(enemy) for enemy in enemies if getattr(enemy, "alive", False)]
    if not distances:
        return
    world_memory.observe_tick(min(distances), dt)
    sync_global_player_profile(global_db, world_memory, persist=False)


def trigger_basic_attack(player: Player, gate: Gate, global_db: GlobalLearningDB | None = None, world_memory: CombatMemory | None = None) -> bool:
    current_enemies = gate.get_active_enemies()
    if player.try_basic_attack(current_enemies):
        record_to_enemies(current_enemies, "record_player_basic_attack")
        record_global_player_action(global_db, world_memory, "basic_attack")
        return True
    return False


def handle_continuous_combat_input(
    player: Player,
    gate: Gate,
    window_size: tuple[int, int],
    keybinds: dict[str, int],
    global_db: GlobalLearningDB | None = None,
    world_memory: CombatMemory | None = None,
) -> None:
    if player.inventory_open or player.skill_tree_open:
        return

    keys = pygame.key.get_pressed()
    mouse_buttons = pygame.mouse.get_pressed(3)
    current_enemies = gate.get_active_enemies()

    if mouse_buttons[0]:
        trigger_basic_attack(player, gate, global_db, world_memory)

    if keys[keybinds["skill_1"]]:
        cam_x, cam_y = get_camera(player)
        mouse_x, mouse_y = get_scaled_mouse_pos(window_size)
        world_mouse_x = mouse_x + cam_x
        world_mouse_y = mouse_y + cam_y
        if player.try_skill_1_projectile(world_mouse_x - player.x, world_mouse_y - player.y, current_enemies):
            record_to_enemies(current_enemies, "record_player_skill_1")
            record_global_player_action(global_db, world_memory, "skill_1")

    if keys[keybinds["ult"]]:
        if player.try_ult(current_enemies):
            record_to_enemies(current_enemies, "record_player_ult")
            record_global_player_action(global_db, world_memory, "ult")


def render_world(
    screen: pygame.Surface,
    player: Player,
    gate: Gate,
    hud: HUD,
    last_kill_feed: str,
    draw_extra_ui: bool = True,
    show_debug_ui: bool = False,
) -> None:
    cam_x, cam_y = get_camera(player)
    t = pygame.time.get_ticks() / 1000.0
    combat_active = len(gate.get_active_enemies()) > 0

    draw_dungeon_background(screen, gate, cam_x, cam_y, t, combat_active=combat_active)
    draw_world_bounds(screen, cam_x, cam_y)

    player.draw(screen, cam_x, cam_y, draw_hp_bar=True)

    for enemy in gate.get_active_enemies():
        enemy.draw(screen, cam_x, cam_y, draw_hp_bar=True)

    hud.draw(screen, player, gate, last_kill_feed)

    if draw_extra_ui:
        if show_debug_ui:
            dbg = player.get_debug_state()
            debug_lines = [
                f"Player HP: {dbg['hp']}",
                f"Mana: {dbg['mana']}",
                f"Stamina: {dbg['stamina']}",
                f"Level: {dbg['level']}",
                f"XP: {dbg['xp']}/{dbg['xp_next']}",
                f"Dash CD: {dbg['dash_cd']}",
                f"Basic CD: {dbg['basic_cd']}",
                f"Skill1 CD: {dbg['skill_1_cd']}",
                f"Class CD: {dbg['class_skill_cd']}",
                f"ULT CD: {dbg['ult_cd']}",
                f"Dashing: {dbg['is_dashing']}",
                f"Hit Grace: {dbg['invuln']}",
                f"Projectiles: {dbg['projectiles']}",
            ]

            x = SCREEN_WIDTH - 270
            y = 230

            title = hud.font_medium.render("Debug", True, (255, 255, 255))
            screen.blit(title, (x, y))

            for i, line in enumerate(debug_lines):
                img = hud.font_small.render(line, True, (200, 200, 200))
                screen.blit(img, (x, y + 28 + i * 18))


def main() -> None:
    pygame.display.init()
    pygame.font.init()

    window_size = get_desktop_window_size()
    screen = pygame.display.set_mode(window_size, pygame.NOFRAME)
    frame = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption(GAME_TITLE)
    clock = pygame.time.Clock()

    world_rect = pygame.Rect(0, 0, WORLD_WIDTH, WORLD_HEIGHT)

    menu_ui = MenuUI()
    save_system = SaveSystem()
    save_data = save_system.load()
    save_data.setdefault("player", {})["keybinds"] = normalize_keybinds(save_data.get("player", {}).get("keybinds"))
    global_learning_db = GlobalLearningDB()
    world_player_memory = CombatMemory()
    world_player_memory.load_from_dict(global_learning_db.get_player_profile_memory())
    player = None
    gate = None
    hud = None

    game_state = STATE_TITLE
    running = True
    last_kill_feed = ""
    gate_clear_recorded = False
    run_summary = {}
    show_debug_ui = SHOW_DEBUG_UI_DEFAULT
    pending_keybind_action: str | None = None
    loading_elapsed = 0.0
    loading_variant = random.choice(LOADING_VARIANTS)

    def begin_loading_run() -> None:
        nonlocal player, gate, hud, run_summary, last_kill_feed, gate_clear_recorded, game_state, loading_elapsed, loading_variant
        player, gate, hud = create_run(save_data)
        run_summary = build_run_summary(player, gate)
        last_kill_feed = ""
        gate_clear_recorded = False
        loading_elapsed = 0.0
        loading_variant = random.choice(LOADING_VARIANTS)
        game_state = STATE_LOADING

    while running:
        dt = clock.tick(FPS) / 1000.0
        events = pygame.event.get()
        keybinds = resolve_keybinds(save_data.get("player", {}).get("keybinds"))
        menu_ui.pending_keybind_action = pending_keybind_action
        menu_ui.keybind_labels = {action: keybind_display_name(name) for action, name in normalize_keybinds(save_data.get("player", {}).get("keybinds")).items()}

        for event in events:
            if event.type == pygame.QUIT:
                running = False
                continue

            if game_state == STATE_TITLE:
                if pending_keybind_action is not None and event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pending_keybind_action = None
                    else:
                        save_data.setdefault("player", {}).setdefault("keybinds", {})
                        save_data["player"]["keybinds"][pending_keybind_action] = pygame.key.name(event.key)
                        save_data["player"]["keybinds"] = normalize_keybinds(save_data["player"]["keybinds"])
                        save_system.save(save_data)
                        pending_keybind_action = None
                    continue

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    action = menu_ui.handle_click(window_to_virtual_pos(event.pos, window_size))
                    if action == "title_begin_hunt":
                        begin_loading_run()
                    elif action == "title_exit":
                        running = False
                    elif action is not None and action.startswith("rebind:"):
                        pending_keybind_action = action.split(":", 1)[1]
                    elif action is not None and action.startswith("title_class:"):
                        class_id = action.split(":", 1)[1]
                        if class_id in HUNTER_CLASSES:
                            save_data.setdefault("player", {})["class_id"] = class_id
                            starter_loadout = make_default_loadout(class_id)
                            save_data["player"]["equipped_skills"] = starter_loadout
                            unlocked = set(save_data["player"].get("unlocked_skills", make_default_unlocked_skills()))
                            unlocked.update(starter_loadout.values())
                            save_data["player"]["unlocked_skills"] = list(unlocked)
                            save_system.save(save_data)

                if event.type == pygame.KEYDOWN:
                    if event.key == keybinds["pause"]:
                        running = False
                    elif event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        class_ids = list(HUNTER_CLASSES.keys())
                        idx = event.key - pygame.K_1
                        if 0 <= idx < len(class_ids):
                            save_data.setdefault("player", {})["class_id"] = class_ids[idx]
                            starter_loadout = make_default_loadout(class_ids[idx])
                            save_data["player"]["equipped_skills"] = starter_loadout
                            unlocked = set(save_data["player"].get("unlocked_skills", make_default_unlocked_skills()))
                            unlocked.update(starter_loadout.values())
                            save_data["player"]["unlocked_skills"] = list(unlocked)
                            save_system.save(save_data)
                    elif event.key == pygame.K_q:
                        save_data.setdefault("player", {})["core_stats"] = sanitize_core_stats(save_data.setdefault("player", {}).get("core_stats", DEFAULT_CORE_STATS))
                        last_kill_feed = spend_title_build_point(save_data, "strength")
                        save_system.save(save_data)
                    elif event.key == pygame.K_w:
                        last_kill_feed = spend_title_build_point(save_data, "dexterity")
                        save_system.save(save_data)
                    elif event.key == pygame.K_e:
                        last_kill_feed = spend_title_build_point(save_data, "vitality")
                        save_system.save(save_data)
                    elif event.key == pygame.K_r:
                        last_kill_feed = spend_title_build_point(save_data, "endurance")
                        save_system.save(save_data)
                    elif event.key == pygame.K_t:
                        last_kill_feed = spend_title_build_point(save_data, "intelligence")
                        save_system.save(save_data)
                    elif event.key == pygame.K_BACKSPACE:
                        last_kill_feed = reset_title_build(save_data)
                        save_system.save(save_data)
                    elif event.key == pygame.K_z:
                        last_kill_feed = f"LMB -> {cycle_title_skill(save_data, 'lmb')}"
                        save_system.save(save_data)
                    elif event.key == pygame.K_x:
                        last_kill_feed = f"Q -> {cycle_title_skill(save_data, 'q')}"
                        save_system.save(save_data)
                    elif event.key == pygame.K_c:
                        last_kill_feed = f"F -> {cycle_title_skill(save_data, 'f')}"
                        save_system.save(save_data)
                    elif event.key == pygame.K_v:
                        last_kill_feed = f"Y -> {cycle_title_skill(save_data, 'y')}"
                        save_system.save(save_data)
                    elif event.key in SHOP_ITEMS:
                        save_data, last_kill_feed = buy_shop_item(save_system, save_data, event.key)
            elif game_state == STATE_LOADING:
                if event.type == pygame.KEYDOWN:
                    game_state = handle_loading_screen_input(event, game_state)
            elif game_state == STATE_PLAYING:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and player is not None and gate is not None:
                    trigger_basic_attack(player, gate, global_learning_db, world_player_memory)

                if event.type == pygame.KEYDOWN:
                    if event.key == keybinds["debug"]:
                        show_debug_ui = not show_debug_ui
                    elif event.key == keybinds["pause"]:
                        game_state = STATE_PAUSED

                    elif event.key == keybinds["dash"] and player is not None and gate is not None:
                        if player.try_dash():
                            dash_direction = infer_dash_direction(player, gate)
                            record_to_enemies(gate.get_active_enemies(), "record_player_dash", dash_direction)
                            record_global_player_action(global_learning_db, world_player_memory, "dash", dash_direction)

                    elif event.key == keybinds["heal_potion"] and player is not None:
                        used, message = player.use_healing_potion()
                        last_kill_feed = message
                        if used:
                            save_data = sync_player_save(save_system, save_data, player)

                    elif event.key == keybinds["mana_potion"] and player is not None:
                        used, message = player.use_mana_potion()
                        last_kill_feed = message
                        if used:
                            save_data = sync_player_save(save_system, save_data, player)

                    elif event.key == keybinds["stamina_tonic"] and player is not None:
                        used, message = player.use_stamina_tonic()
                        last_kill_feed = message
                        if used:
                            save_data = sync_player_save(save_system, save_data, player)

                    elif event.key == keybinds["class_skill"] and player is not None and gate is not None:
                        cam_x, cam_y = get_camera(player)
                        mouse_x, mouse_y = get_scaled_mouse_pos(window_size)
                        world_mouse_x = mouse_x + cam_x
                        world_mouse_y = mouse_y + cam_y
                        if player.try_class_skill(gate.get_active_enemies(), world_mouse_x - player.x, world_mouse_y - player.y):
                            record_to_enemies(gate.get_active_enemies(), "record_player_skill_1")
                            record_global_player_action(global_learning_db, world_player_memory, "class_skill")

                    elif event.key == keybinds["advance_room"] and player is not None and gate is not None:
                        if gate.can_advance() and gate.advance_room():
                            spawn_player_for_room(player, gate)

                if player is not None:
                    player.handle_input([event])

            elif game_state == STATE_PAUSED:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    action = menu_ui.handle_click(window_to_virtual_pos(event.pos, window_size))
                    if action == "pause_resume":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_PLAYING
                    elif action == "pause_title":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_TITLE
                    elif action == "pause_quit":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        running = False

                if event.type == pygame.KEYDOWN:
                    if event.key == keybinds["pause"]:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_PLAYING
                    elif event.key == pygame.K_t:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_TITLE
                    elif event.key == pygame.K_q:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        running = False

            elif game_state == STATE_DEAD:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    action = menu_ui.handle_click(window_to_virtual_pos(event.pos, window_size))
                    if action == "dead_retry":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        begin_loading_run()
                    elif action == "dead_title":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_TITLE
                    elif action == "dead_quit":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        running = False

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        begin_loading_run()
                    elif event.key == pygame.K_t:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_TITLE
                    elif event.key == pygame.K_q:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        running = False

            elif game_state == STATE_CLEARED:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    action = menu_ui.handle_click(window_to_virtual_pos(event.pos, window_size))
                    if action == "clear_retry":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        begin_loading_run()
                    elif action == "clear_title":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_TITLE
                    elif action == "clear_quit":
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        running = False

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        begin_loading_run()
                    elif event.key == pygame.K_t:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        game_state = STATE_TITLE
                    elif event.key == pygame.K_q:
                        if player is not None:
                            save_data = sync_player_save(save_system, save_data, player)
                        sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                        running = False

        if game_state == STATE_LOADING:
            loading_elapsed += dt
            if loading_elapsed >= LOADING_SCREEN_DURATION:
                game_state = STATE_PLAYING

        if game_state == STATE_PLAYING and player is not None and gate is not None:
            run_summary["rooms_reached"] = max(run_summary.get("rooms_reached", 0), gate.current_room_index)
            prev_hp = player.stats.hp
            handle_continuous_combat_input(player, gate, window_size, keybinds, global_learning_db, world_player_memory)
            gate.update(player)
            active_enemies = gate.get_active_enemies()
            room_bounds = gate.current_room_bounds()
            room_walls = gate.current_room_walls()
            observe_global_combat(global_learning_db, world_player_memory, player, gate, dt)

            if hud is not None:
                hud.update(dt)

            player.navigation_walls = room_walls
            player_prev_x, player_prev_y = player.x, player.y
            player.update(dt, room_bounds)
            gate.resolve_entity_position(player, player_prev_x, player_prev_y)
            player.update_projectiles(dt, active_enemies, room_bounds)
            for enemy in active_enemies:
                enemy.navigation_walls = room_walls
                enemy_prev_x, enemy_prev_y = enemy.x, enemy.y
                enemy.update(dt, room_bounds)
                gate.resolve_entity_position(enemy, enemy_prev_x, enemy_prev_y)

            if player.stats.hp < prev_hp:
                run_summary["damage_taken"] = run_summary.get("damage_taken", 0) + int(round(prev_hp - player.stats.hp))
                run_summary["flawless"] = False

            kill_feed = reward_if_kill_happened(player)
            if kill_feed:
                killed_name = player.last_attack_result.get("target_name") or ""
                run_summary["kills"] = run_summary.get("kills", 0) + 1
                run_summary["xp_earned"] = run_summary.get("xp_earned", 0) + Player.xp_for_enemy_name(killed_name)
                run_summary["levels_gained"] = max(0, player.progression.level - run_summary.get("level_start", player.progression.level))
                last_kill_feed = kill_feed
                save_data = sync_player_save(save_system, save_data, player)
            else:
                last_kill_feed = ""

            persist_boss_learning_if_needed(gate)

            if not player.alive:
                run_summary = finalize_run_summary(run_summary, player, gate)
                save_data = sync_player_save(save_system, save_data, player)
                sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                game_state = STATE_DEAD
            elif gate.finished:
                if not gate_clear_recorded:
                    player._last_run_kills = run_summary.get("kills", 0)
                    player._last_run_flawless = bool(run_summary.get("flawless", False))
                    last_kill_feed = apply_gate_clear_rewards(player, gate)
                    save_data = sync_player_save(save_system, save_data, player)
                    save_data = register_gate_clear(save_system, save_data, gate)
                    run_summary = finalize_run_summary(run_summary, player, gate)
                    sync_global_player_profile(global_learning_db, world_player_memory, persist=True)
                    gate_clear_recorded = True
                game_state = STATE_CLEARED

        menu_ui.set_mouse_pos(get_scaled_mouse_pos(window_size))

        if game_state == STATE_TITLE:
            selected_class = save_data.get("player", {}).get("class_id", "striker")
            core_stats = sanitize_core_stats(save_data.get("player", {}).get("core_stats", DEFAULT_CORE_STATS))
            loadout = sanitize_loadout(save_data.get("player", {}).get("equipped_skills", {}), selected_class)
            menu_ui.draw_title_screen(
                frame,
                selected_class=selected_class,
                highest_rank=str(save_data.get("progress", {}).get("highest_gate_rank_cleared", "E")),
                gold=int(save_data.get("player", {}).get("gold", 0)),
                class_mastery_level=int(save_data.get("player", {}).get("class_mastery", {}).get(selected_class, {}).get("level", 1)),
                shop_bonus_hp=int(save_data.get("player", {}).get("shop_bonus_hp", 0)),
                shop_bonus_mana=int(save_data.get("player", {}).get("shop_bonus_mana", 0)),
                shop_bonus_attack=round(float(save_data.get("player", {}).get("shop_bonus_attack", 0.0)) * 100),
                build_points=int(save_data.get("player", {}).get("build_points", STARTING_BUILD_POINTS)),
                core_stats=core_stats,
                loadout_names={slot: get_skill_def(skill_id).name for slot, skill_id in loadout.items()},
                title_message=last_kill_feed,
            )

        elif game_state == STATE_LOADING:
            draw_loading_screen(frame, loading_elapsed, LOADING_SCREEN_DURATION, player, gate, loading_variant)

        elif game_state == STATE_PLAYING:
            if player is not None and gate is not None and hud is not None:
                render_world(frame, player, gate, hud, last_kill_feed, draw_extra_ui=True, show_debug_ui=show_debug_ui)

        elif game_state == STATE_PAUSED:
            if player is not None and gate is not None and hud is not None:
                render_world(frame, player, gate, hud, last_kill_feed, draw_extra_ui=False, show_debug_ui=show_debug_ui)
            menu_ui.draw_pause_menu(frame)

        elif game_state == STATE_DEAD:
            if player is not None and gate is not None and hud is not None:
                render_world(frame, player, gate, hud, last_kill_feed, draw_extra_ui=False, show_debug_ui=show_debug_ui)
            menu_ui.draw_death_screen(frame, run_summary)

        elif game_state == STATE_CLEARED:
            if player is not None and gate is not None and hud is not None:
                render_world(frame, player, gate, hud, last_kill_feed, draw_extra_ui=False, show_debug_ui=show_debug_ui)
            menu_ui.draw_clear_screen(frame, run_summary)

        present_frame(screen, frame, window_size)
        pygame.display.flip()

    if player is not None:
        save_data = sync_player_save(save_system, save_data, player)
    sync_global_player_profile(global_learning_db, world_player_memory, persist=True)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
