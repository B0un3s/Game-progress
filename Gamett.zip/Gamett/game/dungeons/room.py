from __future__ import annotations

from dataclasses import dataclass, field
from game.dungeons.types import RoomType


@dataclass
class RoomTemplate:
    room_id: int
    room_type: RoomType
    encounter_budget: int = 0
    theme: str = "unknown"
    notes: list[str] = field(default_factory=list)
