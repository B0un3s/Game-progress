from __future__ import annotations

from typing import Literal, TypedDict

from game.config import GATE_RANK_ORDER


DEFAULT_RANK = "C"

RoomType = Literal["start", "normal", "boss"]
EncounterTheme = Literal["standard", "swarm", "hunter_pack", "elite_hunt"]
BossType = Literal["boss", "ss_boss"]


class RankSettings(TypedDict):
    label: str
    theme: str
    boss_name: str
    boss_style: str
    room_range: tuple[int, int]
    mob_range: tuple[int, int]
    boss_type: BossType
    accent: tuple[int, int, int]


class GateRewards(TypedDict):
    gold: int
    potions: int
    mana: int
    stamina: int
    mastery_xp: int


RANK_SETTINGS: dict[str, RankSettings] = {
    "E": {
        "label": "E-Rank Ruin",
        "theme": "Broken Training Grounds",
        "boss_name": "Feral Gatekeeper",
        "boss_style": "crusher",
        "room_range": (2, 3),
        "mob_range": (1, 2),
        "boss_type": "boss",
        "accent": (126, 149, 166),
    },
    "D": {
        "label": "D-Rank Ruin",
        "theme": "Collapsed Watch",
        "boss_name": "Howling Warden",
        "boss_style": "hunter",
        "room_range": (3, 4),
        "mob_range": (2, 3),
        "boss_type": "boss",
        "accent": (88, 148, 173),
    },
    "C": {
        "label": "C-Rank Abyss",
        "theme": "Flooded Arsenal",
        "boss_name": "Iron Devourer",
        "boss_style": "crusher",
        "room_range": (4, 5),
        "mob_range": (2, 4),
        "boss_type": "boss",
        "accent": (81, 167, 163),
    },
    "B": {
        "label": "B-Rank Abyss",
        "theme": "Ashen Foundry",
        "boss_name": "Ashfang Brute",
        "boss_style": "crusher",
        "room_range": (5, 6),
        "mob_range": (3, 4),
        "boss_type": "boss",
        "accent": (113, 188, 112),
    },
    "A": {
        "label": "A-Rank Citadel",
        "theme": "Crimson Vault",
        "boss_name": "Vault Tyrant",
        "boss_style": "ritualist",
        "room_range": (6, 7),
        "mob_range": (3, 5),
        "boss_type": "boss",
        "accent": (206, 142, 79),
    },
    "S": {
        "label": "S-Rank Citadel",
        "theme": "Storm Reliquary",
        "boss_name": "Tempest Sovereign",
        "boss_style": "hunter",
        "room_range": (7, 8),
        "mob_range": (4, 5),
        "boss_type": "boss",
        "accent": (228, 120, 104),
    },
    "SS": {
        "label": "SS-Rank Domain",
        "theme": "Adaptive Grave",
        "boss_name": "SS Adaptive Boss",
        "boss_style": "predator",
        "room_range": (8, 9),
        "mob_range": (4, 6),
        "boss_type": "ss_boss",
        "accent": (220, 94, 130),
    },
    "SSS": {
        "label": "SSS-Rank Domain",
        "theme": "Void Cathedral",
        "boss_name": "Void Ascendant",
        "boss_style": "oracle",
        "room_range": (9, 10),
        "mob_range": (5, 6),
        "boss_type": "ss_boss",
        "accent": (190, 84, 184),
    },
    "EX": {
        "label": "EX Cataclysm Gate",
        "theme": "Sunless Throne",
        "boss_name": "Cataclysm Regent",
        "boss_style": "cataclysm",
        "room_range": (10, 11),
        "mob_range": (5, 7),
        "boss_type": "ss_boss",
        "accent": (131, 96, 225),
    },
    "MONARCH": {
        "label": "Monarch Rift",
        "theme": "World-End Mausoleum",
        "boss_name": "Monarch of Ruin",
        "boss_style": "cataclysm",
        "room_range": (11, 12),
        "mob_range": (6, 8),
        "boss_type": "ss_boss",
        "accent": (245, 215, 101),
    },
}


def normalize_rank(rank: str) -> str:
    normalized = str(rank).upper()
    if normalized in GATE_RANK_ORDER:
        return normalized
    return DEFAULT_RANK


def rank_index(rank: str) -> int:
    normalized = normalize_rank(rank)
    return GATE_RANK_ORDER.index(normalized)
