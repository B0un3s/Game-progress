from __future__ import annotations

from game.dungeons.room import RoomTemplate
from game.dungeons.types import rank_index


class DungeonLayoutGenerator:
    def build_room_plan(self, rank: str, room_count: int, theme: str) -> list[RoomTemplate]:
        normalized_rank_index = rank_index(rank)
        room_count = max(1, int(room_count))
        theme = str(theme or "unknown")

        rooms = [RoomTemplate(room_id=0, room_type="start", theme=theme)]
        for i in range(1, room_count + 1):
            encounter_budget = i + max(0, normalized_rank_index - 2)
            rooms.append(RoomTemplate(room_id=i, room_type="normal", encounter_budget=encounter_budget, theme=theme))
        boss_budget = room_count + 2 + max(0, normalized_rank_index - 1)
        rooms.append(RoomTemplate(room_id=room_count + 1, room_type="boss", encounter_budget=boss_budget, theme=theme))
        return rooms
