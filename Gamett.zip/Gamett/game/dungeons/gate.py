# game/dungeons/gate.py

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Protocol, TypedDict
import pygame

from game.dungeons.constants import (
    BOSS_ARENA_GAP,
    BOSS_ARENA_WALL_H,
    BOSS_ARENA_WALL_W,
    GRID_MARGIN,
    GRID_WALL_THICKNESS,
    MIN_SPAWN_SEPARATION,
    ROOM_BOUNDS,
    SPAWN_RADIUS,
)
from game.enemies.factory import create_enemy, create_miniboss, create_variant_enemy
from game.enemies.boss import Boss
from game.enemies.ss_boss import SSBoss
from game.dungeons.balance import DungeonBalance
from game.dungeons.types import (
    EncounterTheme,
    RankSettings,
    RANK_SETTINGS,
    RoomType,
    normalize_rank,
    rank_index,
)


class Combatant(Protocol):
    x: float
    y: float
    alive: bool
    radius: float

    def set_target(self, target: "Targetable") -> None: ...

    def set_coordination(
        self,
        role: str,
        *,
        anchor_x: float,
        anchor_y: float,
        pressure_scale: float,
    ) -> None: ...

    def distance_to(self, target: "Targetable") -> float: ...


class Targetable(Protocol):
    x: float
    y: float
    alive: bool


class PlayerLike(Targetable, Protocol):
    stats: Any


class SummonRequest(TypedDict, total=False):
    variant: str
    variants: list[str]
    count: int
    elite_chance: float


@dataclass
class GateRoom:
    room_id: int
    room_type: RoomType = "normal"
    encounter_theme: EncounterTheme = "standard"
    cleared: bool = False
    mobs: list[Combatant] = field(default_factory=list)
    room_bounds: pygame.Rect = field(default_factory=lambda: pygame.Rect(100, 90, 1080, 540))
    wall_rects: list[pygame.Rect] = field(default_factory=list)
    player_spawn: tuple[float, float] = (220.0, 360.0)
    enemy_spawn_points: list[tuple[float, float]] = field(default_factory=list)
    boss: Boss | SSBoss | None = None

    def is_combat_room(self) -> bool:
        return self.room_type in ("normal", "boss")

    def is_cleared(self) -> bool:
        if self.room_type == "boss":
            summons_cleared = all(not mob.alive for mob in self.mobs)
            return (self.boss is None or not self.boss.alive) and summons_cleared

        if self.room_type == "normal":
            return all(not mob.alive for mob in self.mobs)

        return True


class Gate:
    def __init__(self, rank: str = "A", seed: int | None = None):
        self.rank = normalize_rank(rank)
        self.seed = seed if seed is not None else random.randint(0, 99999999)
        self.rng = random.Random(self.seed)
        self.settings: RankSettings = RANK_SETTINGS[self.rank]
        self.display_name = self.settings["label"]
        self.theme_name = self.settings["theme"]
        self.accent_color = self.settings["accent"]

        self.rooms: list[GateRoom] = []
        self.current_room_index = 0
        self.finished = False
        self.failed = False
        self.player_power: float | None = None

        self.balance = DungeonBalance()

        self.generate()

    @staticmethod
    def _clamp(value: float, min_value: float, max_value: float) -> float:
        return max(min_value, min(max_value, value))

    def generate(self) -> None:
        self.rooms.clear()
        self.current_room_index = 0
        self.finished = False
        self.failed = False

        min_rooms, max_rooms = self.settings["room_range"]
        room_count = self.rng.randint(min_rooms, max_rooms)

        start_room = GateRoom(room_id=0, room_type="start")
        self._build_room_layout(start_room, boss_arena=False)
        start_room.wall_rects = []
        start_room.enemy_spawn_points = []
        self.rooms.append(start_room)

        for i in range(1, room_count + 1):
            room = GateRoom(room_id=i, room_type="normal", encounter_theme=self._roll_encounter_theme(i, room_count))
            self._build_room_layout(room, boss_arena=False)
            self._populate_normal_room(room)
            self.rooms.append(room)

        boss_room = GateRoom(room_id=room_count + 1, room_type="boss")
        self._build_room_layout(boss_room, boss_arena=True)
        self._populate_boss_room(boss_room)
        self.rooms.append(boss_room)

    def apply_balance(self, player: PlayerLike) -> None:
        power = self.balance.evaluate_player(player)
        self.player_power = power
        self.balance.calculate_multiplier(self.rank)

        for room in self.rooms:
            for mob in room.mobs:
                self.balance.scale_enemy(mob, power)

            if room.boss is not None:
                self.balance.scale_boss(room.boss, power)

    def _populate_normal_room(self, room: GateRoom) -> None:
        min_mobs, max_mobs = self.settings["mob_range"]
        mob_count = self.rng.randint(min_mobs, max_mobs)
        encounter = room.encounter_theme

        if encounter == "swarm":
            mob_count += 2
        elif encounter == "elite_hunt":
            mob_count = max(1, mob_count - 1)
        elif encounter == "hunter_pack":
            mob_count += 1

        room.mobs = []
        used_positions: list[tuple[float, float]] = []

        if encounter == "elite_hunt" and self.rank in {"B", "A", "S", "SS", "SSS", "EX", "MONARCH"}:
            mx, my = self._sample_enemy_spawn(room, used_positions, prefer_far=True)
            room.mobs.append(create_miniboss(mx, my, rank=self.rank, name=f"Hunt_{room.room_id}"))
            used_positions.append((mx, my))
            mob_count = max(1, mob_count)

        for i in range(mob_count):
            roll = self.rng.random()
            if encounter == "elite_hunt":
                roll = 0.0
            spawn_x, spawn_y = self._sample_enemy_spawn(room, used_positions)
            mob = create_enemy(
                spawn_x,
                spawn_y,
                rank=self.rank,
                name=f"Mob_{room.room_id}_{i}",
                roll=roll,
            )
            room.mobs.append(mob)
            used_positions.append((spawn_x, spawn_y))

    def _roll_encounter_theme(self, room_id: int, room_count: int) -> EncounterTheme:
        current_rank_index = rank_index(self.rank)
        options = [("standard", 10), ("swarm", 3 + current_rank_index // 2), ("hunter_pack", 2 + current_rank_index // 3)]
        if current_rank_index >= 2:
            options.append(("elite_hunt", 1 + current_rank_index // 2))
        if room_id == room_count:
            options.append(("elite_hunt", 2))
        return self.rng.choices([name for name, _ in options], weights=[weight for _, weight in options], k=1)[0]

    def _populate_boss_room(self, room: GateRoom) -> None:
        boss_name = self.settings["boss_name"]
        boss_style = self.settings.get("boss_style", "crusher")
        boss_x, boss_y = room.enemy_spawn_points[0] if room.enemy_spawn_points else (900, 360)
        if self.settings["boss_type"] == "ss_boss":
            boss_id = f"{self.rank.lower()}_gate_boss"
            room.boss = SSBoss(boss_x, boss_y, name=boss_name, boss_id=boss_id, style=boss_style)
        else:
            room.boss = Boss(boss_x, boss_y, name=boss_name, style=boss_style)

    def _build_room_layout(self, room: GateRoom, *, boss_arena: bool) -> None:
        room.room_bounds = ROOM_BOUNDS.copy()
        room.wall_rects = []
        room.enemy_spawn_points = []
        room.player_spawn = (room.room_bounds.left + 78, room.room_bounds.centery)

        if boss_arena:
            self._configure_boss_arena(room)
            return

        cols, rows, cell_w, cell_h, start_cell = self._grid_layout(room)
        open_edges = self._generate_open_edges(cols, rows, start_cell)
        self._build_grid_room_geometry(room, cols, rows, cell_w, cell_h, start_cell, open_edges)
        room.enemy_spawn_points = [
            point
            for point in room.enemy_spawn_points
            if self.is_walkable_point(point[0], point[1], SPAWN_RADIUS, room=room)
        ]

    def _configure_boss_arena(self, room: GateRoom) -> None:
        room.player_spawn = (room.room_bounds.left + 84, room.room_bounds.centery)
        room.enemy_spawn_points = [(room.room_bounds.right - 120, room.room_bounds.centery)]
        for side in (-1, 1):
            room.wall_rects.append(
                pygame.Rect(
                    room.room_bounds.centerx - BOSS_ARENA_GAP - BOSS_ARENA_WALL_W // 2,
                    room.room_bounds.centery + side * 120 - BOSS_ARENA_WALL_H // 2,
                    BOSS_ARENA_WALL_W,
                    BOSS_ARENA_WALL_H,
                )
            )
            room.wall_rects.append(
                pygame.Rect(
                    room.room_bounds.centerx + BOSS_ARENA_GAP - BOSS_ARENA_WALL_W // 2,
                    room.room_bounds.centery + side * 120 - BOSS_ARENA_WALL_H // 2,
                    BOSS_ARENA_WALL_W,
                    BOSS_ARENA_WALL_H,
                )
            )

    def _grid_layout(self, room: GateRoom) -> tuple[int, int, float, float, tuple[int, int]]:
        cols = 5 + self.rng.randint(0, 1)
        rows = 3 + self.rng.randint(0, 1)
        cell_w = (room.room_bounds.width - GRID_MARGIN * 2) / cols
        cell_h = (room.room_bounds.height - GRID_MARGIN * 2) / rows
        start_cell = (0, rows // 2)
        return cols, rows, cell_w, cell_h, start_cell

    def _generate_open_edges(
        self,
        cols: int,
        rows: int,
        start_cell: tuple[int, int],
    ) -> set[tuple[tuple[int, int], tuple[int, int]]]:
        visited = set()
        open_edges: set[tuple[tuple[int, int], tuple[int, int]]] = set()
        stack = [start_cell]
        visited.add(start_cell)
        while stack:
            cx, cy = stack[-1]
            neighbors = []
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx = cx + dx
                ny = cy + dy
                if 0 <= nx < cols and 0 <= ny < rows and (nx, ny) not in visited:
                    neighbors.append((nx, ny))
            if neighbors:
                nx, ny = self.rng.choice(neighbors)
                open_edges.add(tuple(sorted(((cx, cy), (nx, ny)))))
                visited.add((nx, ny))
                stack.append((nx, ny))
            else:
                stack.pop()

        extra_links = 2 + self.rng.randint(0, 2)
        for _ in range(extra_links):
            x = self.rng.randint(0, cols - 1)
            y = self.rng.randint(0, rows - 1)
            possible = []
            for dx, dy in ((1, 0), (0, 1)):
                nx = x + dx
                ny = y + dy
                if nx < cols and ny < rows:
                    edge = tuple(sorted(((x, y), (nx, ny))))
                    if edge not in open_edges:
                        possible.append(edge)
            if possible:
                open_edges.add(self.rng.choice(possible))
        return open_edges

    def _build_grid_room_geometry(
        self,
        room: GateRoom,
        cols: int,
        rows: int,
        cell_w: float,
        cell_h: float,
        start_cell: tuple[int, int],
        open_edges: set[tuple[tuple[int, int], tuple[int, int]]],
    ) -> None:
        for x in range(cols):
            for y in range(rows):
                cell_center = (
                    room.room_bounds.left + GRID_MARGIN + cell_w * (x + 0.5),
                    room.room_bounds.top + GRID_MARGIN + cell_h * (y + 0.5),
                )
                if (x, y) == start_cell:
                    room.player_spawn = (cell_center[0] - min(42, cell_w * 0.2), cell_center[1])
                else:
                    room.enemy_spawn_points.append(cell_center)

                if x < cols - 1 and tuple(sorted(((x, y), (x + 1, y)))) not in open_edges:
                    wall_x = int(room.room_bounds.left + GRID_MARGIN + cell_w * (x + 1) - GRID_WALL_THICKNESS / 2)
                    wall_y = int(room.room_bounds.top + GRID_MARGIN + cell_h * y + 10)
                    room.wall_rects.append(
                        pygame.Rect(wall_x, wall_y, GRID_WALL_THICKNESS, max(20, int(cell_h - 20)))
                    )

                if y < rows - 1 and tuple(sorted(((x, y), (x, y + 1)))) not in open_edges:
                    wall_x = int(room.room_bounds.left + GRID_MARGIN + cell_w * x + 10)
                    wall_y = int(room.room_bounds.top + GRID_MARGIN + cell_h * (y + 1) - GRID_WALL_THICKNESS / 2)
                    room.wall_rects.append(
                        pygame.Rect(wall_x, wall_y, max(20, int(cell_w - 20)), GRID_WALL_THICKNESS)
                    )

    def _sample_enemy_spawn(self, room: GateRoom, used_positions: list[tuple[float, float]], *, prefer_far: bool = False) -> tuple[float, float]:
        candidates = list(room.enemy_spawn_points)
        if not candidates:
            candidates = [(room.room_bounds.right - 140, room.room_bounds.centery)]
        if prefer_far:
            candidates.sort(key=lambda pos: abs(pos[0] - room.player_spawn[0]) + abs(pos[1] - room.player_spawn[1]), reverse=True)
        else:
            self.rng.shuffle(candidates)
        for px, py in candidates:
            if any(((px - ux) ** 2 + (py - uy) ** 2) < (MIN_SPAWN_SEPARATION ** 2) for ux, uy in used_positions):
                continue
            if self.is_walkable_point(px, py, SPAWN_RADIUS, room=room):
                return px, py

        for px, py in candidates:
            if self.is_walkable_point(px, py, SPAWN_RADIUS, room=room):
                return px, py

        for px, py in self._emergency_spawn_candidates(room):
            if self.is_walkable_point(px, py, SPAWN_RADIUS, room=room):
                return px, py

        return room.player_spawn

    def _emergency_spawn_candidates(self, room: GateRoom) -> list[tuple[float, float]]:
        bounds = room.room_bounds
        fallback_points = [
            (bounds.right - 140, bounds.centery),
            (bounds.centerx + 120, bounds.centery),
            (bounds.centerx, bounds.centery - 110),
            (bounds.centerx, bounds.centery + 110),
            (bounds.centerx, bounds.centery),
        ]
        return fallback_points

    def _scale_enemy_if_ready(self, enemy: Combatant) -> None:
        if self.player_power is not None:
            self.balance.scale_enemy(enemy, self.player_power)

    def current_room_bounds(self) -> pygame.Rect:
        return self.current_room().room_bounds

    def current_room_walls(self) -> list[pygame.Rect]:
        return list(self.current_room().wall_rects)

    def _circle_hits_rect(self, x: float, y: float, radius: float, rect: pygame.Rect) -> bool:
        closest_x = self._clamp(x, rect.left, rect.right)
        closest_y = self._clamp(y, rect.top, rect.bottom)
        dx = x - closest_x
        dy = y - closest_y
        return dx * dx + dy * dy < radius * radius

    def is_walkable_point(self, x: float, y: float, radius: float, room: GateRoom | None = None) -> bool:
        room = room or self.current_room()
        bounds = room.room_bounds
        if x - radius < bounds.left or x + radius > bounds.right or y - radius < bounds.top or y + radius > bounds.bottom:
            return False
        return not any(self._circle_hits_rect(x, y, radius, wall) for wall in room.wall_rects)

    def resolve_entity_position(self, entity: Combatant, prev_x: float, prev_y: float) -> None:
        room = self.current_room()
        bounds = room.room_bounds
        radius = float(getattr(entity, "radius", 0.0))

        target_x = self._clamp(float(entity.x), bounds.left + radius, bounds.right - radius)
        target_y = self._clamp(float(entity.y), bounds.top + radius, bounds.bottom - radius)

        entity.x = target_x
        entity.y = target_y

        wall_hits = [wall for wall in room.wall_rects if self._circle_hits_rect(entity.x, entity.y, radius, wall)]
        if wall_hits:
            for wall in wall_hits:
                closest_x = self._clamp(entity.x, wall.left, wall.right)
                closest_y = self._clamp(entity.y, wall.top, wall.bottom)
                dx = entity.x - closest_x
                dy = entity.y - closest_y
                if dx == 0 and dy == 0:
                    dx = entity.x - (wall.left + wall.width / 2.0)
                    dy = entity.y - (wall.top + wall.height / 2.0)
                length = math.hypot(dx, dy)
                if length == 0:
                    dx, dy = 1.0, 0.0
                    length = 1.0
                entity.x += dx / length * (radius + 2.0)
                entity.y += dy / length * (radius + 2.0)

            if hasattr(entity, "vx"):
                entity.vx *= 0.15
            if hasattr(entity, "vy"):
                entity.vy *= 0.15

        entity.x = self._clamp(float(entity.x), bounds.left + radius, bounds.right - radius)
        entity.y = self._clamp(float(entity.y), bounds.top + radius, bounds.bottom - radius)

        if any(self._circle_hits_rect(entity.x, entity.y, radius, wall) for wall in room.wall_rects):
            entity.x = prev_x
            entity.y = prev_y

    def current_room(self) -> GateRoom:
        return self.rooms[self.current_room_index]

    def can_advance(self) -> bool:
        return self.current_room().is_cleared()

    def advance_room(self) -> bool:
        if not self.can_advance():
            return False

        if self.current_room_index >= len(self.rooms) - 1:
            self.finished = True
            return False

        self.current_room_index += 1
        return True

    def update(self, player: Targetable) -> None:
        room = self.current_room()

        if room.room_type == "normal":
            self._coordinate_room(room, player)
            for mob in room.mobs:
                if mob.alive:
                    mob.set_target(player)
            room.cleared = room.is_cleared()

        elif room.room_type == "boss":
            if room.boss is not None and room.boss.alive:
                room.boss.set_target(player)
                summon_requests = getattr(room.boss, "consume_summon_requests", lambda: [])()
                for request in summon_requests:
                    self._spawn_boss_summons(room, request)
            self._coordinate_room(room, player)
            for mob in room.mobs:
                if mob.alive:
                    mob.set_target(player)
            room.cleared = room.is_cleared()
            if room.cleared:
                self.finished = True

        else:
            room.cleared = True

    def get_active_enemies(self) -> list[Combatant]:
        room = self.current_room()

        if room.room_type == "normal":
            return [mob for mob in room.mobs if mob.alive]

        if room.room_type == "boss":
            enemies = [mob for mob in room.mobs if mob.alive]
            if room.boss is not None and room.boss.alive:
                enemies.insert(0, room.boss)
            return enemies

        return []

    def _spawn_boss_summons(self, room: GateRoom, request: SummonRequest | dict[str, Any]) -> None:
        variants = request.get("variants")
        if isinstance(variants, list) and variants:
            variant_pool = [str(v) for v in variants]
        else:
            variant_pool = [str(request.get("variant", "charger"))]
        count = max(1, int(request.get("count", 1)))
        elite_chance = max(0.0, min(1.0, float(request.get("elite_chance", 0.0))))
        used_positions = [(mob.x, mob.y) for mob in room.mobs if getattr(mob, "alive", False)]
        if room.boss is not None:
            used_positions.append((room.boss.x, room.boss.y))
        for i in range(count):
            variant = self.rng.choice(variant_pool)
            spawn_x, spawn_y = self._sample_enemy_spawn(room, used_positions)
            summon = create_variant_enemy(
                variant,
                spawn_x,
                spawn_y,
                rank=self.rank,
                name=f"Summon_{room.room_id}_{len(room.mobs) + i}",
                elite=self.rng.random() < elite_chance,
                )
            self._scale_enemy_if_ready(summon)
            room.mobs.append(summon)
            used_positions.append((spawn_x, spawn_y))

    def _coordinate_room(self, room: GateRoom, player: Targetable) -> None:
        active_mobs = [mob for mob in room.mobs if getattr(mob, "alive", False)]
        if not active_mobs:
            return

        ordered = sorted(active_mobs, key=lambda mob: mob.distance_to(player))
        pressure_scale = 1.0 + min(0.22, len(active_mobs) * 0.03)

        roles: list[str] = []
        for index, mob in enumerate(ordered):
            variant = getattr(mob, "variant", "mob")
            archetype = getattr(mob, "archetype", "raider")
            if index == 0:
                role = "intercept" if variant in {"charger", "wisp"} or archetype == "stalker" else "pressure"
            elif variant == "gunner":
                role = "anchor"
            elif variant == "wisp":
                role = "flank"
            elif variant == "charger":
                role = "intercept"
            elif index % 3 == 0:
                role = "flank"
            else:
                role = "pressure"
            roles.append(role)

        flankers = [mob for mob, role in zip(ordered, roles) if role == "flank"]
        for flank_index, mob in enumerate(flankers):
            side = -1 if flank_index % 2 == 0 else 1
            anchor_x = player.x + side * (110 + flank_index * 26)
            anchor_y = player.y + (-40 if flank_index % 2 == 0 else 40)
            mob.set_coordination("flank", anchor_x=anchor_x, anchor_y=anchor_y, pressure_scale=pressure_scale)

        for mob, role in zip(ordered, roles):
            if role == "flank":
                continue
            if role == "anchor":
                anchor_x = player.x + 135
                anchor_y = player.y - 10
            elif role == "intercept":
                anchor_x = player.x
                anchor_y = player.y
            else:
                anchor_x = player.x + self.rng.randint(-28, 28)
                anchor_y = player.y + self.rng.randint(-28, 28)
            mob.set_coordination(role, anchor_x=anchor_x, anchor_y=anchor_y, pressure_scale=pressure_scale)

    def get_debug_state(self) -> dict:
        room = self.current_room()
        return {
            "seed": self.seed,
            "rank": self.rank,
            "rank_index": rank_index(self.rank),
            "display_name": self.display_name,
            "theme_name": self.theme_name,
            "current_room_index": self.current_room_index,
            "room_type": room.room_type,
            "room_cleared": room.cleared,
            "finished": self.finished,
            "failed": self.failed,
            "total_rooms": len(self.rooms),
        }
