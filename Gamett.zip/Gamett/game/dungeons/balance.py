from __future__ import annotations


class DungeonBalance:
    def __init__(self):
        self.player_power = 0.0
        self.dungeon_multiplier = 1.0
        self.enemy_hp_factor = 1.0
        self.enemy_damage_factor = 1.0
        self.enemy_speed_factor = 1.0
        self.boss_hp_factor = 1.0
        self.boss_damage_factor = 1.0
        self.boss_speed_factor = 1.0

    def evaluate_player(self, player) -> float:
        hp_score = player.stats.max_hp / 20.0
        mana_score = player.stats.max_mana / 25.0
        stamina_score = player.stats.max_stamina / 25.0

        attack_score = player.stats.attack_power * 18.0
        defense_score = player.stats.defense * 12.0
        speed_score = player.stats.speed / 18.0

        self.player_power = (
            hp_score
            + mana_score
            + stamina_score
            + attack_score
            + defense_score
            + speed_score
        )

        return self.player_power

    def calculate_multiplier(self, rank: str) -> float:
        profiles = {
            "E": {"mult": 0.65, "enemy_hp": 0.92, "enemy_damage": 0.68, "enemy_speed": 0.94, "boss_hp": 0.94, "boss_damage": 0.78, "boss_speed": 0.96},
            "D": {"mult": 0.8, "enemy_hp": 0.98, "enemy_damage": 0.80, "enemy_speed": 0.97, "boss_hp": 1.02, "boss_damage": 0.88, "boss_speed": 0.99},
            "C": {"mult": 0.95, "enemy_hp": 1.04, "enemy_damage": 0.92, "enemy_speed": 1.00, "boss_hp": 1.10, "boss_damage": 0.98, "boss_speed": 1.02},
            "B": {"mult": 1.1, "enemy_hp": 1.10, "enemy_damage": 1.00, "enemy_speed": 1.03, "boss_hp": 1.20, "boss_damage": 1.06, "boss_speed": 1.05},
            "A": {"mult": 1.25, "enemy_hp": 1.18, "enemy_damage": 1.08, "enemy_speed": 1.06, "boss_hp": 1.34, "boss_damage": 1.14, "boss_speed": 1.08},
            "S": {"mult": 1.45, "enemy_hp": 1.28, "enemy_damage": 1.18, "enemy_speed": 1.10, "boss_hp": 1.52, "boss_damage": 1.24, "boss_speed": 1.12},
            "SS": {"mult": 1.75, "enemy_hp": 1.42, "enemy_damage": 1.30, "enemy_speed": 1.15, "boss_hp": 1.78, "boss_damage": 1.38, "boss_speed": 1.18},
            "SSS": {"mult": 2.05, "enemy_hp": 1.56, "enemy_damage": 1.42, "enemy_speed": 1.20, "boss_hp": 2.02, "boss_damage": 1.52, "boss_speed": 1.24},
            "EX": {"mult": 2.45, "enemy_hp": 1.74, "enemy_damage": 1.58, "enemy_speed": 1.28, "boss_hp": 2.34, "boss_damage": 1.72, "boss_speed": 1.32},
            "MONARCH": {"mult": 3.1, "enemy_hp": 2.02, "enemy_damage": 1.84, "enemy_speed": 1.38, "boss_hp": 2.86, "boss_damage": 2.04, "boss_speed": 1.42},
        }

        profile = profiles.get(rank, profiles["C"])
        self.dungeon_multiplier = profile["mult"]
        self.enemy_hp_factor = profile["enemy_hp"]
        self.enemy_damage_factor = profile["enemy_damage"]
        self.enemy_speed_factor = profile["enemy_speed"]
        self.boss_hp_factor = profile["boss_hp"]
        self.boss_damage_factor = profile["boss_damage"]
        self.boss_speed_factor = profile["boss_speed"]
        return self.dungeon_multiplier

    def scale_enemy(self, enemy, player_power: float) -> None:
        scale = min(1.35, (player_power / 100.0) * self.dungeon_multiplier)
        hp_mult = self.enemy_hp_factor * (1.0 + scale * 0.55)
        speed_mult = self.enemy_speed_factor * (1.0 + scale * 0.08)

        enemy.stats.max_hp *= hp_mult
        enemy.stats.hp = enemy.stats.max_hp

        enemy.stats.attack_power *= self.enemy_damage_factor * (1.0 + scale * 0.18)

        if hasattr(enemy, "damage"):
            enemy.damage *= self.enemy_damage_factor
        if hasattr(enemy, "base_speed"):
            enemy.base_speed *= speed_mult
            enemy.stats.speed = enemy.base_speed
        else:
            enemy.stats.speed *= speed_mult
        if hasattr(enemy, "charge_speed"):
            enemy.charge_speed *= speed_mult
        if hasattr(enemy, "preferred_range"):
            enemy.preferred_range *= 1.0 + scale * 0.03

    def scale_boss(self, boss, player_power: float) -> None:
        scale = min(1.85, (player_power / 100.0) * (self.dungeon_multiplier * 1.15))
        hp_mult = self.boss_hp_factor * (1.0 + scale * 0.85)
        speed_mult = self.boss_speed_factor * (1.0 + scale * 0.10)

        boss.stats.max_hp *= hp_mult
        boss.stats.hp = boss.stats.max_hp

        boss.stats.attack_power *= self.boss_damage_factor * (1.0 + scale * 0.28)

        if hasattr(boss, "damage"):
            boss.damage *= self.boss_damage_factor
        if hasattr(boss, "base_damage"):
            boss.base_damage *= self.boss_damage_factor
        if hasattr(boss, "base_speed"):
            boss.base_speed *= speed_mult
            boss.stats.speed = boss.base_speed
        else:
            boss.stats.speed *= speed_mult
        if hasattr(boss, "attack_range"):
            boss.attack_range *= 1.0 + scale * 0.05
        if hasattr(boss, "base_attack_range"):
            boss.base_attack_range *= 1.0 + scale * 0.05
        if hasattr(boss, "base_attack_cooldown"):
            boss.base_attack_cooldown *= max(0.82, 1.0 - scale * 0.04)
