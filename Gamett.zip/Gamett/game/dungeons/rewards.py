from __future__ import annotations

from typing import Final

from game.dungeons.types import GateRewards, normalize_rank


DEFAULT_REWARDS: Final[GateRewards] = {
    "gold": 50,
    "potions": 1,
    "mana": 0,
    "stamina": 0,
    "mastery_xp": 10,
}

BASE_REWARD_MAP: Final[dict[str, GateRewards]] = {
    "E": {"gold": 30, "potions": 1, "mana": 0, "stamina": 0, "mastery_xp": 10},
    "D": {"gold": 45, "potions": 1, "mana": 0, "stamina": 0, "mastery_xp": 12},
    "C": {"gold": 60, "potions": 1, "mana": 1, "stamina": 0, "mastery_xp": 15},
    "B": {"gold": 90, "potions": 2, "mana": 1, "stamina": 1, "mastery_xp": 18},
    "A": {"gold": 125, "potions": 2, "mana": 1, "stamina": 1, "mastery_xp": 22},
    "S": {"gold": 180, "potions": 3, "mana": 2, "stamina": 1, "mastery_xp": 28},
    "SS": {"gold": 260, "potions": 3, "mana": 2, "stamina": 2, "mastery_xp": 36},
    "SSS": {"gold": 360, "potions": 4, "mana": 2, "stamina": 2, "mastery_xp": 46},
    "EX": {"gold": 500, "potions": 4, "mana": 3, "stamina": 2, "mastery_xp": 58},
    "MONARCH": {"gold": 750, "potions": 5, "mana": 3, "stamina": 3, "mastery_xp": 72},
}
def gate_clear_rewards(
    rank: str,
    rooms_cleared: int = 0,
    kills: int = 0,
    flawless: bool = False,
    mastery_level: int = 1,
) -> GateRewards:
    rank = normalize_rank(rank)
    rooms_cleared = max(0, int(rooms_cleared))
    kills = max(0, int(kills))
    mastery_level = max(1, int(mastery_level))

    rewards: GateRewards = dict(BASE_REWARD_MAP.get(rank, DEFAULT_REWARDS))
    rewards["gold"] += rooms_cleared * 8 + kills * 3
    rewards["mastery_xp"] += rooms_cleared * 2 + kills // 3
    if flawless:
        rewards["gold"] += 35 + rooms_cleared * 3
        rewards["mastery_xp"] += 12
        rewards["potions"] += 1
    if mastery_level >= 5:
        rewards["gold"] += mastery_level * 2
    return rewards
