# game/config.py

# -------------------------------------------------
# WINDOW / GAME
# -------------------------------------------------
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
GAME_TITLE = "Shadowfall: Gate Hunter"

# -------------------------------------------------
# WORLD
# -------------------------------------------------
WORLD_WIDTH = 4000
WORLD_HEIGHT = 2400

# -------------------------------------------------
# COLORS
# -------------------------------------------------
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (220, 70, 70)
GREEN = (70, 220, 120)
BLUE = (80, 140, 255)
YELLOW = (240, 220, 90)
PURPLE = (170, 90, 255)
CYAN = (90, 220, 255)
GRAY = (130, 130, 130)
DARK_GRAY = (35, 35, 35)
ORANGE = (255, 150, 70)

# -------------------------------------------------
# PLAYER DEFAULTS
# -------------------------------------------------
PLAYER_RADIUS = 18
PLAYER_BASE_SPEED = 260

PLAYER_MAX_HP = 100
PLAYER_MAX_MANA = 100
PLAYER_MAX_STAMINA = 100

PLAYER_BASIC_DAMAGE = 12
PLAYER_BASIC_RANGE = 70
PLAYER_BASIC_COOLDOWN = 0.35

PLAYER_DASH_SPEED = 700
PLAYER_DASH_DURATION = 0.14
PLAYER_DASH_COOLDOWN = 0.90
PLAYER_DASH_STAMINA_COST = 20

PLAYER_SKILL1_DAMAGE = 28
PLAYER_SKILL1_RANGE = 420
PLAYER_SKILL1_COOLDOWN = 4.0
PLAYER_SKILL1_MANA_COST = 20
PLAYER_SKILL1_PROJECTILE_SPEED = 680
PLAYER_SKILL1_PROJECTILE_RADIUS = 8

PLAYER_ULT_DAMAGE = 65
PLAYER_ULT_RANGE = 180
PLAYER_ULT_COOLDOWN = 12.0
PLAYER_ULT_MANA_COST = 45

HEALING_POTION_HEAL = 45
STARTING_HEALING_POTIONS = 2
MANA_POTION_RESTORE = 35
STAMINA_TONIC_RESTORE = 40

STRIKER_SKILL_DAMAGE = 34
STRIKER_SKILL_RANGE = 95
STRIKER_SKILL_COOLDOWN = 5.0
STRIKER_SKILL_STAMINA_COST = 22

RANGER_SKILL_DAMAGE = 18
RANGER_SKILL_COOLDOWN = 5.5
RANGER_SKILL_MANA_COST = 18
RANGER_SKILL_PROJECTILE_SPEED = 760
RANGER_SKILL_PROJECTILE_RANGE = 460
RANGER_SKILL_PROJECTILE_RADIUS = 7

AWAKENED_SKILL_DAMAGE = 42
AWAKENED_SKILL_RANGE = 120
AWAKENED_SKILL_COOLDOWN = 8.0
AWAKENED_SKILL_MANA_COST = 28

# -------------------------------------------------
# BASIC ENEMY DEFAULTS
# -------------------------------------------------
ENEMY_RADIUS = 16
ENEMY_BASE_SPEED = 145
ENEMY_MAX_HP = 55
ENEMY_DAMAGE = 8
ENEMY_ATTACK_RANGE = 42
ENEMY_ATTACK_COOLDOWN = 0.80

# -------------------------------------------------
# BOSS DEFAULTS
# -------------------------------------------------
BOSS_RADIUS = 30
BOSS_BASE_SPEED = 175
BOSS_MAX_HP = 600
BOSS_DAMAGE = 18
BOSS_ATTACK_RANGE = 70
BOSS_ATTACK_COOLDOWN = 1.0

# -------------------------------------------------
# SS BOSS DEFAULTS
# -------------------------------------------------
SS_BOSS_RADIUS = 34
SS_BOSS_BASE_SPEED = 210
SS_BOSS_MAX_HP = 1200
SS_BOSS_DAMAGE = 28
SS_BOSS_ATTACK_RANGE = 95
SS_BOSS_ATTACK_COOLDOWN = 0.75

# -------------------------------------------------
# LEARNING / ADAPTATION
# -------------------------------------------------
BASIC_MOB_LEARNING_RATE = 0.002
BOSS_LEARNING_RATE = 0.025
SS_BOSS_LEARNING_RATE = 0.080

# -------------------------------------------------
# DUNGEON / GATE
# -------------------------------------------------
MIN_ROOMS_BEFORE_BOSS = 4
MAX_ROOMS_BEFORE_BOSS = 8
MAX_BASIC_ENEMIES_PER_ROOM = 5
MIN_BASIC_ENEMIES_PER_ROOM = 2

GATE_RANK_ORDER = ["E", "D", "C", "B", "A", "S", "SS", "SSS", "EX", "MONARCH"]

# -------------------------------------------------
# DEBUG
# -------------------------------------------------
DRAW_HITBOXES = True
DRAW_DEBUG_TEXT = True
