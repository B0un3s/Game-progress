from __future__ import annotations

from collections import Counter, deque


class PatternReader:
    def __init__(self, history_size: int = 50):
        self.history = deque(maxlen=history_size)

    def observe(self, action: str) -> None:
        self.history.append(str(action))

    def dominant_pattern(self) -> str:
        if not self.history:
            return "unknown"

        return Counter(self.history).most_common(1)[0][0]

    def recent(self, count: int = 5) -> list[str]:
        return list(self.history)[-count:]

    def predict_next(self) -> str:
        if len(self.history) < 3:
            return self.dominant_pattern()

        actions = list(self.history)

        transitions = {}

        for i in range(len(actions) - 2):
            current = (actions[i], actions[i + 1])
            nxt = actions[i + 2]

            transitions.setdefault(current, []).append(nxt)

        last_pair = (actions[-2], actions[-1])

        if last_pair not in transitions:
            return self.dominant_pattern()

        return Counter(
            transitions[last_pair]
        ).most_common(1)[0][0]

    def aggression_score(self) -> float:
        if not self.history:
            return 0.0

        aggressive_actions = {
            "basic_attack",
            "skill",
            "ult",
            "heavy_attack",
        }

        aggressive_count = sum(
            1
            for action in self.history
            if action in aggressive_actions
        )

        return aggressive_count / len(self.history)

    def mobility_score(self) -> float:
        if not self.history:
            return 0.0

        mobility_actions = {
            "dash_left",
            "dash_right",
            "dash_back",
            "dash_forward",
        }

        mobility_count = sum(
            1
            for action in self.history
            if action in mobility_actions
        )

        return mobility_count / len(self.history)

    def player_profile(self) -> dict:
        return {
            "dominant_action": self.dominant_pattern(),
            "predicted_next": self.predict_next(),
            "aggression": round(self.aggression_score(), 2),
            "mobility": round(self.mobility_score(), 2),
            "recent": self.recent(),
        }