from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import random


@dataclass
class Decision:
    action: str
    reason: str = ""
    priority: float = 1.0
    target_x: float | None = None
    target_y: float | None = None
    metadata: dict[str, Any] | None = None


class SimpleBrain:
    def __init__(self) -> None:
        self.last_action = "idle"
        self.repetition_penalty = 0
        self.courage = random.uniform(0.45, 0.75)
        self.focus = 0.0
        self.rage = 0.0

    def choose(
        self,
        aggressive: bool = True,
        *,
        hp_ratio: float = 1.0,
        distance: float = 9999.0,
        attack_range: float = 48.0,
        cooldown_ready: bool = True,
        target_alive: bool = True,
        ally_count: int = 0,
        surrounded: bool = False,
        stuck: bool = False,
        behavior_mode: str = "pressure",
        pack_role: str = "pressure",
        player_aggressive: bool = False,
        player_mobile: bool = False,
    ) -> Decision:
        if not target_alive:
            return self._remember("idle", "no living target", 0.1)

        if stuck:
            return self._remember("unstuck", "mob appears stuck, forcing escape movement", 1.5)

        self._update_emotion(hp_ratio, aggressive, player_aggressive)

        if hp_ratio <= 0.18 and self.courage < 0.38 and behavior_mode != "rushdown":
            return self._remember("retreat", "low hp and courage broke", 1.4)

        if surrounded and hp_ratio < 0.45:
            return self._remember("escape", "surrounded while injured", 1.3)

        if cooldown_ready and distance <= attack_range:
            if behavior_mode == "bait" and player_aggressive and random.random() < 0.45:
                return self._remember("bait_backstep", "baiting aggressive player before hit", 1.2)

            if behavior_mode == "cutoff" and player_mobile:
                return self._remember("intercept_attack", "punishing mobile target", 1.35)

            if self.rage > 0.75:
                return self._remember("heavy_attack", "rage high enough for committed attack", 1.3)

            return self._remember("attack", "target inside attack range", 1.0)

        if distance <= attack_range and not cooldown_ready:
            if pack_role in {"flank", "intercept"}:
                return self._remember("circle", "waiting for cooldown while keeping angle", 1.0)

            return self._remember("reposition", "cooldown unavailable in melee range", 0.9)

        if behavior_mode == "rushdown" or aggressive:
            if pack_role == "flank":
                return self._remember("flank", "closing from side angle", 1.1)

            if pack_role == "intercept":
                return self._remember("intercept", "cutting off predicted movement", 1.2)

            return self._remember("chase", "aggressive chase decision", 1.0)

        if behavior_mode == "trap":
            return self._remember("circle", "creating trap pressure", 1.0)

        if behavior_mode == "bait":
            return self._remember("hold_range", "safe brain maintaining distance", 0.9)

        if ally_count >= 2:
            return self._remember("group_pressure", "allies nearby, push together", 1.05)

        return self._remember("reposition", "default safe brain", 0.75)

    def _update_emotion(self, hp_ratio: float, aggressive: bool, player_aggressive: bool) -> None:
        self.focus = min(1.0, self.focus + 0.015)

        if aggressive:
            self.rage = min(1.0, self.rage + 0.01)

        if player_aggressive:
            self.rage = min(1.0, self.rage + 0.02)

        if hp_ratio < 0.35:
            self.courage = max(0.0, self.courage - 0.015)
        else:
            self.courage = min(1.0, self.courage + 0.004)

    def _remember(
        self,
        action: str,
        reason: str,
        priority: float = 1.0,
        *,
        target_x: float | None = None,
        target_y: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Decision:
        if action == self.last_action:
            self.repetition_penalty += 1
        else:
            self.repetition_penalty = 0

        self.last_action = action

        adjusted_priority = max(0.1, priority - self.repetition_penalty * 0.05)

        return Decision(
            action=action,
            reason=reason,
            priority=adjusted_priority,
            target_x=target_x,
            target_y=target_y,
            metadata=metadata or {},
        )