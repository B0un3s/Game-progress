# game/ai/global_learning.py

from __future__ import annotations

import json
import os
import time
from copy import deepcopy
from typing import Any


DEFAULT_MEMORY = {
    "total_observations": 0,
    "basic_attack_uses": 0,
    "skill_1_uses": 0,
    "ult_uses": 0,
    "dash_uses": 0,
    "close_range_time": 0.0,
    "mid_range_time": 0.0,
    "long_range_time": 0.0,
    "preferred_dodge_left": 0.0,
    "preferred_dodge_right": 0.0,
    "preferred_dodge_back": 0.0,
    "preferred_dodge_forward": 0.0,
    "aggression_score": 0.0,
    "burst_score": 0.0,
    "mobility_score": 0.0,
    "punish_window_score": 0.0,
    "anti_range_score": 0.0,
    "anti_burst_score": 0.0,
}

DEFAULT_ENTITY_STATS = {
    "kills": 0,
    "deaths": 0,
    "encounters": 0,
    "wins": 0,
    "losses": 0,
    "damage_dealt": 0.0,
    "damage_taken": 0.0,
    "time_alive": 0.0,
    "last_seen": 0.0,
    "created_at": 0.0,
    "memory": deepcopy(DEFAULT_MEMORY),
}

DB_VERSION = 2


class GlobalLearningDB:
    _shared_data_by_path: dict[str, dict] = {}
    _loaded_paths: set[str] = set()

    def __init__(self, save_path: str = "game/data/global_learning.json"):
        self.save_path = save_path
        self.data = self._shared_data_by_path.setdefault(self.save_path, {})
        self.load()

    def load(self) -> None:
        if self.save_path in self._loaded_paths:
            self._migrate()
            return

        self._loaded_paths.add(self.save_path)

        if not os.path.exists(self.save_path):
            self.data.clear()
            self._init_database()
            return

        try:
            with open(self.save_path, "r", encoding="utf-8") as f:
                loaded = json.load(f)

            if isinstance(loaded, dict):
                self.data.clear()
                self.data.update(loaded)
            else:
                self.data.clear()

        except Exception:
            self.data.clear()

        self._migrate()

    def save(self) -> None:
        directory = os.path.dirname(self.save_path)

        if directory:
            os.makedirs(directory, exist_ok=True)

        tmp_path = f"{self.save_path}.tmp"

        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, sort_keys=True)

        os.replace(tmp_path, self.save_path)

    def _init_database(self) -> None:
        self.data["__meta__"] = {
            "version": DB_VERSION,
            "created_at": time.time(),
            "updated_at": time.time(),
        }

        self.data["__player_profile__"] = {
            "memory": deepcopy(DEFAULT_MEMORY),
            "created_at": time.time(),
            "updated_at": time.time(),
        }

    def _migrate(self) -> None:
        if "__meta__" not in self.data:
            self.data["__meta__"] = {
                "version": 1,
                "created_at": time.time(),
                "updated_at": time.time(),
            }

        self.data["__meta__"]["version"] = DB_VERSION
        self.data["__meta__"]["updated_at"] = time.time()

        self.ensure_player_profile()

        for key in list(self.data.keys()):
            if key.startswith("__"):
                continue

            self._normalize_entity(key)

    def _normalize_memory(self, memory: dict | None) -> dict:
        normalized = deepcopy(DEFAULT_MEMORY)

        if not isinstance(memory, dict):
            return normalized

        for key, default_value in DEFAULT_MEMORY.items():
            incoming = memory.get(key, default_value)

            try:
                if isinstance(default_value, int):
                    normalized[key] = max(0, int(incoming))
                else:
                    normalized[key] = max(0.0, float(incoming))
            except (TypeError, ValueError):
                normalized[key] = deepcopy(default_value)

        return normalized

    def _normalize_entity(self, entity_id: str) -> None:
        now = time.time()
        current = self.data.get(entity_id)

        if not isinstance(current, dict):
            self.data[entity_id] = deepcopy(DEFAULT_ENTITY_STATS)
            self.data[entity_id]["created_at"] = now
            self.data[entity_id]["last_seen"] = now
            return

        for key, default_value in DEFAULT_ENTITY_STATS.items():
            if key == "memory":
                current["memory"] = self._normalize_memory(current.get("memory"))
                continue

            if key not in current:
                current[key] = deepcopy(default_value)

        if not current.get("created_at"):
            current["created_at"] = now

        current["last_seen"] = now

    def ensure_player_profile(self) -> None:
        if "__player_profile__" not in self.data:
            self.data["__player_profile__"] = {
                "memory": deepcopy(DEFAULT_MEMORY),
                "created_at": time.time(),
                "updated_at": time.time(),
            }

        profile = self.data["__player_profile__"]
        profile["memory"] = self._normalize_memory(profile.get("memory"))
        profile["updated_at"] = time.time()

    def get_player_profile_memory(self) -> dict:
        self.ensure_player_profile()
        return deepcopy(self.data["__player_profile__"]["memory"])

    def set_player_profile_memory(self, memory: dict) -> None:
        self.ensure_player_profile()
        self.data["__player_profile__"]["memory"] = self._normalize_memory(memory)
        self.data["__player_profile__"]["updated_at"] = time.time()

    def merge_player_profile_memory(self, run_memory: dict, weight: float = 1.0) -> None:
        self.ensure_player_profile()

        stored = self.data["__player_profile__"]["memory"]
        incoming = self._normalize_memory(run_memory)

        for key, default_value in DEFAULT_MEMORY.items():
            if isinstance(default_value, int):
                stored[key] += int(incoming[key] * weight)
            else:
                stored[key] += float(incoming[key]) * weight

        self.data["__player_profile__"]["updated_at"] = time.time()

    def reset_player_profile(self) -> None:
        self.data["__player_profile__"] = {
            "memory": deepcopy(DEFAULT_MEMORY),
            "created_at": time.time(),
            "updated_at": time.time(),
        }

    def ensure_boss(self, boss_id: str) -> None:
        self.ensure_entity(boss_id)

    def ensure_entity(self, entity_id: str) -> None:
        if entity_id not in self.data:
            self.data[entity_id] = deepcopy(DEFAULT_ENTITY_STATS)
            self.data[entity_id]["created_at"] = time.time()

        self._normalize_entity(entity_id)

    def register_encounter(self, entity_id: str) -> None:
        self.ensure_entity(entity_id)
        self.data[entity_id]["encounters"] += 1
        self.data[entity_id]["last_seen"] = time.time()

    def register_kill(self, entity_id: str) -> None:
        self.ensure_entity(entity_id)
        self.data[entity_id]["kills"] += 1
        self.data[entity_id]["wins"] += 1
        self.data[entity_id]["last_seen"] = time.time()

    def register_death(self, entity_id: str) -> None:
        self.ensure_entity(entity_id)
        self.data[entity_id]["deaths"] += 1
        self.data[entity_id]["losses"] += 1
        self.data[entity_id]["last_seen"] = time.time()

    def record_damage_dealt(self, entity_id: str, amount: float) -> None:
        self.ensure_entity(entity_id)
        self.data[entity_id]["damage_dealt"] += max(0.0, float(amount))

    def record_damage_taken(self, entity_id: str, amount: float) -> None:
        self.ensure_entity(entity_id)
        self.data[entity_id]["damage_taken"] += max(0.0, float(amount))

    def record_time_alive(self, entity_id: str, seconds: float) -> None:
        self.ensure_entity(entity_id)
        self.data[entity_id]["time_alive"] += max(0.0, float(seconds))

    def get_boss_memory(self, boss_id: str) -> dict:
        return self.get_entity_memory(boss_id)

    def get_entity_memory(self, entity_id: str) -> dict:
        self.ensure_entity(entity_id)
        return deepcopy(self.data[entity_id]["memory"])

    def set_entity_memory(self, entity_id: str, memory: dict) -> None:
        self.ensure_entity(entity_id)
        self.data[entity_id]["memory"] = self._normalize_memory(memory)
        self.data[entity_id]["last_seen"] = time.time()

    def merge_memory(self, boss_id: str, run_memory: dict, weight: float = 1.0) -> None:
        self.merge_entity_memory(boss_id, run_memory, weight=weight)

    def merge_entity_memory(self, entity_id: str, run_memory: dict, weight: float = 1.0) -> None:
        self.ensure_entity(entity_id)

        stored = self.data[entity_id]["memory"]
        incoming = self._normalize_memory(run_memory)

        for key, default_value in DEFAULT_MEMORY.items():
            if isinstance(default_value, int):
                stored[key] += int(incoming[key] * weight)
            else:
                stored[key] += float(incoming[key]) * weight

        self.data[entity_id]["last_seen"] = time.time()

    def decay_entity_memory(self, entity_id: str, factor: float = 0.985) -> None:
        self.ensure_entity(entity_id)

        factor = max(0.0, min(1.0, float(factor)))
        memory = self.data[entity_id]["memory"]

        for key, default_value in DEFAULT_MEMORY.items():
            if key == "total_observations":
                continue

            if isinstance(default_value, int):
                memory[key] = int(memory[key] * factor)
            else:
                memory[key] = float(memory[key]) * factor

    def get_boss_stats(self, boss_id: str) -> dict:
        return self.get_entity_stats(boss_id)

    def get_entity_stats(self, entity_id: str) -> dict:
        self.ensure_entity(entity_id)
        return deepcopy(self.data[entity_id])

    def get_all_entity_ids(self) -> list[str]:
        return sorted(key for key in self.data.keys() if not key.startswith("__"))

    def get_summary(self) -> dict[str, Any]:
        entity_ids = self.get_all_entity_ids()

        total_encounters = 0
        total_kills = 0
        total_deaths = 0

        for entity_id in entity_ids:
            entity = self.data[entity_id]
            total_encounters += int(entity.get("encounters", 0))
            total_kills += int(entity.get("kills", 0))
            total_deaths += int(entity.get("deaths", 0))

        return {
            "version": self.data.get("__meta__", {}).get("version", DB_VERSION),
            "entities": len(entity_ids),
            "total_encounters": total_encounters,
            "total_kills": total_kills,
            "total_deaths": total_deaths,
        }

    def reset_boss(self, boss_id: str) -> None:
        self.reset_entity(boss_id)

    def reset_entity(self, entity_id: str) -> None:
        self.data[entity_id] = deepcopy(DEFAULT_ENTITY_STATS)
        self.data[entity_id]["created_at"] = time.time()
        self.data[entity_id]["last_seen"] = time.time()

    def reset_all_entities(self) -> None:
        for entity_id in self.get_all_entity_ids():
            self.reset_entity(entity_id)

    def reset_all(self) -> None:
        self.data.clear()
        self._init_database()

    def export_data(self) -> dict:
        return deepcopy(self.data)

    def import_data(self, data: dict) -> None:
        if not isinstance(data, dict):
            return

        self.data.clear()
        self.data.update(deepcopy(data))
        self._migrate()
