# game/ai/adaptation.py

from __future__ import annotations


class CombatMemory:
    def __init__(self, learning_rate: float = 0.01):
        self.learning_rate = float(learning_rate)

        self.total_observations = 0

        self.basic_attack_uses = 0
        self.skill_1_uses = 0
        self.ult_uses = 0
        self.dash_uses = 0

        self.close_range_time = 0.0
        self.mid_range_time = 0.0
        self.long_range_time = 0.0

        self.preferred_dodge_left = 0.0
        self.preferred_dodge_right = 0.0
        self.preferred_dodge_back = 0.0
        self.preferred_dodge_forward = 0.0

        self.aggression_score = 0.0
        self.burst_score = 0.0
        self.mobility_score = 0.0
        self.punish_window_score = 0.0
        self.anti_range_score = 0.0
        self.anti_burst_score = 0.0

    def observe_tick(self, distance_to_enemy: float, dt: float) -> None:
        self.total_observations += 1

        if distance_to_enemy < 80:
            self.close_range_time += dt * self.learning_rate
        elif distance_to_enemy < 180:
            self.mid_range_time += dt * self.learning_rate
        else:
            self.long_range_time += dt * self.learning_rate

    def record_basic_attack(self) -> None:
        self.basic_attack_uses += 1
        self.aggression_score += 1.0 * self.learning_rate
        self.punish_window_score += 0.25 * self.learning_rate

    def record_skill_1(self) -> None:
        self.skill_1_uses += 1
        self.burst_score += 1.5 * self.learning_rate
        self.aggression_score += 0.5 * self.learning_rate
        self.anti_range_score += 0.7 * self.learning_rate

    def record_ult(self) -> None:
        self.ult_uses += 1
        self.burst_score += 3.0 * self.learning_rate
        self.aggression_score += 1.0 * self.learning_rate
        self.anti_burst_score += 1.2 * self.learning_rate

    def record_dash(self, direction: str = "back") -> None:
        self.dash_uses += 1
        self.mobility_score += 1.0 * self.learning_rate
        self.punish_window_score += 0.45 * self.learning_rate

        if direction == "left":
            self.preferred_dodge_left += 1.0 * self.learning_rate
        elif direction == "right":
            self.preferred_dodge_right += 1.0 * self.learning_rate
        elif direction == "forward":
            self.preferred_dodge_forward += 1.0 * self.learning_rate
        else:
            self.preferred_dodge_back += 1.0 * self.learning_rate

    def dominant_range(self) -> str:
        values = {
            "close": self.close_range_time,
            "mid": self.mid_range_time,
            "long": self.long_range_time,
        }
        return max(values, key=values.get)

    def preferred_dodge_direction(self) -> str:
        values = {
            "left": self.preferred_dodge_left,
            "right": self.preferred_dodge_right,
            "back": self.preferred_dodge_back,
            "forward": self.preferred_dodge_forward,
        }
        return max(values, key=values.get)

    def aggression_level(self) -> str:
        if self.aggression_score >= 2.5:
            return "high"
        if self.aggression_score >= 1.0:
            return "medium"
        return "low"

    def burst_level(self) -> str:
        if self.burst_score >= 2.5:
            return "high"
        if self.burst_score >= 1.0:
            return "medium"
        return "low"

    def mobility_level(self) -> str:
        if self.mobility_score >= 2.5:
            return "high"
        if self.mobility_score >= 1.0:
            return "medium"
        return "low"

    def punish_level(self) -> str:
        if self.punish_window_score >= 2.0:
            return "high"
        if self.punish_window_score >= 0.9:
            return "medium"
        return "low"

    def range_denial_level(self) -> str:
        if self.anti_range_score >= 2.0:
            return "high"
        if self.anti_range_score >= 0.9:
            return "medium"
        return "low"

    def burst_denial_level(self) -> str:
        if self.anti_burst_score >= 2.0:
            return "high"
        if self.anti_burst_score >= 0.9:
            return "medium"
        return "low"

    def load_from_dict(self, memory: dict | None) -> None:
        if not isinstance(memory, dict):
            return
        for key, value in memory.items():
            if hasattr(self, key):
                setattr(self, key, type(getattr(self, key))(value))

    def merge_from_dict(self, memory: dict | None, scale: float = 1.0) -> None:
        if not isinstance(memory, dict):
            return
        scale = float(scale)
        for key, value in memory.items():
            if not hasattr(self, key):
                continue
            current = getattr(self, key)
            if isinstance(current, int):
                setattr(self, key, current + int(round(float(value) * scale)))
            else:
                setattr(self, key, current + float(value) * scale)

    def to_dict(self) -> dict:
        return {
            "total_observations": self.total_observations,
            "basic_attack_uses": self.basic_attack_uses,
            "skill_1_uses": self.skill_1_uses,
            "ult_uses": self.ult_uses,
            "dash_uses": self.dash_uses,
            "close_range_time": self.close_range_time,
            "mid_range_time": self.mid_range_time,
            "long_range_time": self.long_range_time,
            "preferred_dodge_left": self.preferred_dodge_left,
            "preferred_dodge_right": self.preferred_dodge_right,
            "preferred_dodge_back": self.preferred_dodge_back,
            "preferred_dodge_forward": self.preferred_dodge_forward,
            "aggression_score": self.aggression_score,
            "burst_score": self.burst_score,
            "mobility_score": self.mobility_score,
            "punish_window_score": self.punish_window_score,
            "anti_range_score": self.anti_range_score,
            "anti_burst_score": self.anti_burst_score,
        }

    @classmethod
    def blended_profile(
        cls,
        *memory_sources: tuple[dict | None, float],
        learning_rate: float = 0.01,
    ) -> dict:
        memory = cls(learning_rate=learning_rate)
        for source, scale in memory_sources:
            memory.merge_from_dict(source, scale=scale)
        return memory.get_profile()

    def get_profile(self) -> dict:
        return {
            "observations": self.total_observations,
            "basic_attack_uses": self.basic_attack_uses,
            "skill_1_uses": self.skill_1_uses,
            "ult_uses": self.ult_uses,
            "dash_uses": self.dash_uses,
            "dominant_range": self.dominant_range(),
            "preferred_dodge": self.preferred_dodge_direction(),
            "aggression": self.aggression_level(),
            "burst": self.burst_level(),
            "mobility": self.mobility_level(),
            "punish": self.punish_level(),
            "range_denial": self.range_denial_level(),
            "burst_denial": self.burst_denial_level(),
        }
