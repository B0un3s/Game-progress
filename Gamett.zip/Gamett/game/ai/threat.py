from __future__ import annotations


def estimate_threat(distance: float, damage: float, hp_ratio: float) -> float:
    distance_factor = 1.0 / max(1.0, distance)
    return max(0.0, damage * 0.6 + hp_ratio * 10.0 + distance_factor * 50.0)
