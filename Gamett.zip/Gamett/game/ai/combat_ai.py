# game/ai/combat_ai.py

from __future__ import annotations

import math
import random


class CombatAI:
    def __init__(self):
        self.last_player_x = None
        self.last_player_y = None

        self.player_move_dx = 0.0
        self.player_move_dy = 0.0

        self.smoothed_dx = 0.0
        self.smoothed_dy = 0.0

        self.last_side_bias = random.choice([-1.0, 1.0])
        self.side_swap_timer = 0.0

        self.stuck_timer = 0.0
        self.last_enemy_x = None
        self.last_enemy_y = None
        self.unstuck_angle = random.uniform(0.0, math.tau)

    def observe_player(self, player) -> None:
        if self.last_player_x is not None and self.last_player_y is not None:
            raw_dx = player.x - self.last_player_x
            raw_dy = player.y - self.last_player_y

            self.player_move_dx = raw_dx
            self.player_move_dy = raw_dy

            self.smoothed_dx = self.smoothed_dx * 0.72 + raw_dx * 0.28
            self.smoothed_dy = self.smoothed_dy * 0.72 + raw_dy * 0.28

        self.last_player_x = player.x
        self.last_player_y = player.y

    def observe_enemy(self, enemy, dt: float) -> None:
        if self.last_enemy_x is None or self.last_enemy_y is None:
            self.last_enemy_x = enemy.x
            self.last_enemy_y = enemy.y
            return

        moved = math.hypot(enemy.x - self.last_enemy_x, enemy.y - self.last_enemy_y)

        if moved < 1.0:
            self.stuck_timer += dt
        else:
            self.stuck_timer = max(0.0, self.stuck_timer - dt * 2.5)

        self.last_enemy_x = enemy.x
        self.last_enemy_y = enemy.y

        if self.stuck_timer > 0.45:
            self.unstuck_angle += random.uniform(0.8, 1.7)
            self.stuck_timer = 0.2

    def predict_player_position(self, player, lead_factor: float = 8.0) -> tuple[float, float]:
        px = player.x + self.smoothed_dx * lead_factor
        py = player.y + self.smoothed_dy * lead_factor
        return px, py

    def choose_behavior(self, enemy, player, memory_profile: dict | None = None) -> str:
        dist = enemy.distance_to(player)

        if memory_profile is None:
            memory_profile = {}

        dominant_range = memory_profile.get("dominant_range", "mid")
        mobility = memory_profile.get("mobility", "low")
        burst = memory_profile.get("burst", "low")
        punish = memory_profile.get("punish", "low")
        preferred_dodge = memory_profile.get("preferred_dodge", "back")
        aggression = memory_profile.get("aggression", "medium")

        hp_ratio = getattr(enemy.stats, "hp_ratio", 1.0)

        if self.stuck_timer > 0.12:
            return "unstuck"

        if hp_ratio < 0.22 and aggression != "high":
            return "retreat"

        if punish == "high" and preferred_dodge in ("left", "right"):
            return "cutoff"

        if burst == "high" and dist < enemy.attack_range * 1.45:
            return "kite"

        if dominant_range == "long":
            return "rush"

        if mobility == "high":
            return "trap"

        if dist <= enemy.attack_range:
            return "attack"

        return "chase"

    def apply_behavior(self, enemy, player, behavior: str) -> None:
        self.observe_enemy(enemy, 1 / 60)

        predicted_x, predicted_y = self.predict_player_position(player)

        if behavior == "unstuck":
            tx, ty = self._unstuck_target(enemy)
            enemy.move_toward(tx, ty, enemy.base_speed * 1.25)

        elif behavior == "rush":
            enemy.move_toward(predicted_x, predicted_y, enemy.base_speed * 1.16)

        elif behavior == "kite":
            enemy.move_away_from(player.x, player.y, enemy.base_speed * 0.96)

        elif behavior == "retreat":
            enemy.move_away_from(player.x, player.y, enemy.base_speed * 1.12)

        elif behavior == "trap":
            side_x, side_y = self._side_step_target(enemy, player)
            enemy.move_toward(side_x, side_y, enemy.base_speed * 1.02)

        elif behavior == "cutoff":
            cutoff_x, cutoff_y = self._cutoff_target(enemy, player)
            enemy.move_toward(cutoff_x, cutoff_y, enemy.base_speed * 1.1)

        elif behavior == "flank":
            flank_x, flank_y = self._flank_target(enemy, player)
            enemy.move_toward(flank_x, flank_y, enemy.base_speed * 1.08)

        elif behavior == "circle":
            circle_x, circle_y = self._circle_target(enemy, player)
            enemy.move_toward(circle_x, circle_y, enemy.base_speed * 0.92)

        elif behavior == "attack":
            enemy.stop()
            if hasattr(enemy, "try_attack_target"):
                enemy.try_attack_target()

        else:
            enemy.move_toward(predicted_x, predicted_y, enemy.base_speed)

    def _unstuck_target(self, enemy) -> tuple[float, float]:
        return (
            enemy.x + math.cos(self.unstuck_angle) * 140.0,
            enemy.y + math.sin(self.unstuck_angle) * 140.0,
        )

    def _side_step_target(self, enemy, player) -> tuple[float, float]:
        dx = player.x - enemy.x
        dy = player.y - enemy.y
        length = math.hypot(dx, dy)

        if length <= 0.001:
            return player.x, player.y

        dx /= length
        dy /= length

        if random.random() < 0.006:
            self.last_side_bias *= -1.0

        side_x = -dy * self.last_side_bias
        side_y = dx * self.last_side_bias

        return player.x + side_x * 90.0, player.y + side_y * 90.0

    def _cutoff_target(self, enemy, player) -> tuple[float, float]:
        predicted_x, predicted_y = self.predict_player_position(player, lead_factor=12.0)

        dx = predicted_x - enemy.x
        dy = predicted_y - enemy.y
        length = math.hypot(dx, dy)

        if length <= 0.001:
            return predicted_x, predicted_y

        dx /= length
        dy /= length

        side_x = -dy
        side_y = dx

        movement_dot = self.smoothed_dx * side_x + self.smoothed_dy * side_y

        if movement_dot < 0:
            self.last_side_bias = -1.0
        else:
            self.last_side_bias = 1.0

        return (
            predicted_x + side_x * 78.0 * self.last_side_bias,
            predicted_y + side_y * 78.0 * self.last_side_bias,
        )

    def _flank_target(self, enemy, player) -> tuple[float, float]:
        dx = enemy.x - player.x
        dy = enemy.y - player.y
        length = math.hypot(dx, dy)

        if length <= 0.001:
            return player.x, player.y

        dx /= length
        dy /= length

        side_x = -dy * self.last_side_bias
        side_y = dx * self.last_side_bias

        return (
            player.x + side_x * 120.0 - dx * 35.0,
            player.y + side_y * 120.0 - dy * 35.0,
        )

    def _circle_target(self, enemy, player) -> tuple[float, float]:
        dx = enemy.x - player.x
        dy = enemy.y - player.y
        length = math.hypot(dx, dy)

        if length <= 0.001:
            return player.x, player.y

        dx /= length
        dy /= length

        side_x = -dy * self.last_side_bias
        side_y = dx * self.last_side_bias

        return (
            enemy.x + side_x * 96.0,
            enemy.y + side_y * 96.0,
        )