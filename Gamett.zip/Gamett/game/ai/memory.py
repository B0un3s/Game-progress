from __future__ import annotations

from dataclasses import dataclass, field
from collections import Counter
import time


@dataclass
class MemoryState:
    observations: list[dict] = field(default_factory=list)

    max_observations: int = 300

    damage_taken: float = 0.0
    damage_dealt: float = 0.0
    kills: int = 0
    deaths: int = 0

    def remember(self, event: str, value: str = "", weight: float = 1.0) -> None:
        self.observations.append({
            "time": time.time(),
            "event": str(event),
            "value": str(value),
            "weight": float(weight),
        })

        if len(self.observations) > self.max_observations:
            self.observations.pop(0)

    def recent(self, limit: int = 5) -> list[dict]:
        return self.observations[-limit:]

    def count(self, event: str) -> int:
        return sum(1 for obs in self.observations if obs["event"] == event)

    def most_common_value(self, event: str, fallback: str = "unknown") -> str:
        values = [
            obs["value"]
            for obs in self.observations
            if obs["event"] == event and obs["value"]
        ]

        if not values:
            return fallback

        return Counter(values).most_common(1)[0][0]

    def record_damage_taken(self, amount: float) -> None:
        amount = max(0.0, float(amount))
        self.damage_taken += amount
        self.remember("damage_taken", str(round(amount, 2)), amount)

    def record_damage_dealt(self, amount: float) -> None:
        amount = max(0.0, float(amount))
        self.damage_dealt += amount
        self.remember("damage_dealt", str(round(amount, 2)), amount)

    def record_kill(self) -> None:
        self.kills += 1
        self.remember("kill")

    def record_death(self) -> None:
        self.deaths += 1
        self.remember("death")

    def profile(self) -> dict:
        favorite_dodge = self.most_common_value("player_dash")
        favorite_range = self.most_common_value("player_range", "mid")
        favorite_skill = self.most_common_value("player_skill")

        aggression = self.count("player_basic_attack") + self.count("player_skill")
        mobility = self.count("player_dash")
        burst = self.count("player_ult")

        threat_score = (
            aggression * 1.0
            + mobility * 0.65
            + burst * 3.0
            + self.damage_taken * 0.02
        )

        return {
            "favorite_dodge": favorite_dodge,
            "favorite_range": favorite_range,
            "favorite_skill": favorite_skill,
            "aggression": aggression,
            "mobility": mobility,
            "burst": burst,
            "threat_score": round(threat_score, 2),
            "damage_taken": round(self.damage_taken, 2),
            "damage_dealt": round(self.damage_dealt, 2),
            "kills": self.kills,
            "deaths": self.deaths,
            "recent": self.recent(5),
        }

    def clear(self) -> None:
        self.observations.clear()
        self.damage_taken = 0.0
        self.damage_dealt = 0.0
        self.kills = 0
        self.deaths = 0