from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass
class BehaviorPlan:
    action: str
    reason: str
    priority: float
    hp_ratio: float
    distance: float
    target_distance: float
    cooldown: float = 0.0


class BehaviorTree:
    """
    Better enemy behavior tree.

    Actions:
    - attack: enemy is in range and has an opening
    - heavy_attack: punish player when close and confident
    - advance: close distance
    - retreat: escape when weak or overwhelmed
    - dodge: avoid danger
    - flank: circle around player
    - kite: stay at range if ranged enemy
    - hold: wait and bait player
    - observe: fallback idle scan
    """

    def __init__(self, name: str = "tree"):
        self.name = name
        self.last_action = "observe"
        self.action_timer = 0.0
        self.memory = {
            "retreat_count": 0,
            "attack_count": 0,
            "dodge_count": 0,
            "last_hp_ratio": 1.0,
            "last_distance": 9999.0,
        }

    def tick(
        self,
        enemy=None,
        player=None,
        distance: float | None = None,
        context: dict | None = None,
        dt: float = 1 / 60,
    ) -> dict:
        context = context or {}

        if enemy is None:
            return self._result("observe", "No enemy context available.", 0.1, 1.0, 0.0, 0.0)

        self.action_timer = max(0.0, self.action_timer - dt)

        hp_ratio = self._hp_ratio(enemy)
        distance = float(distance if distance is not None else self._distance(enemy, player))

        attack_range = float(getattr(enemy, "attack_range", 45.0))
        detection_range = float(getattr(enemy, "detection_range", 420.0))
        base_speed = float(getattr(enemy, "base_speed", 140.0))

        enemy_type = str(context.get("type", getattr(enemy, "enemy_type", "melee"))).lower()
        is_ranged = enemy_type in {"ranged", "mage", "archer", "sniper", "caster"}

        player_attacking = bool(context.get("player_attacking", False))
        player_vulnerable = bool(context.get("player_vulnerable", False))
        outnumbering_player = bool(context.get("allies_nearby", 0) >= 1)
        recently_hit = bool(context.get("recently_hit", False))
        stamina_low = bool(context.get("stamina_low", False))
        can_attack = bool(context.get("can_attack", True))
        can_dodge = bool(context.get("can_dodge", True))

        ideal_distance = attack_range * (3.2 if is_ranged else 0.9)

        if distance > detection_range:
            return self._choose("observe", "Player is outside detection range.", hp_ratio, distance, ideal_distance)

        if self.action_timer > 0:
            return self._choose(
                self.last_action,
                "Continuing current action to avoid twitchy AI switching.",
                hp_ratio,
                distance,
                ideal_distance,
            )

        # emergency survival
        if hp_ratio <= 0.18:
            if can_dodge and distance <= attack_range * 1.4:
                return self._choose("dodge", "Critical HP and player is close.", hp_ratio, distance, ideal_distance, 0.45)
            return self._choose("retreat", "low health; enemy retreats to survive.", hp_ratio, distance, ideal_distance, 0.65)

        # reaction if hit
        if recently_hit:
            if can_dodge and random.random() < 0.65:
                return self._choose("dodge", "Enemy was hit and reacts defensively.", hp_ratio, distance, ideal_distance, 0.35)
            if hp_ratio < 0.45:
                return self._choose("retreat", "Enemy was hit while weak.", hp_ratio, distance, ideal_distance, 0.55)

        # ranged behavior
        if is_ranged:
            if distance < attack_range * 1.2 and can_dodge:
                return self._choose("kite", "Ranged enemy is too close and creates space.", hp_ratio, distance, ideal_distance, 0.45)

            if distance > ideal_distance * 1.25:
                return self._choose("advance", "Ranged enemy moves into effective range.", hp_ratio, distance, ideal_distance, 0.35)

            if can_attack and player_vulnerable:
                return self._choose("attack", "Player is vulnerable; ranged enemy fires.", hp_ratio, distance, ideal_distance, 0.5)

            if can_attack and random.random() < 0.55:
                return self._choose("attack", "Ranged enemy has line pressure.", hp_ratio, distance, ideal_distance, 0.55)

            return self._choose("flank", "Ranged enemy repositions for a cleaner angle.", hp_ratio, distance, ideal_distance, 0.45)

        # melee behavior
        if distance <= attack_range * 1.05:
            if player_attacking and can_dodge and random.random() < 0.55:
                return self._choose("dodge", "Player is attacking; enemy avoids trading badly.", hp_ratio, distance, ideal_distance, 0.35)

            if can_attack and player_vulnerable:
                return self._choose("pressure", "Player is vulnerable; enemy commits to pressure.", hp_ratio, distance, ideal_distance, 0.75)

            if can_attack:
                action = "pressure"
                reason = "Enemy is close and applying pressure."
                if hp_ratio > 0.65 and outnumbering_player:
                    reason = "Enemy is close and keeps the pressure on the player."
                return self._choose(action, reason, hp_ratio, distance, ideal_distance, 0.55)

            return self._choose("flank", "Enemy is close but attack is unavailable.", hp_ratio, distance, ideal_distance, 0.35)

        if distance <= attack_range * 1.8:
            if hp_ratio < 0.38 and not outnumbering_player:
                return self._choose("retreat", "Enemy is hurt and avoids close combat.", hp_ratio, distance, ideal_distance, 0.55)

            if base_speed >= 155 and random.random() < 0.45:
                return self._choose("flank", "Fast enemy circles before engaging.", hp_ratio, distance, ideal_distance, 0.4)

            return self._choose("advance", "Enemy is near melee range and closes carefully.", hp_ratio, distance, ideal_distance, 0.35)

        if stamina_low:
            return self._choose("hold", "Enemy conserves stamina before pushing.", hp_ratio, distance, ideal_distance, 0.45)

        return self._choose("advance", "Enemy closes the gap toward the player.", hp_ratio, distance, ideal_distance, 0.35)

    def _choose(
        self,
        action: str,
        reason: str,
        hp_ratio: float,
        distance: float,
        target_distance: float,
        cooldown: float = 0.25,
    ) -> dict:
        self.last_action = action
        self.action_timer = cooldown

        if action == "attack":
            self.memory["attack_count"] += 1
        elif action == "retreat":
            self.memory["retreat_count"] += 1
        elif action == "dodge":
            self.memory["dodge_count"] += 1

        self.memory["last_hp_ratio"] = hp_ratio
        self.memory["last_distance"] = distance

        return self._result(action, reason, 1.0, hp_ratio, distance, target_distance, cooldown)

    def _result(
        self,
        action: str,
        reason: str,
        priority: float,
        hp_ratio: float,
        distance: float,
        target_distance: float,
        cooldown: float = 0.0,
    ) -> dict:
        return {
            "action": action,
            "reason": reason,
            "priority": round(priority, 2),
            "hp_ratio": round(hp_ratio, 2),
            "distance": round(distance, 1),
            "target_distance": round(target_distance, 1),
            "cooldown": round(cooldown, 2),
        }

    def _hp_ratio(self, enemy) -> float:
        stats = getattr(enemy, "stats", None)

        current_hp = getattr(enemy, "hp", None)
        max_hp = getattr(enemy, "max_hp", None)

        if current_hp is None and stats is not None:
            current_hp = getattr(stats, "hp", None)

        if max_hp is None and stats is not None:
            max_hp = getattr(stats, "max_hp", None)

        if current_hp is None:
            current_hp = 1.0

        if max_hp is None or max_hp <= 0:
            max_hp = 1.0

        try:
            return max(0.0, min(1.0, float(current_hp) / float(max_hp)))
        except (TypeError, ValueError, ZeroDivisionError):
            return 1.0

    def _distance(self, enemy, player) -> float:
        if enemy is None or player is None:
            return 0.0

        ex = float(getattr(enemy, "x", 0.0))
        ey = float(getattr(enemy, "y", 0.0))
        px = float(getattr(player, "x", 0.0))
        py = float(getattr(player, "y", 0.0))

        return ((ex - px) ** 2 + (ey - py) ** 2) ** 0.5