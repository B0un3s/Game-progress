from __future__ import annotations

import math


def normalize_vector(dx: float, dy: float) -> tuple[float, float]:
    length = math.hypot(dx, dy)
    if length <= 0:
        return 0.0, 0.0
    return dx / length, dy / length


def scale_vector(dx: float, dy: float, magnitude: float) -> tuple[float, float]:
    nx, ny = normalize_vector(dx, dy)
    return nx * magnitude, ny * magnitude
