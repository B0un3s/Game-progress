# game/core/stats.py

from dataclasses import dataclass


def clamp(value: float, min_value: float, max_value: float) -> float:
    return max(min_value, min(value, max_value))


@dataclass
class Stats:
    max_hp: float
    max_mana: float = 0.0
    max_stamina: float = 0.0

    hp_regen: float = 0.0
    mana_regen: float = 0.0
    stamina_regen: float = 0.0

    attack_power: float = 1.0
    defense: float = 0.0
    speed: float = 0.0

    def __post_init__(self):
        self.hp = float(self.max_hp)
        self.mana = float(self.max_mana)
        self.stamina = float(self.max_stamina)

    @property
    def alive(self) -> bool:
        return self.hp > 0

    @property
    def hp_ratio(self) -> float:
        if self.max_hp <= 0:
            return 0.0
        return self.hp / self.max_hp

    @property
    def mana_ratio(self) -> float:
        if self.max_mana <= 0:
            return 0.0
        return self.mana / self.max_mana

    @property
    def stamina_ratio(self) -> float:
        if self.max_stamina <= 0:
            return 0.0
        return self.stamina / self.max_stamina

    def update(self, dt: float) -> None:
        if not self.alive:
            return

        if self.hp_regen > 0:
            self.hp = clamp(self.hp + self.hp_regen * dt, 0, self.max_hp)

        if self.max_mana > 0 and self.mana_regen > 0:
            self.mana = clamp(self.mana + self.mana_regen * dt, 0, self.max_mana)

        if self.max_stamina > 0 and self.stamina_regen > 0:
            self.stamina = clamp(self.stamina + self.stamina_regen * dt, 0, self.max_stamina)

    def take_damage(self, amount: float) -> float:
        if not self.alive:
            return 0.0

        raw = max(0.0, float(amount))
        final_damage = max(1.0, raw - self.defense) if raw > 0 else 0.0

        before = self.hp
        self.hp = clamp(self.hp - final_damage, 0, self.max_hp)
        return before - self.hp

    def heal(self, amount: float) -> float:
        if amount <= 0 or not self.alive:
            return 0.0

        before = self.hp
        self.hp = clamp(self.hp + amount, 0, self.max_hp)
        return self.hp - before

    def spend_mana(self, amount: float) -> bool:
        amount = float(amount)
        if amount <= 0:
            return True
        if self.mana < amount:
            return False
        self.mana -= amount
        return True

    def restore_mana(self, amount: float) -> float:
        if amount <= 0 or self.max_mana <= 0:
            return 0.0

        before = self.mana
        self.mana = clamp(self.mana + amount, 0, self.max_mana)
        return self.mana - before

    def spend_stamina(self, amount: float) -> bool:
        amount = float(amount)
        if amount <= 0:
            return True
        if self.stamina < amount:
            return False
        self.stamina -= amount
        return True

    def restore_stamina(self, amount: float) -> float:
        if amount <= 0 or self.max_stamina <= 0:
            return 0.0

        before = self.stamina
        self.stamina = clamp(self.stamina + amount, 0, self.max_stamina)
        return self.stamina - before

    def kill(self) -> None:
        self.hp = 0.0

    def revive_full(self) -> None:
        self.hp = float(self.max_hp)
        self.mana = float(self.max_mana)
        self.stamina = float(self.max_stamina)