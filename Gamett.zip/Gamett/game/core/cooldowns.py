# game/core/cooldowns.py

from __future__ import annotations


class Cooldowns:
    def __init__(self):
        self._timers: dict[str, float] = {}

    def update(self, dt: float) -> None:
        expired = []

        for key, value in list(self._timers.items()):
            value -= float(dt)

            if value <= 0:
                expired.append(key)
            else:
                self._timers[key] = value

        for key in expired:
            del self._timers[key]

    def set(self, name: str, duration: float) -> None:
        self._timers[name] = max(0.0, float(duration))

    def trigger(self, name: str, duration: float) -> None:
        self.set(name, duration)

    def ready(self, name: str) -> bool:
        return self.remaining(name) <= 0.0

    def remaining(self, name: str) -> float:
        return max(0.0, float(self._timers.get(name, 0.0)))

    def active(self, name: str) -> bool:
        return self.remaining(name) > 0.0

    def clear(self, name: str) -> None:
        if name in self._timers:
            del self._timers[name]

    def clear_all(self) -> None:
        self._timers.clear()

    def get_all(self) -> dict[str, float]:
        return dict(self._timers)