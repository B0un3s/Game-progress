# game/core/entity.py

from __future__ import annotations

import math
from typing import Optional, Tuple

import pygame

from game.core.stats import Stats


def clamp(value: float, min_value: float, max_value: float) -> float:
    return max(min_value, min(value, max_value))


def distance(ax: float, ay: float, bx: float, by: float) -> float:
    return math.hypot(bx - ax, by - ay)


class Entity:
    def __init__(
        self,
        x: float,
        y: float,
        radius: float,
        color: Tuple[int, int, int],
        stats: Stats,
        name: str = "Entity",
    ):
        self.x = float(x)
        self.y = float(y)

        self.vx = 0.0
        self.vy = 0.0

        self.radius = float(radius)
        self.color = color
        self.stats = stats
        self.name = name

        self.alive = True
        self.facing_x = 1.0
        self.facing_y = 0.0
        self.navigation_walls = []

    @property
    def pos(self) -> Tuple[float, float]:
        return self.x, self.y

    def set_position(self, x: float, y: float) -> None:
        self.x = float(x)
        self.y = float(y)

    def set_velocity(self, vx: float, vy: float) -> None:
        self.vx = float(vx)
        self.vy = float(vy)

        if vx != 0 or vy != 0:
            self.facing_x, self.facing_y = self.normalize(vx, vy)

    def stop(self) -> None:
        self.vx = 0.0
        self.vy = 0.0

    def normalize(self, dx: float, dy: float) -> Tuple[float, float]:
        length = math.hypot(dx, dy)
        if length == 0:
            return 0.0, 0.0
        return dx / length, dy / length

    def move_toward(self, tx: float, ty: float, speed: float) -> None:
        dx = tx - self.x
        dy = ty - self.y
        nx, ny = self.normalize(dx, dy)
        self.set_velocity(nx * speed, ny * speed)

    def move_away_from(self, tx: float, ty: float, speed: float) -> None:
        dx = self.x - tx
        dy = self.y - ty
        nx, ny = self.normalize(dx, dy)
        self.set_velocity(nx * speed, ny * speed)

    def get_rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x - self.radius), int(self.y - self.radius), int(self.radius * 2), int(self.radius * 2))

    def _can_move(self, move_x: float, move_y: float, walls: list[pygame.Rect]) -> bool:
        test_rect = self.get_rect().move(int(move_x), int(move_y))
        return not any(test_rect.colliderect(wall) for wall in walls)

    def _apply_wall_avoidance(self, dt: float) -> None:
        walls = getattr(self, "navigation_walls", []) or []
        if not walls or (self.vx == 0 and self.vy == 0):
            return

        move_x = self.vx * dt
        move_y = self.vy * dt

        if self._can_move(move_x, move_y, walls):
            self.x += move_x
            self.y += move_y
            return

        if self._can_move(move_x, 0.0, walls):
            self.x += move_x
            return

        if self._can_move(0.0, move_y, walls):
            self.y += move_y
            return

        dx = self.vx
        dy = self.vy
        side_x = -dy * dt
        side_y = dx * dt

        if self._can_move(side_x, side_y, walls):
            self.x += side_x
            self.y += side_y
            return

        if self._can_move(-side_x, -side_y, walls):
            self.x -= side_x
            self.y -= side_y
            return

        self.stop()

    def update(self, dt: float, world_rect: Optional[pygame.Rect] = None) -> None:
        self.stats.update(dt)

        if not self.stats.alive:
            self.alive = False
            self.stop()
            return

        self._apply_wall_avoidance(dt)

        if world_rect is not None:
            self.x = clamp(self.x, world_rect.left + self.radius, world_rect.right - self.radius)
            self.y = clamp(self.y, world_rect.top + self.radius, world_rect.bottom - self.radius)

    def distance_to(self, other: "Entity") -> float:
        return distance(self.x, self.y, other.x, other.y)

    def distance_to_point(self, px: float, py: float) -> float:
        return distance(self.x, self.y, px, py)

    def collides_with(self, other: "Entity") -> bool:
        return self.distance_to(other) <= (self.radius + other.radius)

    def take_damage(self, amount: float) -> float:
        dealt = self.stats.take_damage(amount)
        if not self.stats.alive:
            self.alive = False
            self.stop()
        return dealt

    def heal(self, amount: float) -> float:
        return self.stats.heal(amount)

    def draw(
        self,
        surface: pygame.Surface,
        cam_x: float = 0.0,
        cam_y: float = 0.0,
        draw_hp_bar: bool = True,
    ) -> None:
        if not self.alive:
            return

        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)

        pygame.draw.circle(surface, self.color, (sx, sy), int(self.radius))

        fx = sx + int(self.facing_x * self.radius)
        fy = sy + int(self.facing_y * self.radius)
        pygame.draw.line(surface, (255, 255, 255), (sx, sy), (fx, fy), 2)

        if draw_hp_bar:
            self.draw_health_bar(surface, sx, sy)

    def draw_health_bar(self, surface: pygame.Surface, sx: int, sy: int) -> None:
        bar_w = int(self.radius * 2.4)
        bar_h = 6

        x = sx - bar_w // 2
        y = sy - int(self.radius) - 14

        pygame.draw.rect(surface, (35, 35, 35), (x, y, bar_w, bar_h))

        fill = int(bar_w * self.stats.hp_ratio)
        pygame.draw.rect(surface, (220, 70, 70), (x, y, fill, bar_h))

        pygame.draw.rect(surface, (255, 255, 255), (x, y, bar_w, bar_h), 1)