from __future__ import annotations


def damage_after_defense(raw_damage: float, defense: float) -> float:
    raw_damage = max(0.0, float(raw_damage))
    defense = max(0.0, float(defense))
    if raw_damage <= 0:
        return 0.0
    return max(1.0, raw_damage - defense)
