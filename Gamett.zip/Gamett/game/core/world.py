from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class WorldBounds:
    width: int
    height: int

    def center(self) -> tuple[float, float]:
        return self.width / 2.0, self.height / 2.0
